/* FormQuest · background: storage, the locked vault, quests and runs.
   1.1: one writer at a time for recordings, recording across frames, routing quest steps to the right frame. */
importScripts('lib/fields.js', 'lib/crypto.js');

var DEFAULTS = {
  'fq.settings': { theme: 'dungeon', badge: true, sound: true, overwrite: false, autoLockMin: 30, weekEndDay: 5, hiddenSites: [], finalMode: 'count', autoSubmit: false },
  'fq.profiles': { active: 'me', list: { me: { name: 'Personal', data: {} }, biz: { name: 'Business', data: {} } } },
  'fq.answers': FQ.DEFAULT_ANSWERS,
  'fq.rules': {},
  'fq.quests': [],
  'fq.timesheets': { active: 'std', list: { std: { name: 'Standard week', project: '', task: '', comment: '', days: { mon: 8, tue: 8, wed: 8, thu: 8, fri: 8, sat: '', sun: '' } } } },
  'fq.log': []
};

function get(keys) { return chrome.storage.local.get(keys); }
function set(obj) { return chrome.storage.local.set(obj); }
function sget(keys) { return chrome.storage.session.get(keys); }
function sset(obj) { return chrome.storage.session.set(obj); }
// one writer at a time per key, so two steps that land together can't overwrite each other
var locks = {};
function withLock(name, fn) { var p = (locks[name] || Promise.resolve()).then(fn, fn); locks[name] = p.then(function () { }, function () { }); return p; }
function uid() { return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4); }

async function ensureDefaults() {
  var cur = await get(Object.keys(DEFAULTS)), add = {};
  Object.keys(DEFAULTS).forEach(function (k) { if (cur[k] == null) add[k] = DEFAULTS[k]; });
  if (cur['fq.settings']) add['fq.settings'] = Object.assign({}, DEFAULTS['fq.settings'], cur['fq.settings']);
  // new default questions show up for people who already have a bank
  if (cur['fq.answers']) {
    var ids = cur['fq.answers'].map(function (a) { return a.id; });
    var extra = FQ.DEFAULT_ANSWERS.filter(function (a) { return ids.indexOf(a.id) < 0; });
    if (extra.length) add['fq.answers'] = cur['fq.answers'].concat(extra);
  }
  if (Object.keys(add).length) await set(add);
}

chrome.runtime.onInstalled.addListener(async function (d) {
  await ensureDefaults();
  if (d.reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('vault.html#welcome') });
});
chrome.runtime.onStartup.addListener(ensureDefaults);

// ---------- the locked vault ----------
async function lockState() {
  var s = await get(['fq.secure', 'fq.settings']), sess = await sget(['fq.key', 'fq.unlockedAt']);
  var mins = (s['fq.settings'] && s['fq.settings'].autoLockMin) || 30;
  if (sess['fq.key'] && sess['fq.unlockedAt'] && Date.now() - sess['fq.unlockedAt'] > mins * 60000) { await lock(); sess = {}; }
  return { hasPassword: !!s['fq.secure'], unlocked: !!sess['fq.key'], box: s['fq.secure'] };
}
async function lock() { await chrome.storage.session.remove(['fq.key', 'fq.secureData', 'fq.unlockedAt']); }
async function unlock(password) {
  var s = (await get('fq.secure'))['fq.secure'];
  if (!s) return { ok: false, error: 'No master password yet.' };
  try {
    var raw = await FQCrypto.deriveRaw(password, s.salt);
    var data = await FQCrypto.open(raw, s.box);
    await sset({ 'fq.key': raw, 'fq.secureData': data, 'fq.unlockedAt': Date.now() });
    return { ok: true };
  } catch (e) { return { ok: false, error: 'That password didn\'t open the vault.' }; }
}
async function setPassword(password, oldPassword) {
  var s = (await get('fq.secure'))['fq.secure'], data = {};
  if (s) {
    var sess = await sget(['fq.key', 'fq.secureData']);
    if (sess['fq.key']) data = sess['fq.secureData'] || {};
    else {
      if (!oldPassword) return { ok: false, error: 'Enter your current password first.' };
      var r = await unlock(oldPassword); if (!r.ok) return r;
      data = (await sget('fq.secureData'))['fq.secureData'] || {};
    }
  }
  var salt = FQCrypto.newSalt(), raw = await FQCrypto.deriveRaw(password, salt);
  var box = await FQCrypto.seal(raw, data);
  await set({ 'fq.secure': { salt: salt, box: box, v: 1 } });
  await sset({ 'fq.key': raw, 'fq.secureData': data, 'fq.unlockedAt': Date.now() });
  return { ok: true };
}
async function saveSecure(data) {
  var sess = await sget('fq.key'), s = (await get('fq.secure'))['fq.secure'];
  if (!sess['fq.key'] || !s) return { ok: false, error: 'Unlock the vault first.' };
  var box = await FQCrypto.seal(sess['fq.key'], data);
  await set({ 'fq.secure': { salt: s.salt, box: box, v: 1 } });
  await sset({ 'fq.secureData': data, 'fq.unlockedAt': Date.now() });
  return { ok: true };
}

// ---------- what a page needs ----------
function hostMatch(qHost, host) { return qHost === host || host.endsWith('.' + qHost) || qHost.endsWith('.' + host); }
async function getCtx(host, tabId) {
  await ensureDefaults();
  var st = await get(Object.keys(DEFAULTS)), ls = await lockState();
  var settings = st['fq.settings'], profiles = st['fq.profiles'], prof = profiles.list[profiles.active] || { name: 'Personal', data: {} };
  var data = Object.assign({}, prof.data);
  if (ls.unlocked) { var sd = (await sget('fq.secureData'))['fq.secureData'] || {}; Object.assign(data, sd[profiles.active] || {}); }
  var tsAll = st['fq.timesheets'], ts = tsAll.list[tsAll.active];
  if (ts) {
    ['project', 'task', 'comment'].forEach(function (k) { if (ts[k] !== '' && ts[k] != null && !data['ts.' + k]) data['ts.' + k] = ts[k]; });
    Object.keys(ts.days || {}).forEach(function (d) { if (ts.days[d] !== '' && ts.days[d] != null) data['ts.' + d] = ts.days[d]; });
  }
  var hasSecure = FQ.FIELDS.some(function (f) { return f.secure; }) && ls.hasPassword;
  var rec = tabId != null ? (await sget('rec:' + tabId))['rec:' + tabId] : null;
  var allQuests = st['fq.quests'];
  return {
    settings: settings, data: data, answers: st['fq.answers'], rules: st['fq.rules'][host] || {},
    timesheet: ts, profileName: prof.name, locked: !ls.unlocked, hasSecure: hasSecure,
    quests: allQuests.filter(function (q) { return hostMatch(q.host, host); }), allQuests: allQuests,
    rec: rec ? { name: rec.name, steps: rec.steps.length, tail: recTail(rec) } : null,
    hidden: (settings.hiddenSites || []).indexOf(host) >= 0
  };
}

function patchList(key, fn) { return withLock(key, async function () { var cur = (await get(key))[key]; var next = fn(cur); await set({ [key]: next }); return next; }); }

// ---------- recording, in every frame of the tab ----------
function toTab(tabId, msg, frameId) {
  return new Promise(function (res) {
    var cb = function (r) { void chrome.runtime.lastError; res(r == null ? null : r); };
    try { if (frameId == null) chrome.tabs.sendMessage(tabId, msg, cb); else chrome.tabs.sendMessage(tabId, msg, { frameId: frameId }, cb); } catch (e) { res(null); }
  });
}
function recKey(tabId) { return 'rec:' + tabId; }
function recTail(rec) { return rec.steps.slice(-5).map(FQ.stepText); }
function tellTop(tabId, rec) { toTab(tabId, { type: 'fq.recCount', n: rec.steps.length, tail: recTail(rec) }, 0); }
async function fqRecStart(tabId, info) {
  await sset({ [recKey(tabId)]: { name: info.name, host: info.host, url: info.url, steps: [], trace: [] } });
  await toTab(tabId, { type: 'fq.rec', on: true });
  return { ok: true };
}
function recEdit(tabId, fn) {
  return withLock(recKey(tabId), async function () {
    var k = recKey(tabId), rec = (await sget(k))[k]; if (!rec) return null;
    var out = fn(rec);
    await sset({ [k]: rec });
    if (out !== false) tellTop(tabId, rec);
    return { steps: rec.steps.length };
  });
}
function recAdd(tabId, step) {
  return recEdit(tabId, function (rec) {
    if (step.merge) { var m = step.merge; rec.steps = rec.steps.filter(function (s) { return m.indexOf(s.id) < 0; }); delete step.merge; }
    // typing in the same box again replaces its earlier step, as long as nothing but typing happened in between
    if (step.type === 'fill' && step.eid) for (var j = rec.steps.length - 1; j >= 0; j--) {
      var s = rec.steps[j]; if (s.type !== 'fill') break;
      if (s.eid === step.eid) { rec.steps[j] = step; return; }
    }
    rec.steps.push(step);
  });
}
async function fqRecStop(tabId, save) {
  await toTab(tabId, { type: 'fq.rec', on: false });       // every frame writes down what it is still holding
  await new Promise(function (r) { setTimeout(r, 450); });
  return withLock(recKey(tabId), async function () {
    var k = recKey(tabId), r = (await sget(k))[k];
    await chrome.storage.session.remove(k);
    if (!save || !r || !r.steps.length) return { saved: false };
    r.steps.forEach(function (s) { delete s.eid; });
    await patchList('fq.quests', function (q) { q.push({ id: uid(), v: 2, name: r.name, host: r.host, url: r.url, steps: r.steps, trace: (r.trace || []).slice(-500), created: Date.now(), runs: 0 }); return q; });
    return { saved: true, steps: r.steps.length };
  });
}
// which frame holds the thing a step points at?
async function frameFind(tabId, step) {
  var frames = [];
  try { frames = (await chrome.webNavigation.getAllFrames({ tabId: tabId })) || []; } catch (e) { }
  var rs = await Promise.all(frames.filter(function (f) { return f.frameId !== 0; }).map(function (f) {
    return toTab(tabId, { type: 'fq.probe', step: step }, f.frameId).then(function (r) { return { id: f.frameId, s: (r && r.score) || 0 }; });
  }));
  rs.sort(function (a, b) { return b.s - a.s; });
  return { frameId: rs[0] && rs[0].s > 0 ? rs[0].id : null };
}

// ---------- messages ----------
chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
  var tabId = sender.tab ? sender.tab.id : msg.tabId;
  (async function () {
    switch (msg.type) {
      case 'getCtx': return reply(await getCtx(msg.host, tabId));
      case 'saveRule':
        await patchList('fq.rules', function (r) { r = r || {}; r[msg.host] = r[msg.host] || {}; r[msg.host][msg.sig] = Object.assign({ at: Date.now() }, msg.rule); return r; });
        return reply({ ok: true });
      case 'deleteRule':
        await patchList('fq.rules', function (r) { if (r[msg.host]) { if (msg.sig) delete r[msg.host][msg.sig]; else delete r[msg.host]; } return r; });
        return reply({ ok: true });
      case 'addAnswer': {
        var id = uid();
        await patchList('fq.answers', function (a) { a.push({ id: id, q: msg.q, kw: [], a: msg.a || '', custom: true }); return a; });
        return reply({ id: id });
      }
      case 'flagQuestion':
        await patchList('fq.answers', function (a) {
          var n = FQ.norm(msg.q);
          if (!n || n.length < 6 || a.some(function (x) { return FQ.norm(x.q) === n; })) return a;
          if (FQ.matchAnswer(msg.q, a.map(function (x) { return Object.assign({}, x, { a: x.a || '?' }); }))) return a;
          a.push({ id: uid(), q: msg.q.slice(0, 200), kw: [], a: '', custom: true, flagged: true, from: msg.host });
          return a.slice(-300);
        });
        return reply({ ok: true });
      case 'log':
        await patchList('fq.log', function (l) { l.push(Object.assign({ t: Date.now() }, msg.entry)); return l.slice(-400); });
        return reply({ ok: true });
      case 'frameCount':
        if (tabId != null) chrome.tabs.sendMessage(tabId, { type: 'fq.frameCount', frameId: sender.frameId, n: msg.n }, { frameId: 0 }, function () { void chrome.runtime.lastError; });
        return reply({ ok: true });
      case 'broadcast':
        if (tabId != null) chrome.tabs.sendMessage(tabId, { type: 'fq.cmd', cmd: msg.cmd }, function () { void chrome.runtime.lastError; });
        return reply({ ok: true });
      case 'run.get': return reply((await sget('run:' + tabId))['run:' + tabId] || null);
      case 'run.set': await sset({ ['run:' + tabId]: Object.assign({ started: Date.now() }, msg.run) }); return reply({ ok: true });
      case 'run.patch': {
        await withLock('run:' + tabId, async function () { var cur = (await sget('run:' + tabId))['run:' + tabId]; if (cur) await sset({ ['run:' + tabId]: Object.assign(cur, msg.patch) }); });
        return reply({ ok: true });
      }
      case 'run.clear': await chrome.storage.session.remove('run:' + tabId); return reply({ ok: true });
      case 'rec.start': return reply(await fqRecStart(tabId, msg));
      case 'rec.state': { var rs = tabId != null ? (await sget(recKey(tabId)))[recKey(tabId)] : null; return reply({ on: !!rs }); }
      case 'rec.add': return reply(tabId != null ? await recAdd(tabId, msg.step) : null);
      case 'rec.patch': return reply(await recEdit(tabId, function (rec) { var st = rec.steps.filter(function (x) { return x.id === msg.id; })[0]; if (st) Object.assign(st, msg.patch); return false; }));
      case 'rec.undo': return reply(await recEdit(tabId, function (rec) { rec.steps.pop(); }));
      case 'rec.trace': return reply(await recEdit(tabId, function (rec) { rec.trace = (rec.trace || []).concat(msg.lines || []).slice(-500); return false; }));
      case 'rec.stop': return reply(await fqRecStop(tabId, msg.save));
      case 'frame.find': return reply(await frameFind(tabId, msg.step));
      case 'frame.exec': return reply(await toTab(tabId, { type: 'fq.exec', step: msg.step }, msg.frameId));
      case 'hideSite':
        await patchList('fq.settings', function (s) { s.hiddenSites = (s.hiddenSites || []).concat([msg.host]).filter(function (v, i, a) { return a.indexOf(v) === i; }); return s; });
        return reply({ ok: true });
      case 'openVault': chrome.tabs.create({ url: chrome.runtime.getURL('vault.html' + (msg.hash || '')) }); return reply({ ok: true });
      case 'lockState': { var ls = await lockState(); return reply({ hasPassword: ls.hasPassword, unlocked: ls.unlocked }); }
      case 'unlock': return reply(await unlock(msg.password));
      case 'lock': await lock(); return reply({ ok: true });
      case 'setPassword': return reply(await setPassword(msg.password, msg.oldPassword));
      case 'getSecure': { var l2 = await lockState(); if (!l2.unlocked) return reply({ ok: false }); return reply({ ok: true, data: (await sget('fq.secureData'))['fq.secureData'] || {} }); }
      case 'saveSecure': return reply(await saveSecure(msg.data));
      case 'touch': { var l3 = await lockState(); if (l3.unlocked) await sset({ 'fq.unlockedAt': Date.now() }); return reply({ ok: true }); }
      default: return reply(null);
    }
  })();
  return true;
});

chrome.tabs.onRemoved.addListener(function (tabId) { chrome.storage.session.remove(['run:' + tabId, 'rec:' + tabId]); });

chrome.commands.onCommand.addListener(async function (cmd) {
  var tabs = await chrome.tabs.query({ active: true, currentWindow: true }); if (!tabs[0]) return;
  if (cmd === 'fill-page') chrome.tabs.sendMessage(tabs[0].id, { type: 'fq.cmd', cmd: 'fill' }, function () { void chrome.runtime.lastError; });
  if (cmd === 'open-panel') chrome.tabs.sendMessage(tabs[0].id, { type: 'fq.cmd', cmd: 'open' }, { frameId: 0 }, function () { void chrome.runtime.lastError; });
});
