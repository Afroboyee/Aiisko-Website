(async function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  function send(msg) { return new Promise(function (r) { chrome.runtime.sendMessage(msg, function (x) { void chrome.runtime.lastError; r(x); }); }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function toast(t) { document.querySelectorAll('.toast').forEach(function (x) { x.remove(); }); var d = document.createElement('div'); d.className = 'toast bubble'; d.textContent = t; document.body.appendChild(d); setTimeout(function () { d.remove(); }, 2400); }
  var KEYS = ['fq.settings', 'fq.profiles', 'fq.answers', 'fq.rules', 'fq.quests', 'fq.timesheets', 'fq.log'];
  // make sure defaults exist even if this page opens first
  await send({ type: 'getCtx', host: 'guild.hall' });
  var S = await chrome.storage.local.get(KEYS);
  var ns = document.createElement('style'); ns.textContent = self.NIB_CSS; document.head.appendChild(ns);
  function save(key) { var o = {}; o[key] = S[key]; return chrome.storage.local.set(o); }
  function applyTheme() {
    var t = S['fq.settings'].theme || 'dungeon';
    document.documentElement.setAttribute('data-fq-theme', t);
    $('brandNib').innerHTML = self.NibSVG('happy', t);
    $('welcomeNib').innerHTML = self.NibSVG('cheer', t);
  }
  applyTheme();

  // ---------- tabs ----------
  function showTab(t) {
    document.querySelectorAll('#tabs .tab').forEach(function (b) { b.setAttribute('aria-selected', b.dataset.t === t); });
    document.querySelectorAll('section[data-tab]').forEach(function (s) { s.classList.toggle('on', s.dataset.tab === t); });
    RENDER[t] && RENDER[t]();
    if (location.hash.slice(1) !== t && location.hash !== '#welcome') history.replaceState(null, '', '#' + t);
  }
  $('tabs').onclick = function (e) { var b = e.target.closest('.tab'); if (b) showTab(b.dataset.t); };

  // ---------- lock ----------
  var secure = null;
  async function refreshLock() {
    var ls = await send({ type: 'lockState' });
    if (ls.unlocked) { var r = await send({ type: 'getSecure' }); secure = r && r.ok ? r.data : {}; } else secure = null;
    $('lockTag').innerHTML = !ls.hasPassword ? '<span class="tag warn">No master password</span>' : ls.unlocked ? '<button class="btn sm ghost" id="lockNow">🔓 Unlocked · Lock</button>' : '<span class="tag info">🔒 Locked</span>';
    if ($('lockNow')) $('lockNow').onclick = async function () { await send({ type: 'lock' }); await refreshLock(); RENDER.hero(); };
    $('oldWrap').hidden = !ls.hasPassword || ls.unlocked;
    $('pwBtn').textContent = ls.hasPassword ? 'Change password' : 'Set password';
    return ls;
  }

  // ---------- hero sheet ----------
  var editing = S['fq.profiles'].active;
  RENDER = {};
  var RENDER;
  RENDER = {
    hero: async function () {
      var P = S['fq.profiles'], ls = await refreshLock();
      if (!P.list[editing]) editing = P.active;
      $('profSel').innerHTML = Object.keys(P.list).map(function (k) { return '<option value="' + k + '"' + (k === editing ? ' selected' : '') + '>' + esc(P.list[k].name) + (k === P.active ? ' (in use)' : '') + '</option>'; }).join('');
      $('profName').value = P.list[editing].name;
      $('profActive').disabled = editing === P.active;
      var data = P.list[editing].data, sec = (secure && secure[editing]) || {};
      $('groups').innerHTML = FQ.GROUPS.filter(function (g) { return g[0] !== 'custom'; }).map(function (g) {
        var fs = FQ.FIELDS.filter(function (f) { return f.g === g[0] && !f.derived; });
        if (g[0] === 'ts') return '';
        var hasSecure = fs.some(function (f) { return f.secure; });
        var lockNote = hasSecure && !ls.unlocked ? '<div class="secure-lock"><span class="tag info">🔒 Locked fields</span><span class="muted">' + (ls.hasPassword ? 'Unlock to see or edit them.' : 'Set a master password in Settings to store these.') + '</span>' + (ls.hasPassword ? '<form class="row unl"><input class="inp" type="password" placeholder="Master password" aria-label="Master password" style="width:200px" autocomplete="current-password"><button class="btn sm primary">Unlock</button></form>' : '<button class="btn sm alt" data-go="settings">Go to Settings</button>') + '</div>' : '';
        return '<section class="panel grp"><h3 class="disp">' + esc(g[1]) + '</h3>' + lockNote + '<div class="grid2">' + fs.map(function (f) {
          var isSec = !!f.secure, val = isSec ? sec[f.k] : data[f.k], dis = isSec && !ls.unlocked ? ' disabled placeholder="🔒 locked"' : '';
          var type = f.type === 'date' ? 'date' : f.type === 'email' ? 'email' : f.type === 'phone' ? 'tel' : 'text';
          var input = f.type === 'long' ? '<textarea class="inp" data-k="' + f.k + '"' + dis + '>' + esc(val || '') + '</textarea>'
            : f.type === 'state' ? '<select class="inp" data-k="' + f.k + '"' + dis + '><option value=""></option>' + Object.keys(FQ.STATES).map(function (a) { return '<option value="' + a + '"' + (val === a ? ' selected' : '') + '>' + FQ.STATES[a] + '</option>'; }).join('') + '</select>'
              : '<input class="inp" type="' + type + '" data-k="' + f.k + '" value="' + esc(isSec && !ls.unlocked ? '' : (val || '')) + '"' + dis + ' autocomplete="off">';
          return '<label class="f' + (isSec ? ' secure' : '') + '">' + esc(f.label) + (isSec ? ' <span class="lock-ic">🔒</span>' : '') + (f.hint ? ' <small>' + esc(f.hint) + '</small>' : '') + input + '</label>';
        }).join('') + '</div></section>';
      }).join('') +
        '<section class="panel grp"><h3 class="disp">Custom fields</h3><p class="muted" style="margin:0 0 10px">Anything else you type a lot: a badge number, a vendor ID, a reference\'s name. Teach a box to use it from the on-page panel.</p><div class="grid2" id="customs">' +
        Object.keys(data).filter(function (k) { return k.indexOf('custom.') === 0; }).map(function (k) { return '<label class="f">' + esc(k.slice(7)) + '<input class="inp" data-k="' + esc(k) + '" value="' + esc(data[k]) + '"></label>'; }).join('') +
        '</div><button class="btn sm" id="addCustom" style="margin-top:10px">＋ Add custom field</button></section>';
      $('groups').querySelectorAll('form.unl').forEach(function (f) {
        f.onsubmit = async function (e) { e.preventDefault(); var r = await send({ type: 'unlock', password: f.querySelector('input').value }); if (r.ok) { toast('Vault unlocked!'); RENDER.hero(); } else toast(r.error); };
      });
      $('addCustom').onclick = function () {
        var n = prompt('Name for this field (for example "Employee ID"):'); if (!n) return;
        var k = 'custom.' + n.trim(); S['fq.profiles'].list[editing].data[k] = ''; save('fq.profiles'); RENDER.hero();
      };
    },
    answers: function () {
      var A = S['fq.answers'].slice().sort(function (a, b) { return (b.flagged ? 1 : 0) - (a.flagged ? 1 : 0); });
      $('ansList').innerHTML = A.length ? A.map(function (a) {
        return '<div class="ans" data-id="' + esc(a.id) + '"><div><div class="qt">' + esc(a.q) + (a.flagged ? '<span class="tag info new">new from ' + esc(a.from || 'the road') + '</span>' : '') + (!a.a ? '<span class="tag warn new">needs answer</span>' : '') + '</div>' +
          '<div class="kw">Also matches: ' + esc((a.kw || []).join(', ') || '(the question text)') + ' · <a href="#" data-kw>edit</a></div></div>' +
          '<input class="inp" data-a list="ansHints" value="' + esc(a.a) + '" placeholder="Your answer" aria-label="Answer">' +
          '<button class="btn sm danger" data-del aria-label="Delete">✕</button></div>';
      }).join('') + '<datalist id="ansHints"><option>Yes</option><option>No</option><option>I don\'t wish to answer</option><option>I decline to self-identify</option><option>I identify as one or more of the classifications of protected veteran</option><option>LinkedIn</option><option>Company website</option><option>Indeed</option><option>Referral</option></datalist>' : '<p class="empty">No questions yet.</p>';
    },
    quests: function () {
      var Q = S['fq.quests'];
      $('questList').innerHTML = Q.length ? Q.map(function (q) {
        return '<section class="panel quest" data-id="' + q.id + '"><header><h3 class="disp">' + esc(q.name) + '</h3><span class="tag info">' + esc(q.host) + '</span><span class="muted">' + q.steps.length + ' steps</span>' +
          '<button class="btn sm" data-ren>Rename</button><button class="btn sm" data-open>Open site</button>' + ((q.trace || []).length ? '<button class="btn sm" data-trace title="What the recorder heard, step by step. Paste it to Claude if a site was not recorded right.">Copy recorder notes</button>' : '') + '<button class="btn sm danger" data-del>Delete</button></header>' +
          '<ol class="steps">' + q.steps.map(function (st, i) {
            if (st.type === 'page') return '<li class="muted">New page</li>';
            var stopMode = S['fq.settings'].finalMode === 'stop';
            var fin = (st.type === 'click' || st.type === 'choose') && st.final ? (stopMode ? ' <label class="chip" style="margin-left:6px"><input type="checkbox" data-allow="' + i + '"' + (st.allowFinal ? ' checked' : '') + '> Let FormQuest press this final button</label>' : ' <span class="tag warn">final button, I press it</span>') : '';
            if (st.date && st.rel != null && !st.key) fin += ' <label class="chip" style="margin-left:6px" title="On: the date moves with the day you run the quest. Off: always ' + esc(String(st.value)) + '."><input type="checkbox" data-rel="' + i + '"' + (st.relOn ? ' checked' : '') + '> Move with today</label>';
            return '<li>' + esc(FQ.stepText(st)) + (st.frame ? ' <span class="muted">(inside an embedded frame)</span>' : '') + fin + ' <button class="btn sm ghost" data-rm="' + i + '" title="Remove this step" aria-label="Remove step ' + (i + 1) + '" style="padding:1px 7px;margin-left:4px">✕</button></li>';
          }).join('') + '</ol></section>';
      }).join('') : '<div class="panel empty">No quests yet. On any site, open the FormQuest panel and press ⏺ Record quest.</div>';
    },
    timesheets: function () {
      var T = S['fq.timesheets'], days = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
      $('tsList').innerHTML = Object.keys(T.list).map(function (id) {
        var t = T.list[id];
        return '<section class="panel" data-id="' + id + '"><div class="row" style="justify-content:space-between;margin-bottom:10px"><h3 class="disp" style="font-size:17px">' + esc(t.name) + (id === T.active ? ' <span class="tag good">active</span>' : '') + '</h3><div class="row">' + (id !== T.active ? '<button class="btn sm primary" data-act>Make active</button>' : '') + '<button class="btn sm danger" data-del>Delete</button></div></div>' +
          '<div class="grid2"><label class="f">Template name<input class="inp" data-f="name" value="' + esc(t.name) + '"></label><label class="f">Project / charge code<input class="inp" data-f="project" value="' + esc(t.project) + '"></label><label class="f">Task / activity<input class="inp" data-f="task" value="' + esc(t.task) + '"></label><label class="f">Comment<input class="inp" data-f="comment" value="' + esc(t.comment) + '"></label></div>' +
          '<div class="days" style="margin-top:12px">' + days.map(function (d) { return '<label class="f">' + d[0].toUpperCase() + d.slice(1) + '<input class="inp" inputmode="decimal" data-d="' + d + '" value="' + esc(t.days[d]) + '"></label>'; }).join('') + '</div></section>';
      }).join('');
    },
    sites: function () {
      var R = S['fq.rules'], hosts = Object.keys(R).filter(function (h) { return Object.keys(R[h]).length; });
      $('siteList').innerHTML = hosts.length ? hosts.map(function (h) {
        return '<section class="panel" data-host="' + esc(h) + '"><div class="row" style="justify-content:space-between"><h3 class="disp" style="font-size:17px">' + esc(h) + '</h3><button class="btn sm danger" data-delhost>Forget this site</button></div><div class="tbl"><table><tbody>' +
          Object.keys(R[h]).map(function (sig) {
            var r = R[h][sig], what = r.skip ? 'Skip' : r.key ? (FQ.BY_KEY[r.key] || {}).label || r.key : r.answer ? 'Answer: ' + ((S['fq.answers'].find(function (a) { return a.id === r.answer; }) || {}).q || '?') : 'Type "' + r.value + '"';
            return '<tr><td>' + esc(sig.split('|').slice(2).join(' ').replace(/^[a-z]:/, '')) + '</td><td>' + esc(what) + '</td><td class="n"><button class="btn sm ghost" data-delsig="' + esc(sig) + '">Forget</button></td></tr>';
          }).join('') + '</tbody></table></div></section>';
      }).join('') : '<div class="panel empty">Nothing taught yet. Use ✎ Teach on any form.</div>';
    },
    log: function () {
      var L = S['fq.log'].slice().reverse();
      var boxes = L.reduce(function (s, x) { return s + (+x.filled || 0); }, 0), sites = {}, week = 0, now = Date.now();
      L.forEach(function (x) { sites[x.host] = 1; if (now - x.t < 7 * 864e5) week += +x.filled || 0; });
      var mins = Math.round(boxes * 7 / 60);
      $('tiles').innerHTML = [['Boxes filled', boxes.toLocaleString()], ['This week', week.toLocaleString()], ['Sites', Object.keys(sites).length], ['Time saved', mins >= 60 ? (mins / 60).toFixed(1) + ' hrs' : mins + ' min']].map(function (t) { return '<div class="panel tile"><span class="l">' + t[0] + '</span><span class="v">' + t[1] + '</span></div>'; }).join('');
      $('logBody').innerHTML = L.length ? L.slice(0, 300).map(function (x) { return '<tr><td>' + new Date(x.t).toLocaleString() + '</td><td>' + esc(x.host) + '</td><td>' + esc(x.quest || x.title || '') + '</td><td>' + esc({ fill: 'Fill', auto: 'Fill & continue', quest: 'Quest' }[x.mode] || x.mode) + '</td><td class="n">' + (x.filled || 0) + '</td></tr>'; }).join('') : '<tr><td colspan="5" class="empty">No runs yet.</td></tr>';
    },
    settings: async function () {
      var st = S['fq.settings'];
      $('themes').innerHTML = [['dungeon', 'Dungeon', 'Violet night, gold loot'], ['yami', 'Yami', 'Darkest: black ink, crimson'], ['neon', 'Neon Arcade', 'Cyan and magenta glow'], ['parchment', 'Parchment', 'Light: old map paper']].map(function (t) {
        return '<button class="panel theme" data-theme="' + t[0] + '" data-fq-theme="' + t[0] + '" aria-pressed="' + (st.theme === t[0]) + '" style="background:var(--surface);color:var(--ink)"><div class="nib-wrap">' + self.NibSVG('ready', t[0]) + '</div><b>' + t[1] + '</b><span class="muted" style="font-size:12.5px">' + t[2] + '</span></button>';
      }).join('');
      $('setBadge').value = st.badge === false ? '0' : '1';
      $('setSound').value = st.sound === false ? '0' : '1';
      $('setOver').value = st.overwrite ? '1' : '0';
      $('setLock').value = String(st.autoLockMin || 30);
      $('setWeek').value = String(st.weekEndDay != null ? st.weekEndDay : 5);
      $('setFinal').value = st.finalMode || 'count';
      $('setAuto').value = st.autoSubmit ? '1' : '0';
      $('hiddenSites').innerHTML = (st.hiddenSites || []).length ? st.hiddenSites.map(function (h) { return '<button class="chip" data-unhide="' + esc(h) + '">' + esc(h) + ' ✕</button>'; }).join('') : '<span class="muted">None</span>';
      await refreshLock();
    }
  };

  // ---------- hero events ----------
  var saveT = 0;
  $('groups').addEventListener('input', function (e) {
    var el = e.target, k = el.dataset.k; if (!k) return;
    var f = FQ.BY_KEY[k];
    clearTimeout(saveT);
    saveT = setTimeout(async function () {
      if (f && f.secure) {
        if (!secure) return;
        secure[editing] = secure[editing] || {}; secure[editing][k] = el.value;
        var r = await send({ type: 'saveSecure', data: secure }); toast(r.ok ? 'Saved to the locked vault 🔒' : r.error);
      } else { S['fq.profiles'].list[editing].data[k] = el.value; await save('fq.profiles'); toast('Saved ✓'); }
    }, 450);
  });
  $('groups').addEventListener('click', function (e) { var g = e.target.closest('[data-go]'); if (g) showTab(g.dataset.go); });
  $('profSel').onchange = function () { editing = this.value; RENDER.hero(); };
  $('profName').onchange = function () { S['fq.profiles'].list[editing].name = this.value || 'Profile'; save('fq.profiles'); RENDER.hero(); };
  $('profActive').onclick = function () { S['fq.profiles'].active = editing; save('fq.profiles'); RENDER.hero(); toast('Now filling with ' + S['fq.profiles'].list[editing].name); };
  $('profNew').onclick = function () { var n = prompt('Name for the new profile:', 'Business'); if (!n) return; var id = 'p' + Date.now().toString(36); S['fq.profiles'].list[id] = { name: n, data: {} }; editing = id; save('fq.profiles'); RENDER.hero(); };
  $('profDup').onclick = function () { var src = S['fq.profiles'].list[editing], id = 'p' + Date.now().toString(36); S['fq.profiles'].list[id] = { name: src.name + ' copy', data: Object.assign({}, src.data) }; editing = id; save('fq.profiles'); RENDER.hero(); };
  $('profDel').onclick = function () {
    var P = S['fq.profiles']; if (Object.keys(P.list).length < 2) return toast('Keep at least one profile.');
    if (!confirm('Delete the profile "' + P.list[editing].name + '"?')) return;
    delete P.list[editing]; if (P.active === editing) P.active = Object.keys(P.list)[0]; editing = P.active; save('fq.profiles'); RENDER.hero();
  };

  // ---------- answers events ----------
  $('ansList').addEventListener('input', function (e) {
    var row = e.target.closest('.ans'); if (!row || !e.target.hasAttribute('data-a')) return;
    var a = S['fq.answers'].find(function (x) { return x.id === row.dataset.id; }); a.a = e.target.value; delete a.flagged;
    clearTimeout(saveT); saveT = setTimeout(function () { save('fq.answers'); toast('Saved ✓'); }, 450);
  });
  $('ansList').addEventListener('click', function (e) {
    var row = e.target.closest('.ans'); if (!row) return;
    var i = S['fq.answers'].findIndex(function (x) { return x.id === row.dataset.id; }), a = S['fq.answers'][i];
    if (e.target.hasAttribute('data-del')) { if (confirm('Delete this question?')) { S['fq.answers'].splice(i, 1); save('fq.answers'); RENDER.answers(); } }
    if (e.target.hasAttribute('data-kw')) { e.preventDefault(); var v = prompt('Other words or phrases that mean this question (comma separated):', (a.kw || []).join(', ')); if (v != null) { a.kw = v.split(',').map(function (s) { return s.trim(); }).filter(Boolean); save('fq.answers'); RENDER.answers(); } }
  });
  $('ansAdd').onclick = function () {
    var q = prompt('The question, as sites usually ask it:'); if (!q) return;
    var a = prompt('Your answer:') || '';
    S['fq.answers'].unshift({ id: 'u' + Date.now().toString(36), q: q, kw: [], a: a, custom: true }); save('fq.answers'); RENDER.answers();
  };

  // ---------- quest events ----------
  $('questList').addEventListener('click', function (e) {
    var sec = e.target.closest('.quest'); if (!sec) return;
    var q = S['fq.quests'].find(function (x) { return x.id === sec.dataset.id; });
    if (e.target.hasAttribute('data-del')) { if (confirm('Delete the quest "' + q.name + '"?')) { S['fq.quests'] = S['fq.quests'].filter(function (x) { return x !== q; }); save('fq.quests'); RENDER.quests(); } }
    if (e.target.hasAttribute('data-ren')) { var n = prompt('Quest name:', q.name); if (n) { q.name = n; save('fq.quests'); RENDER.quests(); } }
    if (e.target.hasAttribute('data-open')) chrome.tabs.create({ url: q.url || ('https://' + q.host) });
    if (e.target.hasAttribute('data-rel')) { q.steps[+e.target.getAttribute('data-rel')].relOn = e.target.checked; save('fq.quests'); RENDER.quests(); return; }
    if (e.target.hasAttribute('data-rm')) { var k = +e.target.getAttribute('data-rm'); if (confirm('Remove step ' + (k + 1) + ' from this quest?\n' + FQ.stepText(q.steps[k]))) { q.steps.splice(k, 1); save('fq.quests'); RENDER.quests(); } }
    if (e.target.hasAttribute('data-trace')) {
      var text = 'FormQuest recorder notes for "' + q.name + '" on ' + q.host + '\n\nSTEPS\n' + q.steps.map(function (st, i) { return (i + 1) + '. ' + FQ.stepText(st); }).join('\n') + '\n\nWHAT THE RECORDER HEARD\n' + (q.trace || []).join('\n');
      navigator.clipboard.writeText(text).then(function () { toast('Copied. Paste it to Claude with a note on what was missed.'); }, function () { toast('Could not copy.'); });
    }
  });
  $('questList').addEventListener('change', function (e) {
    var sec = e.target.closest('.quest'), i = e.target.dataset.allow; if (!sec || i == null) return;
    var q = S['fq.quests'].find(function (x) { return x.id === sec.dataset.id; });
    q.steps[+i].allowFinal = e.target.checked; save('fq.quests');
    toast(e.target.checked ? 'Okay, I\'ll press that one for you.' : 'I\'ll stop before that button.');
  });

  // ---------- timesheet events ----------
  $('tsList').addEventListener('input', function (e) {
    var sec = e.target.closest('[data-id]'); if (!sec) return;
    var t = S['fq.timesheets'].list[sec.dataset.id];
    if (e.target.dataset.f) t[e.target.dataset.f] = e.target.value;
    if (e.target.dataset.d) t.days[e.target.dataset.d] = e.target.value;
    clearTimeout(saveT); saveT = setTimeout(function () { save('fq.timesheets'); toast('Saved ✓'); }, 450);
  });
  $('tsList').addEventListener('click', function (e) {
    var sec = e.target.closest('[data-id]'); if (!sec) return;
    var T = S['fq.timesheets'], id = sec.dataset.id;
    if (e.target.hasAttribute('data-act')) { T.active = id; save('fq.timesheets'); RENDER.timesheets(); }
    if (e.target.hasAttribute('data-del')) { if (Object.keys(T.list).length < 2) return toast('Keep at least one template.'); if (confirm('Delete this template?')) { delete T.list[id]; if (T.active === id) T.active = Object.keys(T.list)[0]; save('fq.timesheets'); RENDER.timesheets(); } }
  });
  $('tsAdd').onclick = function () { var n = prompt('Template name:', 'Holiday week'); if (!n) return; var id = 't' + Date.now().toString(36); S['fq.timesheets'].list[id] = { name: n, project: '', task: '', comment: '', days: { mon: '', tue: '', wed: '', thu: '', fri: '', sat: '', sun: '' } }; save('fq.timesheets'); RENDER.timesheets(); };

  // ---------- sites events ----------
  $('siteList').addEventListener('click', async function (e) {
    var sec = e.target.closest('[data-host]'); if (!sec) return;
    var h = sec.dataset.host;
    if (e.target.hasAttribute('data-delhost')) { if (!confirm('Forget everything taught on ' + h + '?')) return; delete S['fq.rules'][h]; }
    else if (e.target.dataset.delsig) delete S['fq.rules'][h][e.target.dataset.delsig];
    else return;
    await save('fq.rules'); RENDER.sites();
  });

  // ---------- log events ----------
  $('logCsv').onclick = function () {
    var rows = [['when', 'site', 'page', 'mode', 'boxes']].concat(S['fq.log'].map(function (x) { return [new Date(x.t).toISOString(), x.host, x.quest || x.title || '', x.mode, x.filled]; }));
    var csv = rows.map(function (r) { return r.map(function (c) { return '"' + String(c == null ? '' : c).replace(/"/g, '""') + '"'; }).join(','); }).join('\n');
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'formquest-log.csv'; a.click();
  };
  $('logPrint').onclick = function () { window.print(); };
  $('logClear').onclick = function () { if (confirm('Clear the whole quest log?')) { S['fq.log'] = []; save('fq.log'); RENDER.log(); } };

  // ---------- settings events ----------
  $('themes').onclick = function (e) { var b = e.target.closest('[data-theme]'); if (!b) return; S['fq.settings'].theme = b.dataset.theme; save('fq.settings'); applyTheme(); RENDER.settings(); };
  function bindSet(id, key, fn) { $(id).onchange = function () { S['fq.settings'][key] = fn(this.value); save('fq.settings'); toast('Saved ✓'); }; }
  bindSet('setBadge', 'badge', function (v) { return v === '1'; });
  bindSet('setSound', 'sound', function (v) { return v === '1'; });
  bindSet('setOver', 'overwrite', function (v) { return v === '1'; });
  bindSet('setLock', 'autoLockMin', function (v) { return +v; });
  bindSet('setWeek', 'weekEndDay', function (v) { return +v; });
  bindSet('setFinal', 'finalMode', function (v) { return v; });
  bindSet('setAuto', 'autoSubmit', function (v) { return v === '1'; });

  // ---------- resume import ----------
  function resShow(found) {
    var data = S['fq.profiles'].list[editing].data, keys = FQ.FIELDS.map(function (f) { return f.k; }).filter(function (k) { return found.fields[k]; });
    $('resReview').hidden = false;
    if (!keys.length) { $('resReview').innerHTML = '<p class="muted" style="margin:12px 0 0">I couldn\'t pick anything out of that. If it\'s a scanned image, there is no text in it to read. Try pasting the text instead.</p>'; return; }
    $('resReview').innerHTML = '<p style="margin:14px 0 0"><b>I found ' + keys.length + ' things.</b> <span class="muted">Fix any box, untick anything wrong, then save. Yellow tags are my best guess, so look at those twice.</span></p><div class="rev">' + keys.map(function (k) {
      var f = FQ.BY_KEY[k], v = found.fields[k], cur = data[k], differs = cur && String(cur) !== String(v);
      var inp = f.type === 'long' ? '<textarea class="inp" data-rv="' + k + '" aria-label="' + esc(f.label) + '">' + esc(v) + '</textarea>' : '<input class="inp" data-rv="' + k + '" aria-label="' + esc(f.label) + '" value="' + esc(v) + '">';
      return '<label class="revrow"><input type="checkbox" data-rk="' + k + '"' + (differs ? '' : ' checked') + '><b>' + esc(f.label) + (found.sure[k] ? '' : ' <span class="tag warn">check</span>') + '</b>' + inp + (differs ? '<span class="now">You already have: ' + esc(String(cur).slice(0, 80)) + '. Tick the box to replace it.</span>' : '') + '</label>';
    }).join('') + '</div><div class="row" style="margin-top:12px"><button class="btn primary" id="resSave">Save ticked boxes to ' + esc(S['fq.profiles'].list[editing].name) + '</button><button class="btn" id="resCancel">Never mind</button></div>';
    $('resSave').onclick = async function () {
      var d = S['fq.profiles'].list[editing].data, n = 0;
      $('resReview').querySelectorAll('[data-rk]').forEach(function (c) { if (!c.checked) return; var v = $('resReview').querySelector('[data-rv="' + c.dataset.rk + '"]').value.trim(); if (v) { d[c.dataset.rk] = v; n++; } });
      await save('fq.profiles'); $('resReview').hidden = true; $('resReview').innerHTML = ''; $('resPasteBox').hidden = true; RENDER.hero();
      toast('Saved ' + n + ' boxes from your resume ✓');
    };
    $('resCancel').onclick = function () { $('resReview').hidden = true; $('resReview').innerHTML = ''; };
  }
  $('resFile').onchange = async function () {
    var file = this.files[0]; if (!file) return;
    $('resReview').hidden = false; $('resReview').innerHTML = '<p class="muted" style="margin:12px 0 0">Reading ' + esc(file.name) + '…</p>';
    try { var text = await FQResume.readFile(file); resShow(FQResume.parse(text)); }
    catch (e) { $('resReview').innerHTML = '<p style="margin:12px 0 0;color:var(--bad)">I couldn\'t read that file. ' + esc((e && e.message) || '') + ' Try "Paste text instead".</p>'; }
    this.value = '';
  };
  $('resPaste').onclick = function () { $('resPasteBox').hidden = !$('resPasteBox').hidden; if (!$('resPasteBox').hidden) $('resText').focus(); };
  $('resRead').onclick = function () { var t = $('resText').value; if (!t.trim()) { toast('Paste your resume text first.'); return; } resShow(FQResume.parse(t)); };
  $('hiddenSites').onclick = function (e) { var b = e.target.closest('[data-unhide]'); if (!b) return; S['fq.settings'].hiddenSites = S['fq.settings'].hiddenSites.filter(function (h) { return h !== b.dataset.unhide; }); save('fq.settings'); RENDER.settings(); };
  $('pwForm').onsubmit = async function (e) {
    e.preventDefault();
    if ($('pwNew').value !== $('pwNew2').value) { $('pwMsg').textContent = 'The two new passwords don\'t match.'; return; }
    $('pwBtn').disabled = true; $('pwMsg').textContent = 'Forging your key… (a few seconds on purpose, to slow down guessers)';
    var r = await send({ type: 'setPassword', password: $('pwNew').value, oldPassword: $('pwOld').value });
    $('pwBtn').disabled = false; $('pwMsg').textContent = r.ok ? 'Done! Your vault is locked with the new password, and unlocked for now.' : r.error;
    if (r.ok) { $('pwForm').reset(); refreshLock(); }
  };
  $('bkOut').onclick = async function () {
    var all = await chrome.storage.local.get(KEYS.concat(['fq.secure']));
    var blob = new Blob([JSON.stringify({ app: 'FormQuest', v: 1, saved: new Date().toISOString(), data: all }, null, 1)], { type: 'application/json' });
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'formquest-backup-' + new Date().toISOString().slice(0, 10) + '.json'; a.click();
  };
  $('bkIn').onchange = async function () {
    var f = this.files[0]; if (!f) return;
    try {
      var j = JSON.parse(await f.text()); if (j.app !== 'FormQuest' || !j.data) throw 0;
      if (!confirm('Replace everything in FormQuest with this backup?')) return;
      await chrome.storage.local.set(j.data); await send({ type: 'lock' }); location.reload();
    } catch (e) { toast('That file isn\'t a FormQuest backup.'); }
  };

  // ---------- start ----------
  var hash = location.hash.slice(1);
  if (hash === 'welcome') { $('welcome').hidden = false; $('welcomeGo').onclick = function () { $('welcome').hidden = true; showTab('hero'); }; }
  showTab(RENDER[hash] ? hash : 'hero');
  window.addEventListener('hashchange', function () { var h = location.hash.slice(1); if (RENDER[h]) showTab(h); });
  chrome.storage.onChanged.addListener(async function (ch, area) {
    if (area !== 'local') return;
    var touched = false;
    KEYS.forEach(function (k) { if (ch[k] && JSON.stringify(ch[k].newValue) !== JSON.stringify(S[k])) { S[k] = ch[k].newValue; touched = true; } });
    if (touched && document.activeElement && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { var t = document.querySelector('#tabs [aria-selected="true"]'); if (t) RENDER[t.dataset.t](); }
  });
})();
