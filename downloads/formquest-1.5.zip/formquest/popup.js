(async function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  function send(msg) { return new Promise(function (r) { chrome.runtime.sendMessage(msg, function (x) { void chrome.runtime.lastError; r(x); }); }); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var st = await chrome.storage.local.get(['fq.settings', 'fq.profiles', 'fq.quests']);
  var settings = st['fq.settings'] || {}, profiles = st['fq.profiles'] || { active: 'me', list: {} };
  document.documentElement.setAttribute('data-fq-theme', settings.theme || 'dungeon');
  var s = document.createElement('style'); s.textContent = self.NIB_CSS; document.head.appendChild(s);
  function mood(m) { $('nib').innerHTML = self.NibSVG(m, settings.theme || 'dungeon'); }
  mood('happy');

  $('profile').innerHTML = Object.keys(profiles.list).map(function (k) { return '<option value="' + k + '"' + (k === profiles.active ? ' selected' : '') + '>🛡 ' + esc(profiles.list[k].name) + '</option>'; }).join('');
  $('profile').onchange = async function () { profiles.active = this.value; await chrome.storage.local.set({ 'fq.profiles': profiles }); ping('refresh'); mood('cheer'); };

  var tabs = await chrome.tabs.query({ active: true, currentWindow: true }), tab = tabs[0];
  function ping(cmd) { if (tab) chrome.tabs.sendMessage(tab.id, { type: 'fq.cmd', cmd: cmd }, function () { void chrome.runtime.lastError; }); }
  function status() {
    return new Promise(function (r) {
      if (!tab) return r(null);
      chrome.tabs.sendMessage(tab.id, { type: 'fq.status' }, { frameId: 0 }, function (x) { void chrome.runtime.lastError; r(x || null); });
    });
  }
  var host = '';
  try { host = new URL(tab.url).hostname; } catch (e) { }
  var stt = await status();
  if (!stt) {
    $('counts').innerHTML = '<span class="muted">FormQuest can\'t work on this page (browser pages and the web store are off-limits). Try it on a website with a form.</span>';
    ['fill', 'auto', 'panel'].forEach(function (id) { $(id).disabled = true; });
    mood('sleepy');
  } else {
    $('counts').innerHTML = '<span class="tag good">' + stt.good + ' ready</span><span class="tag warn">' + stt.guess + ' guesses</span><span class="tag bad">' + stt.unknown + ' unknown</span>' + (stt.q ? '<span class="tag info">' + stt.q + ' new questions</span>' : '') + (stt.frames ? '<span class="tag good">+' + stt.frames + ' embedded</span>' : '');
    if (!stt.good && !stt.guess && !stt.frames) mood('sleepy');
  }
  var quests = (st['fq.quests'] || []).filter(function (q) { return host && (q.host === host || host.endsWith('.' + q.host)); });
  $('quests').innerHTML = quests.length ? '<div class="msg" style="margin-top:10px"><b>Quests for this site</b></div>' + quests.map(function (q) { return '<div class="q"><span>' + esc(q.name) + ' <small class="muted">' + q.steps.length + ' steps</small></span><button class="btn sm alt" data-q="' + q.id + '">▶ Run</button></div>'; }).join('') : '';
  $('quests').onclick = async function (e) {
    var b = e.target.closest('[data-q]'); if (!b) return;
    var q = quests.find(function (x) { return x.id === b.dataset.q; });
    await send({ type: 'run.set', tabId: tab.id, run: { mode: 'quest', questId: b.dataset.q, i: 0 } });
    if (q && q.url) chrome.tabs.update(tab.id, { url: q.url }); else chrome.tabs.reload(tab.id);
    window.close();
  };
  $('fill').onclick = function () { ping('fill'); mood('cheer'); $('pageMsg').textContent = 'Filling… watch the page.'; setTimeout(function () { window.close(); }, 700); };
  $('auto').onclick = async function () { await send({ type: 'run.set', tabId: tab.id, run: { mode: 'auto', pages: 0 } }); ping('auto'); window.close(); };
  $('panel').onclick = function () { chrome.tabs.sendMessage(tab.id, { type: 'fq.cmd', cmd: 'open' }, { frameId: 0 }, function () { void chrome.runtime.lastError; }); window.close(); };
  $('hall').onclick = function (e) { e.preventDefault(); chrome.runtime.openOptionsPage(); window.close(); };

  async function renderLock() {
    var ls = await send({ type: 'lockState' });
    if (!ls.hasPassword) {
      $('lockBody').innerHTML = '<p class="msg" style="margin:0 0 8px">Set a master password to store sensitive info like your SSN and VA file number, encrypted on this computer.</p><button class="btn alt" id="setpw">Set up in Guild Hall</button>';
      $('setpw').onclick = function () { send({ type: 'openVault', hash: '#settings' }); window.close(); };
    } else if (!ls.unlocked) {
      $('lockBody').innerHTML = '<form id="uf" class="row"><input class="inp" type="password" id="pw" placeholder="Master password" aria-label="Master password" autocomplete="current-password" style="flex:1"><button class="btn primary">🔓 Unlock</button></form><p class="msg err" id="lerr"></p>';
      $('uf').onsubmit = async function (e) {
        e.preventDefault(); var r = await send({ type: 'unlock', password: $('pw').value });
        if (r && r.ok) { mood('cheer'); ping('refresh'); renderLock(); } else { mood('worried'); $('lerr').textContent = (r && r.error) || 'Could not unlock.'; }
      };
      setTimeout(function () { $('pw').focus(); }, 50);
    } else {
      $('lockBody').innerHTML = '<div class="row"><span class="tag good">Unlocked</span><span class="muted" style="flex:1;font-size:12px">Locks itself after ' + (settings.autoLockMin || 30) + ' min</span><button class="btn sm ghost" id="lk">🔒 Lock</button></div>';
      $('lk').onclick = async function () { await send({ type: 'lock' }); ping('refresh'); renderLock(); };
    }
  }
  renderLock();
  try { $('ver').textContent = 'v' + chrome.runtime.getManifest().version + ' · Alt+Shift+F fills'; } catch (e) { }
})();
