/* FormQuest · on-page UI: the badge, preview, teach, the recording panel, and the quest runner.
   The recorder itself lives in recorder.js and runs in every frame; this file shows what it heard and replays it. */
(function () {
  'use strict';
  if (window.__formquestUI) return;
  window.__formquestUI = true;
  var FQ = self.FQ, E = window.FQE;
  var TOP = window === window.top;
  var HOST = location.hostname;
  var ctx = null, items = [], shadow = null, rootEl = null, state = { open: false, preview: false, teach: false, busy: false };
  var frameCounts = {}, recFeed = [], VER = ''; try { VER = chrome.runtime.getManifest().version.replace(/\.0$/, ''); } catch (e) { }
  window.FQUI = { ctx: function () { return ctx; } };       // the recorder reads your profile through this
  var unloading = false;
  window.addEventListener('beforeunload', function () { unloading = true; });
  window.addEventListener('pagehide', function () { unloading = true; });

  function send(msg) { return new Promise(function (res) { try { chrome.runtime.sendMessage(msg, function (r) { void chrome.runtime.lastError; res(r); }); } catch (e) { res(null); } }); }
  async function loadCtx() { ctx = await send({ type: 'getCtx', host: HOST }); return ctx; }
  function theme() { return (ctx && ctx.settings && ctx.settings.theme) || 'dungeon'; }

  // ---------- sounds (tiny, optional) ----------
  var AC = null;
  function blip(kind) {
    if (!ctx || !ctx.settings || ctx.settings.sound === false) return;
    try {
      AC = AC || new (window.AudioContext || window.webkitAudioContext)();
      var notes = { fill: [660, 880], clear: [523, 659, 784, 1046], pause: [440, 330], tick: [990] }[kind] || [700];
      notes.forEach(function (f, i) {
        var o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime + i * .08;
        o.type = 'square'; o.frequency.value = f; g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.05, t + .01); g.gain.exponentialRampToValueAtTime(.0001, t + .12);
        o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + .14);
      });
    } catch (e) { }
  }

  // ---------- UI shell ----------
  var CSS = [
    ':host{all:initial}',
    '*{box-sizing:border-box;font-family:"M PLUS Rounded 1c","Segoe UI",system-ui,-apple-system,sans-serif}',
    '.t-dungeon{--bg:#0f0b1e;--sf:#19132f;--sf2:#231a42;--ln:#54438f;--ink:#efe9ff;--ink2:#c3b8e6;--ink3:#8f84b8;--ac:#ffc84a;--aci:#1d1400;--ac2:#8a5cff;--ac2i:#fff;--sh:#8a5cff;--edge:#0a0716}',
    '.t-yami{--bg:#06050b;--sf:#0e0b18;--sf2:#171227;--ln:#3d3163;--ink:#ece6f7;--ink2:#b3a8cc;--ink3:#8277a0;--ac:#ff2e6e;--aci:#12030a;--ac2:#8f7bff;--ac2i:#0b0816;--sh:#ff2e6e;--edge:#000}',
    '.t-neon{--bg:#050e16;--sf:#0b1a26;--sf2:#10263a;--ln:#27597e;--ink:#e6fbff;--ink2:#a9d6e6;--ink3:#6f9fb4;--ac:#2ff3e0;--aci:#02201d;--ac2:#ff4fd8;--ac2i:#22021c;--sh:#ff4fd8;--edge:#000}',
    '.t-parchment{--bg:#f3e7cc;--sf:#fffaf0;--sf2:#f7ecd4;--ln:#c4a56d;--ink:#2a1f14;--ink2:#5a4632;--ink3:#86705a;--ac:#b5452f;--aci:#fff6ea;--ac2:#3f6fb0;--ac2i:#fff;--sh:#2a1f14;--edge:#2a1f14}',
    '.wrap{position:fixed;right:18px;bottom:18px;z-index:2147483646;display:flex;flex-direction:column;align-items:flex-end;gap:10px;color:var(--ink)}',
    '.wrap.at-l{align-items:flex-start}.wrap.at-t{flex-direction:column-reverse}.wrap.dragging{opacity:.92}.wrap.dragging .pill{cursor:grabbing;box-shadow:6px 6px 0 var(--sh)}',
    '.pill .grip{font:800 13px/1 inherit;color:var(--ink3);letter-spacing:-2px;margin-left:2px}',
    '.hd{cursor:move;touch-action:none}',
    '.pill{touch-action:none;display:flex;align-items:center;gap:8px;background:var(--sf);border:2.5px solid var(--edge);border-radius:999px;box-shadow:3px 3px 0 var(--sh);padding:4px 14px 4px 4px;cursor:pointer;color:var(--ink);font:800 13px/1 inherit}',
    '.pill:hover{filter:brightness(1.1)}',
    '.pill .nib{width:40px;height:44px;margin:-8px 0 -4px}',
    '.pill b{font-family:"Dela Gothic One","Arial Black",sans-serif;font-weight:400;font-size:13px;letter-spacing:.03em}',
    '.pill .n{background:var(--ac);color:var(--aci);border-radius:999px;padding:2px 8px;font-size:12px}',
    '.pill.rec .n{background:#ff3b5c;color:#fff;animation:blink 1s infinite}',
    '@keyframes blink{50%{opacity:.4}}',
    '.panel{width:330px;max-height:min(560px,80vh);overflow:auto;background:var(--sf);border:2.5px solid var(--edge);border-radius:8px;box-shadow:5px 5px 0 var(--sh);padding:12px 14px 14px;background-image:radial-gradient(color-mix(in srgb,var(--ac2) 12%,transparent) 1px,transparent 1.4px);background-size:7px 7px}',
    '.hd{display:flex;align-items:center;gap:8px}',
    '.hd h2{margin:0;font-family:"Dela Gothic One","Arial Black",sans-serif;font-weight:400;font-size:17px;flex:1;letter-spacing:.02em}',
    '.hd h2 i{font-style:normal;color:var(--ac)}',
    '.x{border:0;background:none;color:var(--ink3);font-size:18px;cursor:pointer;padding:2px 6px}',
    '.hero{display:flex;gap:10px;align-items:flex-end;margin:6px 0 10px}',
    '.hero .nib{width:74px;height:80px;flex:none}',
    '.say{position:relative;flex:1;background:#fff;color:#1d1633;border:2.5px solid #1d1633;border-radius:12px;padding:8px 10px;font:600 12.5px/1.4 inherit;box-shadow:3px 3px 0 var(--ac);margin-bottom:14px}',
    '.say:after{content:"";position:absolute;left:-12px;bottom:10px;border:6px solid transparent;border-right:9px solid #1d1633}',
    '.counts{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 10px}',
    '.c{font:800 11.5px/1 inherit;border-radius:999px;padding:4px 9px;border:1.5px solid currentColor}',
    '.c.g{color:#53e08a}.c.y{color:#ffd24a}.c.r{color:#ff5f7e}.c.p{color:#b89bff}',
    '.t-parchment .c.g{color:#2f8a4f}.t-parchment .c.y{color:#a06a00}.t-parchment .c.r{color:#b5302f}.t-parchment .c.p{color:#6b3fb0}',
    '.btns{display:grid;grid-template-columns:1fr 1fr;gap:8px}',
    '.b{display:flex;align-items:center;justify-content:center;gap:6px;font:800 12.5px/1.2 inherit;color:var(--ink);background:var(--sf2);border:2px solid var(--edge);border-radius:7px;box-shadow:2px 2px 0 var(--edge);padding:8px 8px;cursor:pointer}',
    '.b:hover{filter:brightness(1.15)}.b:active{transform:translate(2px,2px);box-shadow:none}',
    '.b.big{grid-column:1/-1;font-size:14px;padding:10px}',
    '.b.pri{background:var(--ac);color:var(--aci)}.b.alt{background:var(--ac2);color:var(--ac2i)}',
    '.b.on{outline:2px solid var(--ac);outline-offset:1px}',
    '.b:focus-visible,.x:focus-visible,.pill:focus-visible{outline:3px solid var(--ac2);outline-offset:2px}',
    '.sec{margin-top:12px;border-top:2px dashed var(--ln);padding-top:10px}',
    '.sec h3{margin:0 0 6px;font-size:11px;font-weight:800;line-height:1;letter-spacing:.12em;text-transform:uppercase;color:var(--ac)}',
    '.q{display:flex;align-items:center;gap:8px;margin:0 0 6px}',
    '.q span{flex:1;font-size:12.5px;font-weight:700}',
    '.q small{color:var(--ink3);font-weight:600}',
    '.note{font-size:12px;color:var(--ink2);margin:8px 0 0;line-height:1.4}',
    '.lock{background:color-mix(in srgb,var(--ac) 16%,transparent);border:1.5px solid var(--ac);border-radius:6px;padding:6px 8px;font-size:12px;margin-top:8px}',
    '.xp{height:10px;border:2px solid var(--edge);border-radius:6px;background:var(--bg);overflow:hidden;margin-top:10px}',
    '.xp i{display:block;height:100%;width:0;background:repeating-linear-gradient(45deg,var(--ac) 0 8px,color-mix(in srgb,var(--ac) 70%,#fff) 8px 16px);transition:width .2s}',
    '.small{font-size:11.5px;color:var(--ink3)}',
    '.feed{margin:0;padding:0 0 0 2px;list-style:none;font-size:12px;color:var(--ink2);display:flex;flex-direction:column;gap:3px}',
    '.feed li{display:flex;gap:6px}.feed li:before{content:"\\2713";color:#3ddc84;font-weight:800}.feed li:last-child{color:var(--ink);font-weight:700}',
    'a.link{color:var(--ac2);cursor:pointer;text-decoration:underline;font-size:12px}',
    'input.in{width:100%;font:13px/1.3 inherit;color:var(--ink);background:var(--bg);border:2px solid var(--ln);border-radius:6px;padding:6px 8px}',
    '.layer{position:absolute;left:0;top:0;width:0;height:0;z-index:2147483645;pointer-events:none}',
    '.box{position:absolute;border:2.5px solid;border-radius:5px;pointer-events:none}',
    '.box.good{border-color:#3ddc84;box-shadow:0 0 0 2px rgba(61,220,132,.25)}.box.guess{border-color:#ffd24a;box-shadow:0 0 0 2px rgba(255,210,74,.25)}.box.unknown{border-color:#ff5f7e;box-shadow:0 0 0 2px rgba(255,95,126,.25)}.box.skip{border-color:#8f84b8;border-style:dashed}.box.q{border-color:#b89bff}',
    '.box.done{background:rgba(61,220,132,.10)}',
    '.tagx{position:absolute;left:-2px;top:-19px;white-space:nowrap;font:800 10.5px/1 "M PLUS Rounded 1c",system-ui,sans-serif;color:#10091e;padding:3px 6px;border-radius:5px 5px 5px 0;pointer-events:auto;cursor:pointer;border:1.5px solid #10091e}',
    '.good .tagx{background:#3ddc84}.guess .tagx{background:#ffd24a}.unknown .tagx{background:#ff5f7e;color:#fff}.skip .tagx{background:#bdb3dd}.q .tagx{background:#b89bff}',
    '.pop{position:fixed;z-index:2147483647;width:300px;max-height:420px;display:flex;flex-direction:column;background:var(--sf);color:var(--ink);border:2.5px solid var(--edge);border-radius:8px;box-shadow:5px 5px 0 var(--sh);padding:10px 12px;pointer-events:auto}',
    '.pop h4{margin:0 0 2px;font-family:"Dela Gothic One","Arial Black",sans-serif;font-weight:400;font-size:14px}',
    '.pop .ft{font-size:12px;color:var(--ink2);margin:0 0 8px;max-height:48px;overflow:auto;flex:none}','.pop .hd,.pop input{flex:none}',
    '.opts{overflow:auto;flex:1;margin-top:8px;display:flex;flex-direction:column;gap:2px;min-height:80px}',
    '.opt{all:unset;cursor:pointer;padding:5px 8px;border-radius:5px;font-size:12.5px;font-weight:600;color:var(--ink);display:flex;justify-content:space-between;gap:8px}',
    '.opt:hover,.opt:focus-visible{background:var(--sf2);outline:none}',
    '.opt small{color:var(--ink3);font-weight:600}',
    '.og{font:800 10.5px/1 inherit;letter-spacing:.1em;text-transform:uppercase;color:var(--ac);margin:8px 0 3px}',
    '.burst{position:fixed;inset:0;z-index:2147483647;pointer-events:none;display:grid;place-items:center;background:repeating-conic-gradient(from 0deg at 50% 50%,rgba(255,255,255,.35) 0deg 2.5deg,transparent 2.5deg 9deg);animation:bf .9s ease-out forwards}',
    '.burst b{font-family:"Dela Gothic One","Arial Black",sans-serif;font-weight:400;font-size:64px;color:#fff;-webkit-text-stroke:3px #1d1633;paint-order:stroke fill;text-shadow:5px 5px 0 var(--ac);transform:rotate(-6deg)}',
    '@keyframes bf{0%{opacity:0}15%{opacity:1}100%{opacity:0}}',
    '@media (prefers-reduced-motion:reduce){.burst{display:none}.pill.rec .n{animation:none}}',
    self.NIB_CSS
  ].join('\n');

  function ensureShell() {
    if (shadow) return;
    rootEl = document.createElement('div');
    rootEl.id = 'formquest-root';
    rootEl.setAttribute('data-fq-ui', '');
    (document.body || document.documentElement).appendChild(rootEl);
    shadow = rootEl.attachShadow({ mode: 'closed' });
    shadow.innerHTML = '<style>' + CSS + '</style><div class="layer" id="layer"></div><div class="wrap" id="wrap"></div><div id="pops"></div>';
    shadow.getElementById('wrap').addEventListener('click', onClick);
    shadow.getElementById('wrap').addEventListener('pointerdown', onDragDown);
    window.addEventListener('pointermove', onDragMove, true);
    window.addEventListener('pointerup', onDragUp, true);
    window.addEventListener('pointercancel', onDragUp, true);
    window.addEventListener('resize', applyPos);
    loadPos();
    shadow.getElementById('layer').addEventListener('click', onLayerClick);
    shadow.getElementById('pops').addEventListener('click', onPopClick);
    shadow.getElementById('pops').addEventListener('input', onPopInput);
  }
  function $(id) { return shadow.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function setTheme() { if (shadow) ['wrap', 'layer', 'pops'].forEach(function (id) { $(id).className = (id === 'wrap' ? 'wrap ' : id === 'layer' ? 'layer ' : '') + 't-' + theme(); }); }

  function counts() {
    var c = { good: 0, guess: 0, unknown: 0, q: 0 };
    items.forEach(function (it) { if (it.state === 'good') c.good++; else if (it.state === 'guess') c.guess++; else if (it.state === 'unknown') { if (it.newQuestion) c.q++; else c.unknown++; } });
    return c;
  }
  function known() { var c = counts(); return c.good + c.guess; }
  function totalKnown() { var n = known(); for (var k in frameCounts) n += frameCounts[k]; return n; }

  var sayText = '', nibMood = 'happy', progress = -1;
  function nib(mood, size) { return '<div class="nib" style="width:' + size[0] + 'px;height:' + size[1] + 'px">' + self.NibSVG(mood, theme()) + '</div>'; }

  function render() {
    if (!TOP) return;
    ensureShell(); setTheme(); applyPos();
    var rec = ctx && ctx.rec, c = counts(), n = totalKnown();
    var quests = (ctx && ctx.quests) || [];
    var html = '';
    if (state.open) {
      var lockMsg = ctx && ctx.locked && ctx.hasSecure ? '<div class="lock">🔒 Your vault is locked, so SSN and VA file number boxes will be skipped. Unlock it from the FormQuest button in your toolbar.</div>' : '';
      var qs = quests.length ? '<div class="sec"><h3>Quests for this site</h3>' + quests.map(function (q) {
        return '<div class="q"><span>' + esc(q.name) + ' <small>· ' + q.steps.length + ' steps</small></span><button class="b" data-act="runq" data-id="' + esc(q.id) + '">▶ Run</button></div>';
      }).join('') + '</div>' : '';
      html += '<div class="panel" role="dialog" aria-label="FormQuest">' +
        '<div class="hd"><h2>Form<i>Quest</i></h2><span class="small">v' + VER + ' · ' + esc(ctx && ctx.profileName || '') + '</span><button class="x" data-act="close" aria-label="Close">✕</button></div>' +
        '<div class="hero">' + nib(nibMood, [74, 80]) + '<div class="say" id="say">' + esc(sayText || greeting()) + '</div></div>' +
        '<div class="counts"><span class="c g">' + c.good + ' ready</span><span class="c y">' + c.guess + ' guesses</span><span class="c r">' + c.unknown + ' unknown</span>' + (c.q ? '<button class="c p" data-act="answers" style="background:none;cursor:pointer" title="Answer them in the Guild Hall">' + c.q + ' questions to answer ›</button>' : '') + (Object.keys(frameCounts).length ? '<span class="c g">+' + (n - known()) + ' in embedded forms</span>' : '') + '</div>' +
        (rec ? '<div class="btns"><button class="b big alt" data-act="recstop">■ Stop and save quest (' + (rec.steps || 0) + ' steps)</button><button class="b" data-act="recundo"' + (rec.steps ? '' : ' disabled') + '>↶ Undo last step</button><button class="b" data-act="reccancel">Cancel recording</button></div>' +
          '<div class="sec"><h3>Recorded so far</h3>' + (recFeed.length ? '<ol class="feed">' + recFeed.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ol>' : '<p class="note" style="margin:0">Nothing yet. Each thing you do flashes green on the page and lands here.</p>') + '</div>'
          : '<div class="btns">' +
          '<button class="b big pri" data-act="fill">▶ Fill this page</button>' +
          '<button class="b" data-act="auto" title="Fill each page and press Next until the end">⏩ Fill &amp; continue</button>' +
          '<button class="b' + (state.preview ? ' on' : '') + '" data-act="preview">👁 Preview</button>' +
          '<button class="b' + (state.teach ? ' on' : '') + '" data-act="teach">✎ Teach</button>' +
          '<button class="b" data-act="rec">⏺ Record quest</button>' +
          '</div>') +
        (state.count ? '<div class="btns" style="margin-top:8px"><button class="b big alt" data-act="hold">✋ Hold it! (' + state.count.n + ')</button></div>' : '') +
        (state.paused ? '<div class="btns" style="margin-top:8px"><button class="b big pri" data-act="resume">▶ Continue</button><button class="b" data-act="stoprun">Stop</button></div>' : '') +
        (progress >= 0 ? '<div class="xp" aria-hidden="true"><i id="xp" style="width:' + progress + '%"></i></div>' : '') +
        lockMsg + qs +
        '<p class="note">' + (rec ? 'If something you did does not flash green and show up above, it was not recorded. Tell me which site and I can fix it.' : state.teach ? 'Teach mode: click any box on the page, or its tag, and tell me what it is.' : (finalMode() === 'stop' ? 'In a quest I stop before Submit, Sign or Pay.' : 'In a quest I press Submit if you recorded it' + (finalMode() === 'count' ? ', after a 3-second countdown' : '') + '.') + ' Hotkey: Alt+Shift+F fills the page.') + '</p>' +
        '<div class="row small" style="margin-top:8px;display:flex;justify-content:space-between"><a class="link" data-act="hide">Don\'t show on this site</a>' + (POS ? '<a class="link" data-act="resetpos">Move me back to the corner</a>' : '') + '<a class="link" data-act="vault">Open Guild Hall</a></div>' +
        '</div>';
    }
    var label = rec ? 'REC' : n ? n + ' ready' : 'Teach me';
    html += '<button class="pill' + (rec ? ' rec' : '') + '" data-act="toggle" aria-expanded="' + state.open + '" aria-label="FormQuest, ' + label + '. Drag to move." title="Click to open · drag to move anywhere">' + nib(rec ? 'ready' : n ? 'happy' : 'sleepy', [40, 44]) + '<b>FormQuest</b><span class="n">' + label + '</span><span class="grip" aria-hidden="true">⋮⋮</span></button>';
    $('wrap').innerHTML = html;
  }
  function greeting() {
    var c = counts();
    if (!items.length) return "No form boxes on this page yet. When one shows up, I'm ready.";
    if (!c.good && !c.guess) return "I don't recognize these boxes yet. Use Teach and I'll remember them for this site.";
    return 'I know ' + (c.good + c.guess) + ' of ' + items.length + ' boxes here' + (c.unknown ? ', and ' + c.unknown + ' are new to me' : '') + '. Ready when you are!';
  }
  function say(text, mood) { sayText = text; if (mood) nibMood = mood; if (shadow && $('say')) { render(); } }

  function burst(text) {
    if (!shadow) return;
    var b = document.createElement('div'); b.className = 'burst t-' + theme(); b.innerHTML = '<b>' + esc(text) + '</b>';
    shadow.appendChild(b); setTimeout(function () { b.remove(); }, 950);
  }

  // ---------- preview overlay ----------
  var raf = 0;
  function tagText(it) {
    if (it.state === 'skip') return 'skip';
    if (it.answerId) { var a = (ctx.answers || []).find(function (x) { return x.id === it.answerId; }); return 'Q: ' + (a ? a.q.slice(0, 24) + (a.a ? '' : '… · needs answer') : 'answer'); }
    if (it.literal != null) return '"' + String(it.literal).slice(0, 18) + '"';
    if (it.key) { var f = FQ.BY_KEY[it.key]; return (f ? f.label : it.key) + (it.partCount ? ' ' + (it.partIndex + 1) + '/' + it.partCount : '') + (it.datePart ? ' (' + it.datePart + ')' : ''); }
    return it.newQuestion ? 'New question?' : '? teach me';
  }
  function drawLayer() {
    if (!shadow) return;
    var layer = $('layer');
    if (!(state.preview || state.teach)) { layer.innerHTML = ''; return; }
    var sx = window.scrollX, sy = window.scrollY, html = '';
    items.forEach(function (it, i) {
      var el = it.kind === 'radio' ? (it.options[0].closest('fieldset,[role="radiogroup"]') || it.options[0].parentElement) : it.el;
      if (!el || !el.isConnected) return;
      var r = el.getBoundingClientRect(); if (r.width < 2) { var lab = it.el.labels && it.el.labels[0]; if (lab) r = lab.getBoundingClientRect(); }
      if (r.width < 2) return;
      var cls = it.state === 'unknown' && it.newQuestion ? 'q' : it.state;
      html += '<div class="box ' + cls + (it.done ? ' done' : '') + '" style="left:' + (r.left + sx - 3) + 'px;top:' + (r.top + sy - 3) + 'px;width:' + (r.width + 6) + 'px;height:' + (r.height + 6) + 'px"><span class="tagx" data-i="' + i + '" title="Click to teach">' + esc(tagText(it)) + '</span></div>';
    });
    layer.innerHTML = html;
  }
  function loopLayer() { cancelAnimationFrame(raf); if (!(state.preview || state.teach)) { drawLayer(); return; } var last = ''; (function tick() { var k = window.scrollX + ',' + window.scrollY + ',' + innerWidth + ',' + innerHeight + ',' + items.length; if (k !== last) { last = k; drawLayer(); } raf = requestAnimationFrame(tick); })(); }
  function onLayerClick(e) { var t = e.target.closest('.tagx'); if (!t) return; e.preventDefault(); e.stopPropagation(); openTeach(items[+t.dataset.i]); }

  // ---------- teach popover ----------
  var teachItem = null;
  function openTeach(it) {
    if (!it) return;
    teachItem = it;
    var r = (it.kind === 'radio' ? it.options[0] : it.el).getBoundingClientRect();
    var left = Math.min(innerWidth - 316, Math.max(8, r.left)), top = r.bottom + 8 > innerHeight - 330 ? Math.max(8, r.top - 430) : r.bottom + 8;
    var groups = FQ.GROUPS.map(function (g) {
      var fs = FQ.FIELDS.filter(function (f) { return f.g === g[0]; });
      return fs.length ? '<div class="og">' + esc(g[1]) + '</div>' + fs.map(function (f) { return '<button class="opt" data-key="' + f.k + '" data-s="' + esc((f.label + ' ' + f.k).toLowerCase()) + '">' + esc(f.label) + '<small>' + esc(valuePreview(f.k)) + '</small></button>'; }).join('') : '';
    }).join('');
    var ans = (ctx.answers || []).map(function (a) { return '<button class="opt" data-ans="' + esc(a.id) + '" data-s="' + esc(a.q.toLowerCase()) + '">' + esc(a.q) + '<small>' + esc(a.a || 'no answer yet') + '</small></button>'; }).join('');
    var q = it.question || it.text || '';
    $('pops').className = 't-' + theme();
    $('pops').innerHTML = '<div class="pop" role="dialog" aria-label="Teach this box" style="left:' + left + 'px;top:' + top + 'px">' +
      '<div class="hd"><h4>What is this box?</h4><button class="x" data-act="pclose" aria-label="Close">✕</button></div>' +
      '<p class="ft">' + esc(q || '(no label)') + '</p>' +
      '<input class="in" id="tq" placeholder="Search: phone, zip, veteran…" aria-label="Search">' +
      '<div class="opts" id="topts">' +
      '<div class="og">Quick</div><button class="opt" data-act="skipbox">Skip this box on this site<small>never fill</small></button>' +
      '<button class="opt" data-act="literal">Always type exact text…<small>for this site</small></button>' +
      '<button class="opt" data-act="newq">Save as a screening question…<small>answer bank</small></button>' +
      groups + '<div class="og">Answer bank</div>' + ans + '</div></div>';
    setTimeout(function () { var i = $('tq'); if (i) i.focus(); }, 30);
  }
  function valuePreview(k) {
    var f = FQ.BY_KEY[k]; if (f && f.secure) return '🔒';
    var v = FQ.resolve(k, ctx.data, ctx); v = v == null ? '' : String(v);
    return v ? (v.length > 16 ? v.slice(0, 15) + '…' : v) : 'empty';
  }
  function closePop() { teachItem = null; if (shadow) $('pops').innerHTML = ''; }
  function onPopInput(e) {
    if (e.target.id !== 'tq') return;
    var q = e.target.value.toLowerCase().trim();
    shadow.querySelectorAll('#topts .opt[data-s]').forEach(function (o) { o.hidden = q && o.dataset.s.indexOf(q) < 0; });
  }
  async function saveRule(rule, msg) {
    var it = teachItem;
    await send({ type: 'saveRule', host: HOST, sig: it.sig, rule: rule });
    if (it.partCount) {       // teach the whole split group at once
      items.filter(function (x) { return x.partCount && x.key === it.key && x !== it; }).forEach(function (x) { send({ type: 'saveRule', host: HOST, sig: x.sig, rule: rule }); });
    }
    closePop(); await loadCtx(); rescan();
    say(msg || 'Got it! I\'ll remember that box on ' + HOST + '.', 'cheer'); blip('tick');
  }
  function onPopClick(e) {
    var b = e.target.closest('button'); if (!b) return;
    if (b.dataset.act === 'pclose') return closePop();
    if (!teachItem) return;
    if (b.dataset.key) return saveRule({ key: b.dataset.key });
    if (b.dataset.ans) return saveRule({ answer: b.dataset.ans });
    if (b.dataset.act === 'skipbox') return saveRule({ skip: true }, "Okay, I'll leave that one alone.");
    if (b.dataset.act === 'literal') {
      var v = prompt('What should FormQuest always type in this box on ' + HOST + '?');
      if (v != null) saveRule({ value: v });
      return;
    }
    if (b.dataset.act === 'newq') {
      var q = teachItem.question || teachItem.text || '';
      var a = prompt('Your answer to:\n"' + q + '"\n\n(For multiple choice, type the choice text, like "Yes")');
      if (a == null) return;
      send({ type: 'addAnswer', q: q, a: a }).then(function (r) { if (r && r.id) saveRule({ answer: r.id }, 'Added to your answer bank. Next time, I\'ll answer it anywhere I see it.'); });
    }
  }

  // ---------- scanning ----------
  var scanT = 0;
  function rescan() {
    if (!ctx) return;
    items = E.scan({ rules: ctx.rules, answers: ctx.answers, data: ctx.data, timesheet: ctx.timesheet });
    watchRoots();
    if (!TOP) { send({ type: 'frameCount', n: items.filter(function (i) { return i.state === 'good' || i.state === 'guess'; }).length }); return; }
    if (shouldShow()) render(); else if (shadow && !state.open) $('wrap').innerHTML = '';
    if (state.preview || state.teach) drawLayer();
  }
  function shouldShow() {
    if (!ctx || !ctx.settings) return false;
    if (ctx.hidden) return state.open;
    if (ctx.settings.badge === false) return state.open;
    return state.open || !!ctx.rec || totalKnown() >= 2 || (ctx.quests && ctx.quests.length) || items.filter(function (i) { return i.kind !== 'checkbox'; }).length >= 3;
  }
  var mo = new MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      var m = muts[i], t = m.target; if (rootEl && (t === rootEl || rootEl.contains(t))) continue;
      if (m.type === 'childList' && Array.prototype.every.call(m.addedNodes, isOurs) && Array.prototype.every.call(m.removedNodes, isOurs)) continue;
      clearTimeout(scanT); scanT = setTimeout(rescan, 700); return;
    }
  });
  function isOurs(n) { return n.nodeType === 1 && n.hasAttribute('data-fq-ui'); }
  var MO_OPT = { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class', 'hidden', 'aria-hidden'] }, seenRoots = new WeakSet();
  function watchRoots() { E.roots().forEach(function (r) { if (!seenRoots.has(r)) { seenRoots.add(r); try { mo.observe(r, MO_OPT); } catch (e) { } } }); }

  // ---------- actions ----------
  async function fillPage(opts) {
    opts = opts || {};
    await loadCtx(); rescan();
    if (!items.length) return { filled: 0 };
    state.busy = true; progress = 0; say('Filling… ⚔', 'ready');
    var res = await E.fillItems(items, {
      data: ctx.data, answers: ctx.answers, timesheet: ctx.timesheet, weekEndDay: ctx.settings.weekEndDay, overwrite: !!(opts.overwrite || ctx.settings.overwrite), pace: 30,
      onStep: function (i, n) { progress = Math.round(i / n * 100); var x = shadow && $('xp'); if (x) x.style.width = progress + '%'; }
    });
    state.busy = false; progress = -1;
    var newQs = items.filter(function (it) { return it.newQuestion && !it.done; });
    newQs.slice(0, 6).forEach(function (it) { send({ type: 'flagQuestion', q: it.question || it.text, host: HOST }); });
    var missing = res.missing.length ? ' ' + res.missing.length + ' boxes need info you haven\'t saved yet.' : '';
    var unsure = res.unsure || [], fails = (res.failed || []).filter(function (it) { return it.kind === 'combo' || it.kind === 'typeahead' || it.kind === 'select'; });
    if (unsure.length) { missing += ' ' + unsure.length + ' dropdown' + (unsure.length > 1 ? 's' : '') + ' had no exact match, so I took the closest one. I outlined ' + (unsure.length > 1 ? 'them' : 'it') + ' in yellow; give ' + (unsure.length > 1 ? 'them' : 'it') + ' a look.'; unsure.forEach(function (it) { flash(it.el); }); }
    if (fails.length) { missing += ' ' + fails.length + ' dropdown' + (fails.length > 1 ? 's have' : ' has') + ' nothing that matches your info, so ' + (fails.length > 1 ? 'those are' : 'that one is') + ' yours.'; fails.forEach(function (it) { flash(it.el); }); }
    if (TOP || res.filled) send({ type: 'log', entry: { host: HOST, title: document.title.slice(0, 80), filled: res.filled, mode: opts.mode || 'fill' } });
    if (TOP) {
      rescan();
      if (res.filled) { blip('fill'); say('Filled ' + res.filled + ' boxes!' + missing + (res.kept ? ' I left ' + res.kept + ' that already had text.' : ''), 'cheer'); }
      else say(res.kept ? 'Everything I know here is already filled in.' + missing : 'Nothing to fill that I know yet.' + missing + ' Try Teach.', res.kept ? 'happy' : 'worried');
    }
    return res;
  }

  // ---------- Fill & continue (no recording needed) ----------
  function sigSet() { return items.map(function (i) { return i.sig; }).sort().join('~'); }
  function requiredEmpty() {
    return items.filter(function (it) {
      var el = it.el; if (it.state === 'skip' && it.kind !== 'checkbox') return false;
      var req = el.required || el.getAttribute('aria-required') === 'true';
      if (!req) return false;
      if (it.kind === 'checkbox') return !el.checked;
      if (it.kind === 'radio') return !it.options.some(function (o) { return o.checked; });
      if (it.kind === 'combo' || it.kind === 'select') return !E.hasValue(it);
      return !(el.isContentEditable ? E.txt(el) : el.value);
    });
  }
  // a last look before a final button: anything required still empty, anything the site is flagging?
  function preflight() {
    try { rescan(); } catch (e) { }
    return { need: requiredEmpty().length, invalid: E.qsa('[aria-invalid="true"]').filter(E.visible).length };
  }
  function finalMode() { return (ctx && ctx.settings && ctx.settings.finalMode) || 'count'; }
  // "Pressing Submit in 3…" with a way to stop it. → true to go ahead
  function countdown(label) {
    return new Promise(function (res) {
      var n = 3, t = 0;
      function done(v) { clearInterval(t); document.removeEventListener('keydown', esc2, true); state.count = null; render(); res(v); }
      function esc2(e) { if (e.key === 'Escape') done(false); }
      function tick() { state.count = { label: label, n: n, hold: function () { done(false); } }; state.open = true; sayText = 'Everything is filled in. Pressing "' + label + '" in ' + n + '…'; nibMood = 'ready'; render(); blip('tick'); }
      document.addEventListener('keydown', esc2, true);
      tick(); t = setInterval(function () { n--; if (n <= 0) done(true); else tick(); }, 1000);
    });
  }
  async function autoLoop() {
    var run = await send({ type: 'run.get' });
    if (!run || run.mode !== 'auto') return;
    open(true);
    var blk = E.blocker();
    if (blk) return pauseRun(blk === 'captcha' ? 'A robot check is on this page. Solve it, then press Continue.' : 'This page wants you to log in. Sign in, then press Continue.');
    var before = location.href + '|' + sigSet();
    await fillPage({ mode: 'auto' });
    broadcast('fillFrames');
    await E.wait(600);
    var need = requiredEmpty();
    if (need.length) return pauseRun(need.length + ' required box' + (need.length > 1 ? 'es need' : ' needs') + ' you. Fill ' + (need.length > 1 ? 'them' : 'it') + ', then press Continue.', need);
    var btn = E.findNext();
    for (var w0 = 0; w0 < 14 && !btn.next && !btn.final; w0++) { await E.wait(300); btn = E.findNext(); }   // some sites enable Next only after checking the page
    if (!btn.next) {
      await send({ type: 'run.clear' });
      if (btn.final) {
        var flabel = E.labelOfButton(btn.final).slice(0, 30);
        btn.final.scrollIntoView({ block: 'center' }); flash(btn.final);
        if (ctx.settings.autoSubmit) {
          var pf = preflight();
          if (pf.invalid) return say('Last page, but the site is flagging ' + pf.invalid + ' box' + (pf.invalid > 1 ? 'es' : '') + '. Fix that, then press "' + flabel + '" yourself.', 'worried');
          if (await countdown(flabel)) {
            var markF = E.pageMark(); E.human(btn.final);
            send({ type: 'log', entry: { host: HOST, title: document.title.slice(0, 80), filled: 0, mode: 'auto', quest: 'Pressed "' + flabel + '"' } });
            for (var w = 0; w < 40 && !unloading && E.pageMark() === markF; w++) await E.wait(250);
            blip('clear'); burst('SUBMITTED!'); return say('I pressed "' + flabel + '". Check the page to make sure it went through.', 'cheer');
          }
          return say('Held. Press "' + flabel + '" yourself when you\'re ready.', 'happy');
        }
        blip('clear'); burst('QUEST CLEAR!'); return say('Last page! Review everything, then press "' + flabel + '" yourself. (You can let me press it: Guild Hall, Settings.)', 'cheer');
      }
      return say("I don't see a Next button. I filled what I could on this page.", 'happy');
    }
    if (run.pages >= 25) { await send({ type: 'run.clear' }); return say('That was 25 pages, so I stopped to be safe.', 'worried'); }
    await send({ type: 'run.set', run: { mode: 'auto', pages: (run.pages || 0) + 1 } });
    say('Page ' + ((run.pages || 0) + 1) + ' done. On to the next! ⏩', 'ready');
    await E.wait(350);
    E.human(btn.next);
    // single-page apps: wait for the page to change, then keep going here
    for (var i = 0; i < 40; i++) {
      await E.wait(250);
      items = E.scan({ rules: ctx.rules, answers: ctx.answers, data: ctx.data, timesheet: ctx.timesheet });
      if (location.href + '|' + sigSet() !== before) { await E.wait(700); return autoLoop(); }
    }
    var errs = document.querySelectorAll('[aria-invalid="true"],.error:not(:empty),[role="alert"]:not(:empty)');
    await send({ type: 'run.clear' });
    say(errs.length ? 'The site says something needs fixing. I highlighted it; fix it and run Fill & continue again.' : 'The page didn\'t change after Next. Check it, then run again.', 'worried');
    if (errs[0]) { errs[0].scrollIntoView({ block: 'center' }); flash(errs[0]); }
  }
  function flash(el) { try { var o = el.style.outline; el.style.outline = '4px solid #ffc84a'; el.style.outlineOffset = '3px'; setTimeout(function () { el.style.outline = o; }, 4000); } catch (e) { } }
  async function pauseRun(msg, els) {
    await send({ type: 'run.patch', patch: { paused: true } });
    state.paused = true; progress = -1; state.open = true;
    blip('pause'); sayText = msg; nibMood = 'worried'; render();
    if (els && els[0]) { els[0].el.scrollIntoView({ block: 'center' }); els.forEach(function (it) { flash(it.el); }); }
  }

  // ---------- quests (recorded) ----------
  function frameMatch(fr) {
    var me = window.FQREC && window.FQREC.frameInfo(); if (!fr || !me) return 0;
    return (me.url === fr.url ? 2 : 0) + (fr.name && me.name === fr.name ? 1 : 0) + (JSON.stringify(me.path) === JSON.stringify(fr.path) ? 1 : 0);
  }
  // can this frame see what the step points at? (a score, so the best frame wins)
  function probeStep(st) {
    if (unloading) return { score: 0 };
    var s = 0, r = st.target ? E.locate(st.target) : null;
    if (r && r.el) s = r.score;
    else if (st.type === 'choose' && E.findOption(st, null, null)) s = 3;
    else if ((st.effects || []).some(function (fx) { return E.locate(fx.target); })) s = 2;
    else if (st.type === 'key' && !st.target) s = 1;
    return { score: s ? s + frameMatch(st.frame) : 0 };
  }
  function wantMet(el, want) { return !!want && el.getAttribute(want[0]) === want[1]; }
  // a dressed-up dropdown hides the real one; if pressing the costume didn't work, set the real one
  function applyEffects(st, onlyIfDifferent) {
    var did = false;
    (st.effects || []).forEach(function (fx) {
      var r = E.locate(fx.target); if (!r || !r.el || r.el.tagName !== 'SELECT') return;
      var cur = (r.el.options[r.el.selectedIndex] || {}).text || '';
      if (onlyIfDifferent && FQ.norm(cur) === FQ.norm(fx.value)) { did = true; return; }
      if (E.setSelectText(r.el, fx.value)) did = true;
    });
    return did;
  }
  // do one step in this frame → { status: 'ok' | 'skip' | 'final' | 'missing', label }
  async function execStep(st) {
    if (!ctx) await loadCtx();
    var r = st.target ? E.locate(st.target) : null, el = r && r.el;
    if (st.type === 'fill') {
      if (!el) return { status: 'missing' };
      var kind = E.kindOf(el) || (el.tagName === 'SELECT' ? 'select' : 'text');
      var item = { el: el, kind: kind, key: st.key || null, answerId: st.answerId || null, literal: st.value != null ? st.value : null, text: E.labelText(el) };
      if (kind === 'radio') {
        item.options = el.name ? E.qsa('input[type="radio"][name="' + window.CSS.escape(el.name) + '"]') : [el];
        if (st.choice && item.literal == null && !item.key && !item.answerId) item.literal = st.choice;
      }
      if (st.date && st.value != null && !st.key && !st.answerId && kind !== 'radio' && kind !== 'select' && kind !== 'checkbox') {
        var dv = st.relOn && st.rel != null ? E.shiftedDate(st.value, st.rel) : st.value;      // "today" when you recorded means today now
        return (await E.fillDate(el, dv)) ? { status: 'ok' } : { status: 'nodate', label: dv };
      }
      item.state = 'good';
      await E.fillItems([item], { data: ctx.data, answers: ctx.answers, timesheet: ctx.timesheet, weekEndDay: ctx.settings.weekEndDay, overwrite: true, noRecheck: true });
      return { status: 'ok' };
    }
    var mark = st.nav ? E.pageMark() : null, out = { status: 'ok' }, peekWas = st.peek ? !!E.locate(st.peek) : true;
    if (st.type === 'click') {
      if (!el) return applyEffects(st) ? { status: 'ok' } : { status: 'missing' };
      if ((st.final || E.isFinal(el)) && !st.allowFinal) { try { el.scrollIntoView({ block: 'center' }); } catch (e) { } flash(el); return Object.assign({ status: 'final', label: E.labelOfButton(el).slice(0, 30) }, preflight()); }
      if (wantMet(el, st.want)) return { status: 'skip' };          // already ticked / already open
      E.human(el);
      if (st.effects) { await E.wait(250); applyEffects(st, true); }
    } else if (st.type === 'choose') {
      var res = await E.choose(st, el);
      if (res === 'final') { var o = E.findOption(st, null, el); if (o) flash(o); return Object.assign({ status: 'final', label: String(st.option).slice(0, 30) }, preflight()); }
      if (res === 'missing') return applyEffects(st) ? { status: 'ok' } : { status: 'missing' };
      if (st.effects) { await E.wait(250); applyEffects(st, true); }
      out.status = res;
    } else if (st.type === 'key') {
      if (el) { try { el.focus({ preventScroll: true }); } catch (e) { } }
      var keys = st.keys || [];
      for (var i = 0; i < keys.length; i++) { E.pressKey(E.deepActive() || el || document.body, keys[i]); await E.wait(70); }
    } else return { status: 'skip' };
    // when you recorded this, the page moved on afterwards (Next, Save and continue). Wait for that same thing before the next step.
    if (mark != null && out.status === 'ok') {
      var moved = false;
      for (var w = 0; w < 100 && !moved; w++) { await E.wait(200); moved = unloading || E.pageMark() !== mark || (!peekWas && w > 4 && !!E.locate(st.peek)); }
      if (!moved) return { status: 'stuck', label: (st.target && (st.target.desc || st.target.text)) || st.option || 'that button' };
    }
    return out;
  }
  async function findStep(st) {
    if (!st.frame) return probeStep(st).score > 0 ? { top: true } : null;
    var r = await send({ type: 'frame.find', step: st });
    return r && r.frameId != null ? { frameId: r.frameId } : null;
  }
  // is this page on its way out? If so, wait: the next page picks the quest up where this one stopped.
  async function leaving() {
    if (!unloading) return false;
    for (var k = 0; k < 48; k++) await E.wait(250);
    unloading = false;                 // still here after 12 s: it was a download or a cancelled jump, carry on
    return false;
  }
  var running = false;
  async function runQuest() {
    if (running) return;
    var run = await send({ type: 'run.get' });
    if (!run || run.mode !== 'quest') return;
    await loadCtx();
    var quest = (ctx.allQuests || []).find(function (q) { return q.id === run.questId; });
    if (!quest) { await send({ type: 'run.clear' }); return; }
    running = true;
    try { await questLoop(quest, run.i || 0, !!run.force, !!run.again); } finally { running = false; }
  }
  function nameOf(st) { var t = st.target || {}; return st.type === 'choose' ? st.option + ' (in ' + (t.desc || t.label || 'the list') + ')' : t.desc || t.label || t.text || 'the next box'; }
  async function doStep(st, where) {
    try { return (where.top ? await execStep(st) : await send({ type: 'frame.exec', frameId: where.frameId, step: st })) || { status: 'ok' }; }   // no answer from a frame = it navigated, which means it worked
    catch (err) { return { status: 'missing' }; }                                                                                                // never hang silently on a step that blew up
  }
  async function questLoop(quest, from, force, again) {
    open(true);
    for (var i = from; i < quest.steps.length; i++) {
      var st = quest.steps[i];
      progress = Math.round(i / quest.steps.length * 100); say('Quest "' + quest.name + '": step ' + (i + 1) + ' of ' + quest.steps.length + '. ' + FQ.stepText(st), 'ready');
      if (st.type === 'page') continue;
      await E.settle(220, 2500);
      await leaving();
      if (E.blocker() === 'captcha') { await send({ type: 'run.patch', patch: { i: i } }); return pauseRun('A robot check showed up. Solve it, then press Continue.'); }
      var where = null, tries = again && i === from ? 8 : 34;
      for (var t = 0; t < tries && !where; t++) { where = await findStep(st); if (!where) { await leaving(); await E.wait(300); } }
      if (!where) {
        // not here. Is the site already past this step? Find the next step it could do.
        var ahead = -1;
        for (var j = i + 1; j < Math.min(quest.steps.length, i + 16) && ahead < 0; j++) if (quest.steps[j].type !== 'page' && await findStep(quest.steps[j])) ahead = j;
        if (ahead === i + 1 && st.type === 'click' && st.nav) { say('The site already moved past "' + String(nameOf(st)).slice(0, 40) + '". Carrying on.', 'ready'); again = false; continue; }
        if (again && i === from) { again = false; if (ahead > 0) i = ahead - 1; continue; }      // you pressed Continue and it still isn't here: move on
        await send({ type: 'run.patch', patch: { i: i, again: true, force: false } });
        return pauseRun(ahead > 0
          ? 'I can\'t find "' + String(nameOf(st)).slice(0, 50) + '" on this page, but I can see a later step ("' + String(nameOf(quest.steps[ahead])).slice(0, 40) + '"). If the site skipped ahead, go back a page and press Continue. Or just press Continue and I\'ll carry on from here.'
          : 'I can\'t find "' + String(nameOf(st)).slice(0, 60) + '". Get the page to where it shows and press Continue, or do it yourself and press Continue and I\'ll move on.');
      }
      again = false;
      await send({ type: 'run.patch', patch: { i: i + 1, force: false, again: false } });        // saved first: if this step loads a new page, that page carries on from the next one
      var peek = null; for (var pk = i + 1; pk < quest.steps.length && !peek; pk++) if (quest.steps[pk].target && !quest.steps[pk].frame) peek = quest.steps[pk].target;
      // a page that had nothing on it but Next (a notice, an intro) sometimes isn't shown the second time. If the next page is already up, don't press Next on it.
      var prev = quest.steps[i - 1];
      if (st.type === 'click' && st.nav && peek && where.top && prev && prev.nav && prev.type !== 'fill') {
        var pe = E.locate(peek), ce = E.locate(st.target);
        if (pe && pe.el && (!ce || pe.el !== ce.el)) { say('The site skipped a page this time, so I skipped that "' + String(nameOf(st)).slice(0, 30) + '" too.', 'ready'); continue; }
      }
      var res = await doStep(st.nav && peek ? Object.assign({}, st, { peek: peek }) : st, where);
      if (res.status === 'final') {
        // a final button (Submit, Sign, Pay) that you pressed while recording
        var mode = finalMode(), label = res.label || 'the last button';
        if (mode === 'stop') {
          await send({ type: 'run.clear' }); progress = -1; blip('clear'); burst('QUEST CLEAR!');
          return say('All set up to "' + label + '". Review it and press it yourself.', 'cheer');
        }
        if (!force && (res.need || res.invalid)) {
          await send({ type: 'run.patch', patch: { i: i, force: true } });
          return pauseRun(res.need ? res.need + ' required box' + (res.need > 1 ? 'es look' : ' looks') + ' empty, so I did not press "' + label + '". Fill ' + (res.need > 1 ? 'them' : 'it') + ' in, then press Continue and I will.'
            : 'The site is flagging something on this page, so I did not press "' + label + '". Fix it, then press Continue and I will.');
        }
        if (mode === 'count' && !(await countdown(label))) {
          await send({ type: 'run.patch', patch: { i: i, force: true } });
          return pauseRun('Held. Press Continue when you want me to press "' + label + '".');
        }
        res = await doStep(Object.assign({}, st, { allowFinal: true }), where);
        send({ type: 'log', entry: { host: HOST, title: document.title.slice(0, 80), filled: 0, mode: 'quest', quest: quest.name + ': pressed "' + label + '"' } });
      }
      force = false;
      if (res.status === 'nodate') return pauseRun('I couldn\'t get the date ' + String(res.label || '') + ' into "' + String(nameOf(st)).slice(0, 50) + '". Set it yourself, then press Continue.');
      if (res.status === 'missing') return pauseRun('I found the control but not "' + String(nameOf(st)).slice(0, 60) + '". Do this step yourself, then press Continue.');
      if (res.status === 'stuck') return pauseRun('I pressed "' + String(res.label).slice(0, 40) + '", but the page did not move on like it did when you recorded. If the site is asking for something, fix it and get to the next page, then press Continue.');
      if (st.type !== 'fill') { await E.wait(st.waitMs || 180); await leaving(); }
    }
    await send({ type: 'run.clear' }); progress = -1;
    send({ type: 'log', entry: { host: HOST, title: document.title.slice(0, 80), filled: quest.steps.length, mode: 'quest', quest: quest.name } });
    blip('clear'); burst('QUEST CLEAR!'); say('Quest "' + quest.name + '" complete!', 'cheer');
  }

  // ---------- teach clicks on the page ----------
  function onTeachClick(e) {
    if (!state.teach || e.target.closest && e.target.closest('#formquest-root')) return;
    var el = e.target.closest(E.FILL_SELECTOR) || (e.target.closest('label') && e.target.closest('label').control);
    if (!el) return;
    var it = items.find(function (x) { return x.el === el || (x.options && x.options.indexOf(el) >= 0); });
    if (!it) return;
    e.preventDefault(); e.stopPropagation();
    openTeach(it);
  }

  // ---------- moveable button: drag the pill (or the panel header) anywhere on the page ----------
  // The spot is remembered per site, and new sites start where you last put it.
  // It anchors to the nearest corner, so the panel always opens toward the middle of the screen.
  var POS = null, POSKEY = 'fqPos', drag = null, dragEndAt = 0;
  function loadPos() {
    try { chrome.storage.local.get(POSKEY, function (r) { void chrome.runtime.lastError; var m = (r && r[POSKEY]) || {}; POS = m[HOST] || m['*'] || null; applyPos(); }); } catch (e) { }
  }
  function savePos() {
    try { chrome.storage.local.get(POSKEY, function (r) { void chrome.runtime.lastError; var m = (r && r[POSKEY]) || {}; if (POS) { m[HOST] = POS; m['*'] = POS; } else { delete m[HOST]; delete m['*']; } var o = {}; o[POSKEY] = m; chrome.storage.local.set(o); }); } catch (e) { }
  }
  function applyPos() {
    if (!shadow) return; var w = $('wrap'); if (!w || drag && drag.moved) return;
    var p = POS || { ax: 'r', ay: 'b', x: 18, y: 18 };
    var x = Math.max(0, Math.min(p.x, innerWidth - 80)), y = Math.max(0, Math.min(p.y, innerHeight - 48));
    w.style.left = p.ax === 'l' ? x + 'px' : 'auto'; w.style.right = p.ax === 'r' ? x + 'px' : 'auto';
    w.style.top = p.ay === 't' ? y + 'px' : 'auto'; w.style.bottom = p.ay === 'b' ? y + 'px' : 'auto';
    w.classList.toggle('at-l', p.ax === 'l'); w.classList.toggle('at-t', p.ay === 't');
  }
  function onDragDown(e) {
    if (e.button !== 0) return;
    var h = e.target.closest('.pill,.hd'); if (!h) return;
    if (e.target.closest('[data-act]') && !e.target.closest('.pill')) return;
    var r = $('wrap').getBoundingClientRect();
    drag = { sx: e.clientX, sy: e.clientY, ox: r.left, oy: r.top, w: r.width, h: r.height, moved: false, id: e.pointerId, el: h };
  }
  function onDragMove(e) {
    if (!drag) return;
    var dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
    if (!drag.moved) { if (Math.abs(dx) + Math.abs(dy) < 6) return; drag.moved = true; try { drag.el.setPointerCapture(drag.id); } catch (_) { } $('wrap').classList.add('dragging'); }
    var w = $('wrap');
    w.style.left = Math.max(0, Math.min(innerWidth - drag.w, drag.ox + dx)) + 'px'; w.style.top = Math.max(0, Math.min(innerHeight - drag.h, drag.oy + dy)) + 'px';
    w.style.right = 'auto'; w.style.bottom = 'auto'; w.classList.remove('at-l', 'at-t');
    e.preventDefault(); e.stopPropagation();
  }
  function onDragUp() {
    if (!drag) return; var d = drag; drag = null; if (!d.moved) return;
    dragEndAt = Date.now(); $('wrap').classList.remove('dragging');
    var pill = shadow.querySelector('.pill'), r = (pill || $('wrap')).getBoundingClientRect();
    var ax = r.left + r.width / 2 < innerWidth / 2 ? 'l' : 'r', ay = r.top + r.height / 2 < innerHeight / 2 ? 't' : 'b';
    POS = { ax: ax, ay: ay, x: Math.round(ax === 'l' ? r.left : innerWidth - r.right), y: Math.round(ay === 't' ? r.top : innerHeight - r.bottom) };
    applyPos(); savePos(); if (state.open) render();
  }

  // ---------- UI events ----------
  function open(v) { state.open = v; render(); }
  async function onClick(e) {
    var b = e.target.closest('[data-act]'); if (!b) return;
    var a = b.dataset.act;
    if (Date.now() - dragEndAt < 400) return;
    if (a === 'resetpos') { POS = null; savePos(); applyPos(); render(); return; }
    if (a === 'toggle') { state.open = !state.open; if (!state.open) sayText = ''; render(); return; }
    if (a === 'close') { state.open = false; sayText = ''; state.preview = state.teach = false; loopLayer(); closePop(); render(); return; }
    if (a === 'fill') { broadcast('fill'); return; }
    if (a === 'auto') { await send({ type: 'run.set', run: { mode: 'auto', pages: 0 } }); broadcast('auto'); return; }
    if (a === 'preview') { state.preview = !state.preview; if (!state.preview) state.teach = false; loopLayer(); render(); say(state.preview ? 'Green = sure. Yellow = my guess. Red = new to me. Purple = a question for your answer bank. Click any tag to fix it.' : '', 'happy'); return; }
    if (a === 'teach') { state.teach = !state.teach; state.preview = state.teach || state.preview; loopLayer(); render(); say(state.teach ? 'Click any box on the page and tell me what it is.' : '', 'happy'); return; }
    if (a === 'rec') {
      var name = prompt('Name this quest (for example "Weekly timesheet" or "VA.gov contact info"):', document.title.slice(0, 40));
      if (!name) return;
      recFeed = [];
      await send({ type: 'rec.start', name: name, host: HOST, url: location.href });
      await loadCtx(); render(); say('Recording! Do the form like normal. Every step flashes green and shows up below. Press Stop when you\'re done.', 'ready');
      return;
    }
    if (a === 'recundo') { await send({ type: 'rec.undo' }); return; }
    if (a === 'recstop') { say('Saving…', 'ready'); var r = await send({ type: 'rec.stop', save: true }); recFeed = []; await loadCtx(); render(); blip('clear'); say(r && r.saved ? 'Quest saved with ' + r.steps + ' steps! Run it any time from here or the toolbar. You can review or remove steps in the Guild Hall.' : 'Nothing was recorded.', r && r.saved ? 'cheer' : 'worried'); return; }
    if (a === 'reccancel') { await send({ type: 'rec.stop', save: false }); recFeed = []; await loadCtx(); render(); say('Recording canceled.', 'happy'); return; }
    if (a === 'hold') { if (state.count) state.count.hold(); return; }
    if (a === 'runq') { await send({ type: 'run.set', run: { mode: 'quest', questId: b.dataset.id, i: 0 } }); runQuest(); return; }
    if (a === 'resume') { var run = await send({ type: 'run.get' }); if (!run) return; await send({ type: 'run.patch', patch: { paused: false } }); state.paused = false; if (run.mode === 'auto') autoLoop(); else runQuest(); return; }
    if (a === 'stoprun') { await send({ type: 'run.clear' }); progress = -1; state.paused = false; say('Stopped.', 'happy'); return; }
    if (a === 'hide') { await send({ type: 'hideSite', host: HOST }); state.open = false; await loadCtx(); rescan(); render(); return; }
    if (a === 'vault') { send({ type: 'openVault' }); return; }
    if (a === 'answers') { send({ type: 'openVault', hash: '#answers' }); return; }
  }
  function broadcast(cmd) { send({ type: 'broadcast', cmd: cmd }); }

  chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
    if (!msg || !msg.type) return;
    if (msg.type === 'fq.cmd') {
      (async function () {
        if (msg.cmd === 'fill') { await fillPage(); }
        else if (msg.cmd === 'auto') { if (TOP) autoLoop(); }
        else if (msg.cmd === 'resume' && TOP) { var rr = await send({ type: 'run.get' }); if (rr) { await send({ type: 'run.patch', patch: { paused: false } }); state.paused = false; if (rr.mode === 'auto') autoLoop(); else runQuest(); } }
        else if (msg.cmd === 'fillFrames') { if (!TOP) await fillPage({ mode: 'auto' }); }
        else if (msg.cmd === 'open' && TOP) { await loadCtx(); rescan(); open(true); }
        else if (msg.cmd === 'refresh') { await loadCtx(); rescan(); render(); }
      })();
      return;
    }
    if (msg.type === 'fq.recCount' && TOP) { if (ctx && ctx.rec) { ctx.rec.steps = msg.n; recFeed = msg.tail || []; render(); } return; }
    if (msg.type === 'fq.probe') { if (TOP) return; reply(probeStep(msg.step)); return; }
    if (msg.type === 'fq.exec') { if (TOP) return; execStep(msg.step).then(reply, function () { reply({ status: 'missing' }); }); return true; }
    if (msg.type === 'fq.status' && TOP) { var c = counts(); reply({ total: items.length, good: c.good, guess: c.guess, unknown: c.unknown, q: c.q, frames: totalKnown() - known(), host: HOST }); return; }
    if (msg.type === 'fq.frameCount' && TOP) { frameCounts[msg.frameId] = msg.n; if (shouldShow()) render(); return; }
  });

  // ---------- boot ----------
  async function boot() {
    await loadCtx();
    if (!ctx) return;
    rescan();
    mo.observe(document.documentElement, MO_OPT);
    document.addEventListener('click', onTeachClick, true);
    if (!TOP) return;
    if (ctx.rec) recFeed = ctx.rec.tail || [];
    var run = await send({ type: 'run.get' });
    if (run && !run.paused) { await E.wait(900); rescan(); if (run.mode === 'auto') autoLoop(); else if (run.mode === 'quest') runQuest(); }
    else if (run && run.paused) { state.paused = true; sayText = 'Paused. Press Continue when you\'re ready.'; nibMood = 'worried'; open(true); }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { setTimeout(boot, 300); });
  else setTimeout(boot, 300);
})();
