/* FormQuest · page engine: find every box, work out what it wants, fill it the way a person would.
   1.1: sees inside shadow DOM, locates recorded targets by scoring every clue, presses like a real pointer. */
(function () {
  'use strict';
  if (window.FQE) return;
  var FQ = self.FQ;
  var SKIP_TYPES = /^(hidden|submit|button|reset|image|file|password|search|range|color)$/i;
  var FILL_SELECTOR = 'input,select,textarea,[role="combobox"],button[aria-haspopup="listbox"],[contenteditable="true"][role="textbox"]';

  function txt(n) { return n ? String(n.innerText || n.textContent || '').replace(/\s+/g, ' ').trim() : ''; }

  // ---------- seeing through component walls (shadow DOM) ----------
  function inUI(el) { return !!(el && el.closest && el.closest('#formquest-root,[data-fq-ui]')); }
  function shadowOf(el) {
    if (el.id === 'formquest-root') return null;
    if (el.shadowRoot) return el.shadowRoot;
    if (el.localName && el.localName.indexOf('-') > 0) { try { return (chrome.dom && chrome.dom.openOrClosedShadowRoot(el)) || null; } catch (e) { } }
    return null;
  }
  var rootCache = { at: 0, list: [] };
  function roots(force) {
    var now = Date.now();
    if (!force && now - rootCache.at < 700) return rootCache.list;
    var out = [], stack = [document];
    while (stack.length) {
      var all = stack.pop().querySelectorAll('*');
      for (var i = 0; i < all.length; i++) { var sr = shadowOf(all[i]); if (sr) { out.push(sr); stack.push(sr); } }
    }
    rootCache = { at: now, list: out };
    return out;
  }
  function qsa(sel, force) {
    var out = Array.prototype.slice.call(document.querySelectorAll(sel));
    roots(force).forEach(function (r) { Array.prototype.push.apply(out, r.querySelectorAll(sel)); });
    return out;
  }
  function parentOf(n) { return n.parentElement || (n.parentNode && n.parentNode.host) || null; }
  function rootOf(el) { var r = el.getRootNode && el.getRootNode(); return r && r.getElementById ? r : document; }
  function deepActive() { var a = document.activeElement; while (a) { var sr = shadowOf(a); if (sr && sr.activeElement) a = sr.activeElement; else break; } return a; }
  function visible(el) {
    if (!el || !el.isConnected) return false;
    var r = el.getBoundingClientRect(), s = getComputedStyle(el);
    var ok = r.width >= 2 && r.height >= 2 && s.visibility !== 'hidden' && s.display !== 'none' && +s.opacity > 0.02;
    if (!ok && (el.type === 'radio' || el.type === 'checkbox') && s.display !== 'none') {
      // radios and checkboxes are often invisible behind a styled stand-in; what counts is the thing a person sees
      var stand = (el.labels && el.labels[0]) || el.parentElement;
      return !!stand && stand !== el && visible(stand);
    }
    return ok;
  }
  function kindOf(el) {
    var tag = el.tagName;
    if (tag === 'SELECT') return 'select';
    if (tag === 'TEXTAREA') return 'text';
    if (tag === 'BUTTON') return el.getAttribute('aria-haspopup') === 'listbox' || el.getAttribute('role') === 'combobox' ? 'combo' : null;
    if (el.getAttribute('role') === 'combobox' && tag !== 'INPUT') return 'combo';
    if (el.isContentEditable) return 'rich';
    if (tag === 'INPUT') {
      var t = (el.type || 'text').toLowerCase();
      if (/^(submit|button|reset|image)$/.test(t)) return null;      // these are buttons, not boxes
      if (t === 'radio') return 'radio';
      if (t === 'checkbox') return 'checkbox';
      if (el.getAttribute('role') === 'combobox' || el.getAttribute('aria-autocomplete') === 'list' || looksDropdown(el)) return 'typeahead';
      return 'text';
    }
    return null;
  }
  function looksDate(el) {
    if (el.tagName !== 'INPUT') return false;
    return /date|flatpickr|calendar|\bdob\b|mm\s*\/\s*dd|dd\s*\/\s*mm|yyyy/i.test([typeof el.className === 'string' ? el.className : '', el.id, el.name, el.placeholder, el.getAttribute('aria-label')].join(' '));
  }
  function usable(el) {
    if (el.closest('#formquest-root,[data-fq-ui]')) return false;
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') return false;
    if ((el.readOnly || el.getAttribute('aria-readonly') === 'true') && !looksDropdown(el) && !looksDate(el)) return false;   // a read-only box is fine if it's a click-to-choose dropdown
    if (el.tagName === 'INPUT' && SKIP_TYPES.test(el.type || '')) return false;
    if (el.tagName === 'INPUT' && /^(q|query|search|s|keyword|keywords)$/i.test(el.name || '')) return false;
    if (el.tagName === 'BUTTON' && !el.getAttribute('aria-haspopup') && el.getAttribute('role') !== 'combobox') return false;
    if (el.tagName === 'SELECT' && !visible(el)) return !!skinOf(el);      // a real dropdown hidden behind a pretty copy
    return visible(el);
  }

  function byIds(ids, el) { var r = el ? rootOf(el) : document; return (ids || '').split(/\s+/).map(function (id) { return txt(r.getElementById(id) || document.getElementById(id)); }).filter(Boolean).join(' '); }

  // text a person would read next to this box
  function labelText(el) {
    var t = '';
    if (el.getAttribute('aria-labelledby')) {
      // skip a label that points back inside the control itself (Select2 does this: its "label" is the current value)
      var ids = el.getAttribute('aria-labelledby').split(/\s+/).filter(function (id) { var n = rootOf(el).getElementById(id); return n && !el.contains(n); });
      t = byIds(ids.join(' '), el);
    }
    if (!t && el.labels && el.labels.length) t = Array.prototype.map.call(el.labels, txt).join(' ');
    if (!t) { var lab = el.closest('label'); if (lab) t = txt(lab).replace(txt(el), ''); }
    if (!t && el.getAttribute('aria-label')) t = el.getAttribute('aria-label');
    if (!t && el.tagName === 'BUTTON') {
      // Workday style: the label lives in a sibling above the button
      var box = el.closest('[data-automation-id^="formField"],[data-automation-id*="formField"]');
      if (!box) { var gp = el.parentElement && el.parentElement.parentElement; if (gp && gp.querySelectorAll(FILL_SELECTOR).length <= 2) box = gp; }   // only a box that holds just this control
      var l = box && box.querySelector('label');
      if (l) t = txt(l);
    }
    if (!t) t = nearbyText(el);
    return t.replace(/\*+/g, '').replace(/\s+/g, ' ').trim().slice(0, 160);
  }
  function nearbyText(el) {
    var node = el, depth = 0;
    while (node && node.parentElement && depth < 4) {
      var parent = node.parentElement, controls = parent.querySelectorAll(FILL_SELECTOR).length;
      if (controls > 3 && depth > 0) break;
      var s = '', sib = node.previousElementSibling, guard = 0;
      while (sib && guard++ < 4) {
        if (sib.matches && !sib.matches(FILL_SELECTOR) && !sib.querySelector(FILL_SELECTOR)) { var st = txt(sib); if (st) { s = st; break; } }
        sib = sib.previousElementSibling;
      }
      if (!s && node.previousSibling && node.previousSibling.nodeType === 3) s = node.previousSibling.textContent.trim();
      if (s && s.length < 120) return s;
      node = parent; depth++;
    }
    return '';
  }
  function attrText(el) {
    return [el.name, el.id, el.getAttribute('data-automation-id'), el.getAttribute('data-testid'), el.getAttribute('data-qa'), el.placeholder, el.title, el.getAttribute('aria-describedby') && byIds(el.getAttribute('aria-describedby'), el)]
      .filter(Boolean).join(' ').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[_\-.[\]]+/g, ' ');
  }

  // the question for a group of radios / checkboxes / a select
  function questionFor(el) {
    var fs = el.closest('fieldset');
    if (fs) { var lg = fs.querySelector('legend'); if (lg && txt(lg)) return txt(lg); }
    var rg = el.closest('[role="radiogroup"],[role="group"]');
    if (rg) {
      if (rg.getAttribute('aria-labelledby')) { var a = byIds(rg.getAttribute('aria-labelledby'), rg); if (a) return a; }
      if (rg.getAttribute('aria-label')) return rg.getAttribute('aria-label');
    }
    if (el.type === 'radio' || el.type === 'checkbox') {
      var name = el.name, node = el.parentElement, depth = 0;
      while (node && depth++ < 6) {
        var same = name ? node.querySelectorAll('input[name="' + CSS.escape(name) + '"]').length : 1;
        var all = node.querySelectorAll('input[type="radio"],input[type="checkbox"]').length;
        if (node.parentElement && all > same) break;
        var clone = node.cloneNode(true);
        clone.querySelectorAll('label,input,[role="radio"]').forEach(function (n) { n.remove(); });
        var q = txt(clone);
        if (q && q.length > 3) return q.slice(0, 220);
        node = node.parentElement;
      }
      return nearbyText(el.closest('label') || el);
    }
    return labelText(el);
  }
  function optionLabel(el) {
    if (el.labels && el.labels.length) return txt(el.labels[0]);
    var lab = el.closest('label'); if (lab) return txt(lab);
    if (el.getAttribute('aria-label')) return el.getAttribute('aria-label');
    var n = el.nextSibling; while (n && n.nodeType === 3 && !n.textContent.trim()) n = n.nextSibling;
    return n ? (n.nodeType === 3 ? n.textContent.trim() : txt(n)) : el.value;
  }

  // a stable fingerprint for this box on this site (used by taught rules)
  function stableId(id) { return id && !/\d{4,}|[0-9a-f]{8,}|^(input|field|react|mui|:r)|:r[0-9a-z]+:/i.test(id) && id.length < 60; }
  function sig(el) {
    var parts = [el.tagName.toLowerCase(), (el.type || '').toLowerCase()];
    var auto = el.getAttribute('data-automation-id'), nm = el.name;
    if (auto) parts.push('a:' + auto);
    else if (stableId(el.id)) parts.push('#' + el.id);
    else if (nm && !/\d{4,}/.test(nm)) parts.push('n:' + nm);
    else parts.push('l:' + FQ.norm(el.type === 'radio' || el.type === 'checkbox' ? questionFor(el) : labelText(el)).slice(0, 60));
    if (el.type === 'radio' || el.type === 'checkbox') parts.push('q:' + FQ.norm(questionFor(el)).slice(0, 50));
    return parts.join('|');
  }
  // ---------- locators: remember a thing by every clue, find it again by score ----------
  var CELL = 'td,th,[role="gridcell"],[role="cell"]';
  function q(v) { return String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"'); }
  function isCell(c) { return /^(TD|TH)$/.test(c.tagName) || /cell|header/.test(c.getAttribute('role') || ''); }
  // where a box sits in a table: row and column, by header text when there is one
  function gridOf(el) {
    var cell = el.closest(CELL); if (!cell) return null;
    var row = cell.closest('tr,[role="row"]'); if (!row) return null;
    var cells = Array.prototype.filter.call(row.children, isCell), ci = cells.indexOf(cell); if (ci < 0) return null;
    var table = row.closest('table,[role="grid"],[role="table"],[role="treegrid"]');
    var rowsAll = Array.prototype.slice.call(table ? table.querySelectorAll('tr,[role="row"]') : row.parentElement.children);
    var g = { r: rowsAll.indexOf(row), c: ci, rt: '', ct: '' };
    for (var i = 0; i < cells.length; i++) {
      if (cells[i] === cell || cells[i].querySelector(FILL_SELECTOR)) continue;
      var s = txt(cells[i]); if (s) { g.rt = s.slice(0, 60); break; }
    }
    var head = rowsAll[0];
    if (head && head !== row) { var hc = Array.prototype.filter.call(head.children, isCell)[ci]; if (hc && !hc.querySelector(FILL_SELECTOR)) g.ct = txt(hc).slice(0, 60); }
    var same = cell.querySelectorAll(el.tagName); if (same.length > 1) g.k = Array.prototype.indexOf.call(same, el);
    return g;
  }
  function gridScore(a, b) {
    if ((a.k || 0) !== (b.k || 0)) return 0;
    var col = a.ct ? (a.ct === b.ct ? 3 : 0) : (a.c === b.c ? 2 : 0);
    var row = a.rt ? (a.rt === b.rt ? 3 : 0) : (a.r === b.r ? 2 : 0);
    return col && row ? col + row : 0;
  }
  // the heading this thing sits under ("Laptop" for one of three Edit buttons)
  function sectionOf(el) {
    var fs = el.closest('fieldset'); if (fs) { var lg = fs.querySelector('legend'); if (lg && txt(lg)) return txt(lg).slice(0, 60); }
    var n = el, d = 0;
    while ((n = parentOf(n)) && d++ < 6) {
      if (n === document.body || n === document.documentElement) break;
      var hs = n.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"]');
      if (hs.length > 40) break;
      for (var i = hs.length - 1; i >= 0; i--) {
        if (hs[i].contains(el)) continue;
        if (hs[i].compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) { var t = txt(hs[i]); if (t) return t.slice(0, 60); }
      }
    }
    return '';
  }
  // a short structural address, anchored on the nearest stable id
  function pathOf(el) {
    var parts = [], n = el, d = 0;
    while (n && n.nodeType === 1 && d++ < 10) {
      if (stableId(n.id)) { parts.unshift('#' + CSS.escape(n.id)); break; }
      var tag = n.tagName.toLowerCase(), p = n.parentElement;
      if (tag === 'body' || tag === 'html' || !p) { parts.unshift(tag); break; }
      var sibs = Array.prototype.filter.call(p.children, function (c) { return c.tagName === n.tagName; });
      parts.unshift(sibs.length > 1 ? tag + ':nth-of-type(' + (sibs.indexOf(n) + 1) + ')' : tag);
      n = p;
    }
    return parts.length >= 3 || (parts[0] || '')[0] === '#' ? parts.join('>') : '';   // too short to mean anything
  }
  var OPENER = '[aria-haspopup],[aria-expanded],[role="combobox"]';
  function isOpener(el) { return el.matches(OPENER); }
  function nearOf(el) { var nr = labelText(el); if (!nr || FQ.norm(nr) === FQ.norm(clickText(el))) nr = nearbyText(el); return (nr || '').slice(0, 80); }
  function fieldLabel(el) { return el.type === 'radio' || el.type === 'checkbox' ? questionFor(el) + ' :: ' + optionLabel(el) : labelText(el); }
  function clickText(el) { return txt(el).slice(0, 80) || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || (el.querySelector && el.querySelector('img[alt]') || { alt: '' }).alt || ''; }
  function findable(el) { return el && el.isConnected && !inUI(el) && (visible(el) || el.tagName === 'SELECT'); }
  // everything on the page that reads the same as this target (to tell twins apart by position)
  function twins(t) {
    if (t.label) { var w = FQ.norm(t.label); return qsa(FILL_SELECTOR).filter(function (e) { return findable(e) && FQ.norm(fieldLabel(e)) === w; }); }
    if (t.text) {
      var w2 = FQ.norm(t.text);
      return qsa(t.tag).filter(function (e) { return (e.textContent || '').length < 400 && visible(e) && !inUI(e) && FQ.norm(clickText(e)) === w2; });
    }
    return [];
  }
  function targetOf(el) {
    var tag = el.tagName.toLowerCase(), kind = kindOf(el) || (tag === 'select' ? 'select' : null);
    var t = { v: 2, tag: tag, css: [], label: '', text: '' };
    if (tag === 'input') t.itype = (el.type || 'text').toLowerCase();
    if (el.getAttribute('role')) t.role = el.getAttribute('role');
    if (stableId(el.id)) t.css.push('#' + CSS.escape(el.id));
    ['data-automation-id', 'data-testid', 'data-test', 'data-qa', 'data-cy'].forEach(function (a) { var v = el.getAttribute(a); if (v && v.length < 80 && !/\d{5,}/.test(v)) t.css.push('[' + a + '="' + q(v) + '"]'); });
    if (el.name && typeof el.name === 'string' && !/\d{4,}/.test(el.name)) t.css.push(tag + '[name="' + q(el.name) + '"]' + (el.type === 'radio' ? '[value="' + q(el.value) + '"]' : ''));
    if (el.getAttribute('aria-label')) t.css.push(tag + '[aria-label="' + q(el.getAttribute('aria-label')) + '"]');
    var href = tag === 'a' && el.getAttribute('href');
    if (href && href.length < 120 && !/^(#|javascript:)/i.test(href) && !/\d{6,}|[0-9a-f]{16,}/i.test(href)) t.css.push('a[href="' + q(href) + '"]');
    t.label = kind ? fieldLabel(el) : '';
    t.text = kind ? '' : clickText(el);
    if (kind && el.placeholder && !t.label) t.css.push(tag + '[placeholder="' + q(el.placeholder) + '"]');
    // a dropdown opener usually shows its current value as its text, so also remember the label beside it
    if (!kind && isOpener(el)) { var nr = labelText(el); if (!nr || FQ.norm(nr) === FQ.norm(t.text)) nr = nearbyText(el); if (nr && FQ.norm(nr) !== FQ.norm(t.text)) t.near = nr.slice(0, 80); }
    var g = gridOf(el); if (g) t.grid = g;
    var sec = sectionOf(el); if (sec) t.sec = sec;
    t.path = pathOf(el);
    var tw = twins(t); if (tw.length > 1) { t.nth = tw.indexOf(el); t.of = tw.length; }
    // a name people can read in the step list
    t.desc = (t.label || t.near || t.text || (g ? [g.rt || 'row ' + (g.r + 1), g.ct || 'column ' + (g.c + 1)].join(', ') : '') || el.getAttribute('title') || el.placeholder || t.role || tag).slice(0, 60);
    if (t.sec && t.of > 1) t.desc += ' (' + t.sec.slice(0, 30) + ')';
    return t;
  }
  // score every candidate; a recorded id, label, table position, heading and address all count
  function locate(t) {
    if (!t) return null;
    var pool = new Map(), isField = !!t.label || (!t.text && /^(input|select|textarea)$/.test(t.tag || ''));
    function add(el, s) { if (findable(el)) pool.set(el, (pool.get(el) || 0) + s); }
    (t.css || []).forEach(function (sel) { try { var l = qsa(sel).filter(findable); if (l.length <= 25) l.forEach(function (el) { add(el, l.length === 1 ? 4 : 2); }); } catch (e) { } });
    if (t.path) { try { var pl = qsa(t.path).filter(findable); if (pl.length <= 8) pl.forEach(function (el) { add(el, pl.length === 1 ? 3 : 1.5); }); } catch (e) { } }
    var tw = twins(t); tw.forEach(function (el) { add(el, 4); });
    if (t.near) qsa(OPENER).forEach(function (el) { if (el.tagName.toLowerCase() === t.tag && findable(el) && nearOf(el) === t.near) add(el, 3.5); });
    if (t.grid) (isField ? qsa(FILL_SELECTOR) : qsa(t.tag)).forEach(function (el) {
      if (!el.closest(CELL)) return;
      var g = gridOf(el), s = g ? gridScore(t.grid, g) : 0; if (s) add(el, s);
    });
    var best = null, bs = 0;
    pool.forEach(function (s, el) {
      if (t.tag && el.tagName.toLowerCase() !== t.tag) s -= 3;
      if (t.itype && (el.type || '').toLowerCase() !== t.itype) s -= 2;
      if (t.role && el.getAttribute('role') === t.role) s += .5;
      if (t.sec && s >= 2 && sectionOf(el) === t.sec) s += 1.5;
      if (t.grid && !el.closest(CELL)) s -= 2;
      if (!visible(el)) s -= 1;
      pool.set(el, s);
      if (s > bs) { bs = s; best = el; }
    });
    if (best && bs >= 3) {
      var ties = []; pool.forEach(function (s, el) { if (s >= bs - .01) ties.push(el); });
      if (ties.length > 1) {
        var want = t.nth != null && tw.length === t.of ? tw[t.nth] : null;
        if (want && ties.indexOf(want) >= 0) best = want;
        else { var first = tw.filter(function (e) { return ties.indexOf(e) >= 0; })[0]; if (first) best = first; }
      }
      return { el: best, score: bs };
    }
    // nothing matched outright: a button whose words nearly match (sites reword "Next" to "Next step")
    if (t.text) {
      var bb = null, bsc = 0;
      qsa('button,a,[role="button"],input[type="submit"],input[type="button"],[role="tab"],[role="link"],[role="menuitem"],[role="option"]').forEach(function (c) {
        if (!visible(c) || inUI(c)) return;
        var sc = FQ.optionScore(txt(c) || c.value || c.getAttribute('aria-label'), t.text); if (sc > bsc) { bsc = sc; bb = c; }
      });
      if (bb && bsc >= .85) return { el: bb, score: 3 };
    }
    return null;
  }
  function findTarget(t) { var r = locate(t); return r ? r.el : null; }

  // ---------- classify ----------
  var AC = {};
  FQ.FIELDS.forEach(function (f) { (f.ac || []).forEach(function (a) { AC[a] = f.k; }); });

  function classifyText(text, attrs) {
    var best = null, bs = 0, t = FQ.norm(text), a = FQ.norm(attrs);
    FQ.FIELDS.forEach(function (f) {
      if (!f.re) return;
      f.re.forEach(function (pair) {
        var re = pair[0], w = pair[1], s = 0;
        if (t && re.test(t) && !(f.not && f.not.test(t))) s = w;
        else if (a && re.test(a) && !(f.not && f.not.test(a))) s = w * .88;
        if (s > bs) { bs = s; best = f.k; }
      });
    });
    return best ? { key: best, conf: bs } : null;
  }

  function scan(ctx) {
    ctx = ctx || {};
    var rules = ctx.rules || {}, answers = ctx.answers || [];
    var els = qsa(FILL_SELECTOR).filter(usable);
    // include radios/checkboxes whose own box is hidden but label is visible
    var items = [], seenGroups = {};
    els.forEach(function (el) {
      var kind = kindOf(el); if (!kind) return;
      var item = { el: el, kind: kind, sig: sig(el), key: null, conf: 0, src: '' };
      if (kind === 'radio' || kind === 'checkbox') {
        var gname = kind + ':' + (el.name || sig(el));
        if (kind === 'radio' && seenGroups[gname]) { seenGroups[gname].options.push(el); return; }
        item.question = questionFor(el); item.options = [el];
        if (kind === 'radio') seenGroups[gname] = item;
        item.text = item.question + (kind === 'checkbox' ? ' :: ' + optionLabel(el) : '');
      } else {
        item.text = labelText(el);
        item.attrs = attrText(el);
        if (kind === 'select' || kind === 'combo' || kind === 'typeahead') item.question = item.text;
      }
      items.push(item);
    });

    items.forEach(function (it) {
      var el = it.el, rule = rules[it.sig];
      if (rule) {
        it.src = 'taught'; it.conf = 1;
        if (rule.skip) { it.skip = true; return; }
        if (rule.key) it.key = rule.key;
        if (rule.value != null) it.literal = rule.value;
        if (rule.answer) it.answerId = rule.answer;
        return;
      }
      if (it.kind === 'checkbox') return;          // never tick agreements on a guess
      var ac = (el.getAttribute('autocomplete') || '').toLowerCase().split(/\s+/).pop();
      if (AC[ac]) { it.key = AC[ac]; it.conf = .95; it.src = 'autocomplete'; }
      else {
        var c = classifyText(it.kind === 'radio' ? it.question : it.text, it.attrs || '');
        if (c) { it.key = c.key; it.conf = c.conf; it.src = 'label'; }
      }
      // radios and selects that read like screening questions go to the answer bank
      if (it.kind === 'radio' || ((it.kind === 'select' || it.kind === 'combo' || it.kind === 'text' || it.kind === 'typeahead') && (!it.key || it.conf < .8))) {
        var qtext = it.question || it.text || '', m = FQ.matchAnswer(qtext, answers);
        var asks = /\?\s*\*?\s*$/.test(qtext) || /^(how|what|are|do|did|does|will|would|have|has|is|can|please|if)\b/i.test(qtext.trim());
        var keyEmpty = it.key && !FQ.resolve(it.key, ctx.data || {}, ctx);
        if (m && (!it.key || m.score > it.conf || asks || keyEmpty)) { it.key = null; it.answerId = m.answer.id; it.conf = Math.min(.95, m.score); it.src = 'answers'; }
        else if (!it.key) {
          var m2 = FQ.matchAnswer(qtext, answers, true);
          if (m2) { it.answerId = m2.answer.id; it.needsAnswer = true; it.conf = .7; it.src = 'answers'; }
          else if ((it.kind === 'radio' || it.kind === 'select' || it.kind === 'combo') && qtext.length > 8) it.newQuestion = true;
        }
      }
      if (it.key === 'dob' || (it.key && (FQ.BY_KEY[it.key] || {}).type === 'date')) {
        var tt = FQ.norm(it.text);
        if (/^(month|mm)$/.test(tt)) it.datePart = 'month'; else if (/^(day|dd)$/.test(tt)) it.datePart = 'day'; else if (/^(year|yyyy|yy)$/.test(tt)) it.datePart = 'year';
      }
    });
    // month/day/year boxes with a question above them ("Date of birth")
    items.forEach(function (it) {
      if (it.key || it.answerId || it.skip) return;
      var tt = FQ.norm(it.text);
      if (!/^(month|mm|day|dd|year|yyyy)$/.test(tt)) return;
      var q = questionFor(it.el), c = q && classifyText(q, '');
      if (c && (FQ.BY_KEY[c.key] || {}).type === 'date') { it.key = c.key; it.conf = c.conf * .95; it.src = 'label'; it.datePart = /^m/.test(tt) ? 'month' : /^d/.test(tt) ? 'day' : 'year'; }
    });
    // split phone / SSN boxes (3-3-4, 3-2-4)
    for (var i = 0; i < items.length; i++) {
      var it = items[i]; if (it.kind !== 'text' || !it.key) continue;
      var type = (FQ.BY_KEY[it.key] || {}).type, ml = it.el.maxLength;
      if ((type === 'phone' || type === 'ssn') && ml === 3) {
        var b = items[i + 1], c2 = items[i + 2];
        var want = type === 'phone' ? [3, 3, 4] : [3, 2, 4];
        if (b && c2 && b.el.maxLength === want[1] && c2.el.maxLength === want[2]) {
          [it, b, c2].forEach(function (x, j) { x.key = it.key; x.conf = it.conf; x.src = it.src; x.partIndex = j; x.partCount = 3; });
          i += 2;
        } else if (type === 'phone' && b && b.el.maxLength >= 7 && b.el.maxLength <= 8) {
          [it, b].forEach(function (x, j) { x.key = it.key; x.conf = it.conf; x.partIndex = j; x.partCount = 2; });
          i += 1;
        }
      }
    }
    items.forEach(function (it) {
      if (it.needsAnswer) { it.state = 'unknown'; it.newQuestion = true; return; }
      it.state = it.skip ? 'skip' : (it.key || it.answerId || it.literal != null) ? (it.conf >= .8 ? 'good' : 'guess') : it.kind === 'checkbox' ? 'skip' : 'unknown';
    });
    return items;
  }

  // ---------- writing values like a person ----------
  function nativeSet(el, value) {
    var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    var desc = Object.getOwnPropertyDescriptor(proto, 'value');
    try { el.focus({ preventScroll: true }); } catch (e) { }
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Unidentified' }));
    if (desc && desc.set) desc.set.call(el, value); else el.value = value;
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Unidentified' }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function blur(el) { el.dispatchEvent(new FocusEvent('focusout', { bubbles: true })); el.dispatchEvent(new FocusEvent('blur')); try { el.blur(); } catch (e) { } }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function valueFor(it, ctx) {
    if (it.literal != null) return it.literal;
    if (it.answerId) { var a = (ctx.answers || []).find(function (x) { return x.id === it.answerId; }); return a ? a.a : ''; }
    if (it.key) return FQ.resolve(it.key, ctx.data, ctx);
    return '';
  }

  function fillText(it, raw) {
    var el = it.el;
    var vctx = { maxLength: el.maxLength, placeholder: el.placeholder || '', inputType: (el.type || '').toLowerCase(), partIndex: it.partIndex, partCount: it.partCount, datePart: it.datePart, text: FQ.norm(it.text) };
    var vars = it.key ? FQ.variants(it.key, raw, vctx) : [String(raw)];
    if (!vars.length) return false;
    for (var i = 0; i < vars.length; i++) {
      nativeSet(el, vars[i]);
      var ok = !el.validity || el.validity.valid || (el.validity.valueMissing && !vars[i]);
      if (ok && el.value !== '') { blur(el); return true; }
    }
    nativeSet(el, vars[0]); blur(el);
    return true;
  }
  function bestOption(options, getText, wants) {
    var best = null, bs = 0;
    options.forEach(function (o) { wants.forEach(function (w) { var s = FQ.optionScore(getText(o), w); if (s > bs) { bs = s; best = o; } }); });
    return bs >= .55 ? best : null;
  }
  function pickOption(it, raw) {
    var el = it.el, wants = it.key ? FQ.variants(it.key, raw, { datePart: it.datePart }) : [String(raw)];
    if (it.key && (FQ.BY_KEY[it.key] || {}).type === 'state') { var ab = raw.length === 2 ? raw.toUpperCase() : null; if (ab && FQ.STATES[ab]) wants.push(FQ.STATES[ab]); }
    var opts = Array.prototype.filter.call(el.options, function (o) { return !o.disabled && o.value !== ''; });
    var exact = opts.find(function (o) { return wants.some(function (w) { return o.value === w || o.text.trim() === w; }); });
    return exact || bestOption(opts, function (o) { return o.text + ' ' + o.value; }, wants);
  }
  function setSelectDirect(el, pick) {
    nativeSet(el, pick.value); blur(el);
    if (!visible(el)) ['chosen:updated', 'liszt:updated', 'refresh'].forEach(function (t) { try { el.dispatchEvent(new CustomEvent(t, { bubbles: true })); } catch (e) { } });
    return true;
  }
  async function fillSelect(it, raw) {
    var el = it.el, pick = pickOption(it, raw);
    if (!pick) return false;
    if (!visible(el)) {                       // press the stand-in the way a person does; fall back to setting the real one
      var skin = skinOf(el);
      if (skin) { try { await pickFromList(skin, [pick.text.trim()], { noType: true }); await wait(120); } catch (e) { } if (el.value === pick.value) return true; }
    }
    return setSelectDirect(el, pick);
  }
  function fillRadio(it, raw) {
    var pick = bestOption(it.options, optionLabel, [String(raw)]);
    if (!pick) return false;
    if (!pick.checked) { (pick.labels && pick.labels[0] && !visible(pick) ? pick.labels[0] : pick).click(); }
    if (!pick.checked) { pick.checked = true; pick.dispatchEvent(new Event('change', { bubbles: true })); }
    return true;
  }
  function fillCheckbox(it, raw) {
    var want = /^(yes|y|true|1|on|checked|x)$/i.test(String(raw).trim());
    if (it.el.checked !== want) (it.el.labels && it.el.labels[0] && !visible(it.el) ? it.el.labels[0] : it.el).click();
    return true;
  }
  // ---------- dropdowns of every make: open it, find the list that appeared, pick the match ----------
  // Sites build dropdowns a hundred ways, and most give no hint in the code. So instead of trusting labels in the
  // markup, this watches what the page does: press the box, see what list shows up, and choose from it.
  var OPT_SEL = '[role="option"],[role="menuitem"],[role="menuitemradio"],[role="menuitemcheckbox"],[role="treeitem"],[data-automation-id="promptOption"]';
  var ITEM_SEL = OPT_SEL + ',li,[class*="option" i],[class*="item" i],[class*="result" i],[class*="suggest" i],[class*="choice" i],[data-value],[data-option-index]';
  function shownOptions() { return qsa(OPT_SEL, true).filter(function (o) { return visible(o) && !inUI(o); }); }
  function floats(el) { var n = el, d = 0; while (n && n.nodeType === 1 && d++ < 10) { var p = getComputedStyle(n).position; if (p === 'absolute' || p === 'fixed') return true; n = parentOf(n); } return false; }
  // does this text box behave like a dropdown? (hints in the markup; the real test is what happens when it's pressed)
  function looksDropdown(el) {
    if (el.tagName !== 'INPUT' || !/^(text|search|)$/i.test(el.getAttribute('type') || '')) return false;
    if (el.getAttribute('role') === 'combobox' || el.hasAttribute('aria-autocomplete') || el.hasAttribute('aria-haspopup') || el.hasAttribute('aria-owns') || el.hasAttribute('aria-activedescendant') || (el.hasAttribute('aria-controls') && el.hasAttribute('aria-expanded'))) return true;
    if (el.list) return true;
    if (looksDate(el)) return false;                      // a date box with a calendar is not a list to pick words from
    var re = /(^|[\s_\-])(select|dropdown|drop-down|combo(box)?|autocomplete|auto-complete|typeahead|type-ahead|chosen|lookup|suggest(ion)?s?|multiselect|searchable|picklist)([\s_\-]|$)/i, n = el, d = 0;
    while (n && n.nodeType === 1 && d++ < 3) {
      var c = (typeof n.className === 'string' ? n.className : '') + ' ' + (n.getAttribute('data-automation-id') || '') + ' ' + (n.getAttribute('data-testid') || '');
      if (/date|time|calendar/i.test(c)) return false;
      if (re.test(c) || /^(combobox|listbox)$/.test(n.getAttribute('role') || '')) return true;
      n = parentOf(n);
    }
    try { if (el.readOnly && getComputedStyle(el).cursor === 'pointer') return true; } catch (e) { }
    return false;
  }
  // the pretty stand-in that sits beside a hidden real <select> (Chosen, Tom Select, bootstrap-select and friends)
  function skinOf(sel) {
    var p = sel.parentElement; if (!p || !visible(p)) return null;
    var c = [sel.nextElementSibling, sel.previousElementSibling].filter(function (e) { return e && visible(e) && !/^(LABEL|SELECT|OPTION|SCRIPT|STYLE)$/.test(e.tagName); })[0];
    if (!c) return null;
    return c.querySelector('[role="combobox"],[aria-haspopup],input:not([type="hidden"]),button,a,[class*="single" i],[class*="control" i],[class*="selection" i],[class*="current" i]') || c;
  }
  function watchFresh() {
    var set = new Set(), opt = { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'hidden', 'aria-hidden', 'aria-expanded', 'open', 'data-state'] };
    var mo = new MutationObserver(function (ms) { ms.forEach(function (m) { if (m.type === 'attributes') { if (m.target.nodeType === 1) set.add(m.target); } else m.addedNodes.forEach(function (n) { if (n.nodeType === 1) set.add(n); }); }); });
    try { mo.observe(document.documentElement, opt); roots().forEach(function (r) { mo.observe(r, opt); }); } catch (e) { }
    return { roots: function () { return Array.from(set); }, stop: function () { mo.disconnect(); } };
  }
  // list items that showed up since we pressed the box
  function listItems(watch, before, el) {
    var out = [], seen = new Set();
    function add(e) {
      if (seen.has(e)) return; seen.add(e);
      if (!visible(e) || inUI(e) || e.contains(el) || el.contains(e)) return;
      var t = (e.textContent || '').trim(); if (!t || t.length > 140) return;
      out.push(e);
    }
    function generic(e) { if (e.matches(OPT_SEL)) return add(e); if (floats(e) || e.closest('[role="listbox"],[role="menu"],ul,ol')) add(e); }
    qsa(OPT_SEL, true).forEach(function (e) { if (!before.has(e)) add(e); });
    watch.roots().forEach(function (r) {
      if (!r.isConnected || inUI(r) || r === document.body || r === document.documentElement) return;
      if (r.matches(ITEM_SEL)) generic(r);
      var inner = r.querySelectorAll(ITEM_SEL); if (inner.length > 500) return;
      if (!inner.length && floats(r)) Array.prototype.forEach.call(r.children, function (c) { add(c); });   // a bare floating box of rows
      Array.prototype.forEach.call(inner, generic);
    });
    // a list that was already open, or was only re-filtered in place, isn't "new": look at what is floating right next to the box
    try {
      var rc = el.getBoundingClientRect(), cx = rc.left + Math.min(rc.width / 2, 120);
      [[cx, rc.bottom + 10], [cx, rc.bottom + 36], [rc.left + 16, rc.bottom + 10], [cx, rc.top - 10]].forEach(function (pt) {
        var e = document.elementFromPoint(pt[0], pt[1]); while (e && shadowOf(e) && shadowOf(e).elementFromPoint) { var e2 = shadowOf(e).elementFromPoint(pt[0], pt[1]); if (!e2 || e2 === e) break; e = e2; }
        if (!e || inUI(e) || e.contains(el)) return;
        var f = e, d = 0; while (f && d++ < 10 && !/absolute|fixed/.test(getComputedStyle(f).position)) f = parentOf(f);
        if (!f || f === document.body || f.contains(el) || f.querySelectorAll('*').length > 600) return;
        var inner = f.querySelectorAll(ITEM_SEL);
        if (inner.length) Array.prototype.forEach.call(inner, add); else Array.prototype.forEach.call(f.children, add);
      });
    } catch (e) { }
    // a row and the label inside it are the same choice: keep the outer one (or the one that says it's an option)
    return out.filter(function (e) { return e.matches(OPT_SEL) || !out.some(function (o) { return o !== e && o.contains(e) && FQ.norm(txt(o)) === FQ.norm(txt(e)); }); });
  }
  async function waitPick(wants, before, watch, ms, el, min) {
    var t0 = Date.now(), best = null, bs = 0, n = 0;
    while (Date.now() - t0 < ms) {
      await wait(110);
      var c = listItems(watch, before, el); best = null; bs = 0; n = c.length;
      c.forEach(function (o) { wants.forEach(function (w) { var s = FQ.optionScore(txt(o), w); if (s > bs) { bs = s; best = o; } }); });
      if (best && bs >= .85) return { el: best, score: bs, count: n };
    }
    return bs >= (min || .55) ? { el: best, score: bs, count: n } : { el: null, count: n, items: n ? listItems(watch, before, el) : [] };
  }
  function shownValue(el) { return FQ.norm(el.tagName === 'INPUT' ? el.value : txt(el)); }
  // → 'picked' | 'closest' (picked the site's nearest match; worth a look) | 'typed' (left as plain text) | 'none'
  async function pickFromList(el, wants, o) {
    o = o || {};
    wants = wants.filter(Boolean); if (!wants.length) return 'none';
    var canType = el.tagName === 'INPUT' && !el.readOnly && !/^(button|submit|checkbox|radio)$/i.test(el.type || '');
    if (el.list && el.list.options && el.list.options.length) {                          // <datalist>: the choices are right there
      var dl = bestOption(Array.prototype.slice.call(el.list.options), function (x) { return x.value + ' ' + (x.label || x.text || ''); }, wants);
      nativeSet(el, dl ? dl.value : wants[0]); blur(el); return dl ? 'picked' : 'typed';
    }
    var watch = watchFresh(), before = new Set(shownOptions()), hit = null, result = 'none', typedQ = '';
    try {
      if (canType && el.value) typeInto(el, '');                                         // start clean so the full list shows
      human(el);                                                                         // 1. press it, like a person would
      hit = await waitPick(wants, before, watch, 800, el, canType ? .85 : .55);
      if (!hit.el && canType) {                                                          // 2. type to narrow it down
        var first = wants[0], qs = [first];
        if (first.split(' ')[0].length >= 3 && first.split(' ')[0] !== first) qs.push(first.split(' ')[0]);
        if (first.length > 4) qs.push(first.slice(0, 3));
        for (var i = 0; i < qs.length && !hit.el; i++) {
          typedQ = qs[i]; typeInto(el, typedQ);
          hit = await waitPick(wants, before, watch, i ? 1300 : 1800, el, .55);
          if (!hit.el && hit.count && i === 0) {                                         // the site narrowed the list but words differ: take its top match
            var real = (hit.items || []).filter(function (x) { return !/^(no |loading|searching|type |enter |start )/i.test(txt(x)); });
            if (real.length && real.length <= 8) { hit = { el: real[0], closest: true }; break; }
          }
        }
      } else if (!hit.el) {                                                              // a pop-up with its own search box, or a long list
        var a = deepActive();
        if (a && a !== el && a.tagName === 'INPUT' && !inUI(a) && !a.readOnly) { typeInto(a, wants[0]); hit = await waitPick(wants, before, watch, 1500, el, .55); }
        for (var k = 0; k < 6 && !hit.el && hit.count; k++) {
          var n0 = shownOptions().filter(function (x) { return !before.has(x); })[0] || (hit.items || [])[0], sc = n0, d = 0;
          while (sc && d++ < 6 && !(sc.scrollHeight > sc.clientHeight + 8 && /auto|scroll/.test(getComputedStyle(sc).overflowY))) sc = parentOf(sc);
          if (!sc) break; sc.scrollTop += Math.max(60, sc.clientHeight * .8);
          hit = await waitPick(wants, before, watch, 350, el, .55);
        }
      }
      if (hit && hit.el) {
        var was = shownValue(el);
        human(hit.el); await wait(170);
        if (hit.el.isConnected && visible(hit.el) && shownValue(el) === was && canType) { pressKey(el, 'Enter'); await wait(120); }   // some lists only take the keyboard
        result = hit.closest ? 'closest' : 'picked';
      } else {
        try { el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true, composed: true })); } catch (e) { }
        if (canType && !o.noType) { nativeSet(el, wants[0]); result = 'typed'; }
      }
    } finally { watch.stop(); }
    return result;
  }
  async function fillCombo(it, raw) {
    var el = it.el, wants = it.key ? FQ.variants(it.key, raw, {}) : [String(raw)];
    var r = await pickFromList(el, wants);
    if (r === 'closest' || r === 'typed') it.unsure = r;
    return r !== 'none';
  }
  // the site answered a typed box with "please select": that box is a dropdown in disguise
  function complains(el) {
    var ids = el.getAttribute('aria-describedby') || el.getAttribute('aria-errormessage'), t = ids ? byIds(ids, el) : '', n = el, d = 0;
    while (!t && (n = parentOf(n)) && d++ < 3) {
      if (n.querySelectorAll(FILL_SELECTOR).length > 2) break;
      var e = n.querySelector('[role="alert"],[aria-live],[class*="error" i],[class*="invalid" i],[class*="warning" i],[class*="help" i]'); if (e && visible(e)) t = txt(e);
    }
    return /\b(select|choose|pick)\b/i.test(t || '');
  }
  function hasValue(it) {
    var el = it.el;
    if (it.kind === 'radio') return it.options.some(function (o) { return o.checked; });
    if (it.kind === 'checkbox') return false;
    if (it.kind === 'select') return el.selectedIndex > 0 || (el.value && el.selectedIndex >= 0 && !/select|choose|--/i.test(el.options[el.selectedIndex].text));
    if (it.kind === 'combo') { var t = FQ.norm(txt(el)); return t && !/^(select|choose|pick|click)\b|^-+$/.test(t); }
    return !!(el.value && String(el.value).trim());
  }

  async function fillItems(items, ctx) {
    var res = { filled: 0, kept: 0, missing: [], failed: [] };
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (it.state === 'unknown' || it.state === 'skip') continue;
      if (!ctx.overwrite && hasValue(it)) { res.kept++; continue; }
      var raw = valueFor(it, ctx);
      if (raw === '' || raw == null) { res.missing.push(it); continue; }
      var ok = false;
      try {
        if ((it.kind === 'text' || it.kind === 'typeahead') && it.key && (FQ.BY_KEY[it.key] || {}).type === 'date' && !it.datePart && it.el.tagName === 'INPUT' && it.el.type !== 'date' && (it.el.readOnly || looksDate(it.el))) {
          var dv = FQ.variants(it.key, raw, { maxLength: it.el.maxLength, placeholder: it.el.placeholder || '', inputType: 'text', text: FQ.norm(it.text) });   // a date box with a calendar behind it
          ok = dv.length ? await fillDate(it.el, dv[0]) : false;
          if (!ok && !it.el.readOnly) ok = fillText(it, raw);
        }
        else if (it.kind === 'text') ok = fillText(it, raw);
        else if (it.kind === 'select') ok = await fillSelect(it, raw);
        else if (it.kind === 'radio') ok = fillRadio(it, raw);
        else if (it.kind === 'checkbox') ok = fillCheckbox(it, raw);
        else if (it.kind === 'combo' || it.kind === 'typeahead') ok = await fillCombo(it, raw);
        else if (it.kind === 'rich') { ok = fillRich(it.el, raw); }
      } catch (e) { ok = false; }
      if (ok) { res.filled++; it.done = true; } else res.failed.push(it);
      if (ctx.onStep) ctx.onStep(i + 1, items.length, it, ok);
      await wait(ctx.pace || 35);
    }
    // a box that looked like plain text but wiped what was typed, or answered "please select", is a dropdown: go back and pick
    var typed = items.filter(function (x) { return x.done && x.kind === 'text' && x.el.tagName === 'INPUT' && x.el.isConnected; });
    if (typed.length && !ctx.noRecheck) {
      await wait(380);
      for (var j = 0; j < typed.length; j++) {
        var t2 = typed[j], raw2 = valueFor(t2, ctx);
        if (!(t2.el.value === '' || complains(t2.el))) continue;
        try { var r2 = await pickFromList(t2.el, t2.key ? FQ.variants(t2.key, raw2, {}) : [String(raw2)]); if (r2 !== 'picked') t2.unsure = r2 === 'none' ? 'typed' : r2; } catch (e) { t2.unsure = 'typed'; }
      }
    }
    res.unsure = items.filter(function (x) { return x.done && x.unsure; });
    return res;
  }

  // ---------- dates: write the date; if the box only takes clicks, work the calendar ----------
  var MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
  function monthIndex(s) { s = String(s || '').toLowerCase().replace(/\./g, ''); if (s.length < 3) return -1; for (var i = 0; i < 12; i++) if (MONTHS[i].indexOf(s) === 0 || s.indexOf(MONTHS[i].slice(0, 3)) === 0) return i; return -1; }
  function validYMD(y, m, d) { return y > 1900 && y < 2100 && m >= 1 && m <= 12 && d >= 1 && d <= 31; }
  // → { y, m, d, f } where f remembers how it was written, so a different date can be written the same way
  function parseDate(s) {
    s = String(s == null ? '' : s).trim().replace(/^(mon|tue|wed|thu|fri|sat|sun)[a-z]*\.?,?\s+/i, '');
    var m, y, mo, d;
    if ((m = /^(\d{4})([\-\/.])(\d{1,2})\2(\d{1,2})$/.exec(s))) { y = +m[1]; mo = +m[3]; d = +m[4]; return validYMD(y, mo, d) ? { y: y, m: mo, d: d, f: { k: 'ymd', sep: m[2], pad: m[3].length === 2 } } : null; }
    if ((m = /^(\d{1,2})([\-\/.])(\d{1,2})\2(\d{4}|\d{2})$/.exec(s))) {
      var a = +m[1], b = +m[3]; y = +m[4]; if (m[4].length === 2) y += y > 50 ? 1900 : 2000;
      var dayFirst = a > 12 && b <= 12; mo = dayFirst ? b : a; d = dayFirst ? a : b;
      return validYMD(y, mo, d) ? { y: y, m: mo, d: d, f: { k: dayFirst ? 'dmy' : 'mdy', sep: m[2], pad: m[1].length === 2 && m[3].length === 2, y2: m[4].length === 2 } } : null;
    }
    if ((m = /^([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})$/.exec(s)) && monthIndex(m[1]) >= 0) { y = +m[3]; mo = monthIndex(m[1]) + 1; d = +m[2]; return validYMD(y, mo, d) ? { y: y, m: mo, d: d, f: { k: 'Mdy', long: m[1].replace('.', '').length > 3 && !/^may$/i.test(m[1]), comma: /,/.test(s), dot: /\./.test(m[0].slice(0, m[1].length + 1)) } } : null; }
    if ((m = /^(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]{3,9})\.?,?\s+(\d{4})$/.exec(s)) && monthIndex(m[2]) >= 0) { y = +m[3]; mo = monthIndex(m[2]) + 1; d = +m[1]; return validYMD(y, mo, d) ? { y: y, m: mo, d: d, f: { k: 'dMy', long: m[2].length > 3 && !/^may$/i.test(m[2]), pad: m[1].length === 2 } } : null; }
    return null;
  }
  function formatDate(p, f) {
    var pad = function (n) { return (n < 10 ? '0' : '') + n; }, cap = function (i, long) { var n = MONTHS[i - 1]; n = n[0].toUpperCase() + n.slice(1); return long ? n : n.slice(0, 3); };
    f = f || { k: 'mdy', sep: '/', pad: true };
    var Y = f.y2 ? pad(p.y % 100) : String(p.y), M = f.pad ? pad(p.m) : String(p.m), D = f.pad ? pad(p.d) : String(p.d);
    if (f.k === 'ymd') return [Y, M, D].join(f.sep);
    if (f.k === 'dmy') return [D, M, Y].join(f.sep);
    if (f.k === 'mdy') return [M, D, Y].join(f.sep);
    if (f.k === 'Mdy') return cap(p.m, f.long) + (f.dot && !f.long ? '.' : '') + ' ' + p.d + (f.comma ? ',' : '') + ' ' + p.y;
    return (f.pad ? pad(p.d) : p.d) + ' ' + cap(p.m, f.long) + ' ' + p.y;
  }
  function dayNumber(p) { return Math.round(Date.UTC(p.y, p.m - 1, p.d) / 86400000); }
  function todayParts() { var n = new Date(); return { y: n.getFullYear(), m: n.getMonth() + 1, d: n.getDate() }; }
  function daysFromToday(p) { return dayNumber(p) - dayNumber(todayParts()); }
  // the same distance from today, written the way the recorded date was written
  function shiftedDate(value, rel) {
    var p = parseDate(value); if (!p) return value;
    var t = new Date(); t.setHours(12, 0, 0, 0); t.setDate(t.getDate() + rel);
    return formatDate({ y: t.getFullYear(), m: t.getMonth() + 1, d: t.getDate() }, p.f);
  }
  function sameDate(shown, want) { var p = parseDate(shown); return !!p && !!want && p.y === want.y && p.m === want.m && p.d === want.d; }

  function dayText(e) { var t = (e.textContent || '').trim(); return /^\d{1,2}$/.test(t) ? +t : 0; }
  function dayCells(root) { return Array.prototype.filter.call(root.querySelectorAll('td,button,a,span,div,[role="gridcell"]'), function (e) { var n = dayText(e); return n >= 1 && n <= 31 && visible(e) && !Array.prototype.some.call(e.children, function (c) { return dayText(c) === n; }); }); }
  // the calendar that popped up: a floating box holding a month's worth of day numbers
  function calendarRoot(watch, el) {
    var c = [];
    function consider(r) { if (!r || !r.isConnected || inUI(r) || r.contains(el) || r === document.body || !visible(r)) return; var f = r, d = 0; while (f && d++ < 10 && !/absolute|fixed/.test(getComputedStyle(f).position)) f = parentOf(f); if (!f || f === document.body || f.contains(el)) return; if (c.indexOf(f) < 0 && dayCells(f).length >= 20) c.push(f); }
    watch.roots().forEach(consider);
    try { var rc = el.getBoundingClientRect(); [[rc.left + 30, rc.bottom + 40], [rc.left + 30, rc.top - 40], [rc.left + 30, rc.bottom + 120]].forEach(function (pt) { consider(document.elementFromPoint(pt[0], pt[1])); }); } catch (e) { }
    qsa('[class*="calendar" i],[class*="datepicker" i],[class*="date-picker" i],[class*="picker-dropdown" i],[role="dialog"]').forEach(function (r) { if (floats(r)) consider(r); });
    c.sort(function (a, b) { return a.querySelectorAll('*').length - b.querySelectorAll('*').length; });
    return c[0] || null;
  }
  function calControls(pop) {
    var o = { monthSel: null, yearSel: null, yearInp: null };
    Array.prototype.forEach.call(pop.querySelectorAll('select'), function (s) {
      if (!visible(s)) return;
      var t = Array.prototype.map.call(s.options, function (x) { return x.text.trim(); });
      if (t.length >= 12 && t.filter(function (x) { return monthIndex(x) >= 0; }).length >= 12) o.monthSel = s;
      else if (t.length && t.every(function (x) { return /^\d{4}$/.test(x); })) o.yearSel = s;
    });
    Array.prototype.forEach.call(pop.querySelectorAll('input'), function (i) { if (visible(i) && /^\d{4}$/.test(i.value) && (i.type === 'number' || /year/i.test(i.className + ' ' + (i.getAttribute('aria-label') || '')))) o.yearInp = i; });
    return o;
  }
  function readMonthYear(pop) {
    var c = calControls(pop), y = null, m = null;
    if (c.monthSel) m = monthIndex((c.monthSel.options[c.monthSel.selectedIndex] || {}).text) + 1;
    if (c.yearSel) y = +c.yearSel.value || +(c.yearSel.options[c.yearSel.selectedIndex] || {}).text;
    if (c.yearInp) y = +c.yearInp.value;
    var t = (pop.innerText || pop.textContent || '');
    if (!m || !y) { var r = /\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\b\.?,?\s*((?:19|20)\d{2})?/i.exec(t); if (r) { if (!m) m = monthIndex(r[1]) + 1; if (!y && r[2]) y = +r[2]; } }
    if (!y) { var r2 = /\b((?:19|20)\d{2})\b/.exec(t); if (r2) y = +r2[1]; }
    return m && y ? { m: m, y: y, c: c } : null;
  }
  function navButton(pop, dir, byYear) {
    var re = dir > 0 ? /next|forward|right/i : /prev|back|left/i, glyph = dir > 0 ? /^[›»>→▶⟩]+$/ : /^[‹«<←◀⟨]+$/, best = null, bs = 0;
    Array.prototype.forEach.call(pop.querySelectorAll('button,a,[role="button"],span,div,th,td,svg'), function (e) {
      if (!visible(e) || e.disabled || e.getAttribute('aria-disabled') === 'true') return;
      var meta = [e.getAttribute('aria-label'), e.getAttribute('title'), typeof e.className === 'string' ? e.className : (e.getAttribute('class') || ''), e.getAttribute('data-handler')].join(' '), tx = (e.textContent || '').trim();
      if (tx.length > 24 || dayText(e)) return;
      var hit = re.test(meta) || glyph.test(tx) || re.test(tx); if (!hit) return;
      var yr = /year|super|double|decade/i.test(meta), s = 1 + (/month/i.test(meta) ? 2 : 0) + (/^(BUTTON|A)$/.test(e.tagName) || e.getAttribute('role') === 'button' ? 1 : 0);
      if (byYear ? !yr : yr) return;
      if (e.querySelectorAll('*').length > 6) return;
      if (s > bs) { bs = s; best = e; }
    });
    return best;
  }
  function dayCell(pop, want) {
    var cells = dayCells(pop).filter(function (e) { return dayText(e) === want.d; });
    var off = /(^|[\s_\-])(prev|next|other|outside|old|new|disabled|muted|adjacent|off|notin|hidden)|OtherMonth|outsideMonth|prevMonth|nextMonth|-disabled/i;
    var ok = cells.filter(function (e) { var n = e, d = 0; while (n && n !== pop && d++ < 3) { var cl = typeof n.className === 'string' ? n.className : ''; if (off.test(cl) || n.getAttribute('aria-disabled') === 'true' || n.disabled) return false; n = n.parentElement; } return true; });
    if (!ok.length) return null;
    var mon = MONTHS[want.m - 1], named = ok.filter(function (e) { var n = e, d = 0, s = ''; while (n && n !== pop && d++ < 3) { s += ' ' + (n.getAttribute('aria-label') || '') + ' ' + (n.getAttribute('title') || '') + ' ' + (n.getAttribute('data-date') || ''); n = n.parentElement; } s = s.toLowerCase(); return s.indexOf(mon.slice(0, 3)) >= 0 || s.indexOf(want.y + '-' + (want.m < 10 ? '0' : '') + want.m) >= 0; });
    if (named.length) return named[0];
    return want.d <= 15 ? ok[0] : ok[ok.length - 1];       // days spilling in from the next or last month sit at the edges
  }
  async function driveCalendar(el, want) {
    var watch = watchFresh();
    try {
      human(el); await wait(380);
      var pop = calendarRoot(watch, el);
      if (!pop) {                                            // a calendar icon beside the box
        var wrap = el.parentElement, btn = null, d = 0;
        while (wrap && d++ < 3 && !btn) { btn = Array.prototype.filter.call(wrap.querySelectorAll('button,[role="button"],a,svg,i,span[class*="icon" i]'), function (b) { return visible(b) && !b.contains(el) && /calendar|date|pick|icon/i.test([b.getAttribute('aria-label'), b.getAttribute('title'), typeof b.className === 'string' ? b.className : ''].join(' ')); })[0]; wrap = wrap.parentElement; }
        if (btn) { human(btn); await wait(420); pop = calendarRoot(watch, el); }
      }
      if (!pop) return false;
      var direct = false;
      for (var n = 0; n < 60; n++) {
        var cur = readMonthYear(pop); if (!cur) break;
        var diff = (want.y - cur.y) * 12 + (want.m - cur.m); if (!diff) break;
        if (!direct && (cur.c.monthSel || cur.c.yearSel || cur.c.yearInp)) {       // the calendar has its own month/year controls: set them
          direct = true;
          if (cur.c.yearSel && want.y !== cur.y) { var yo = Array.prototype.filter.call(cur.c.yearSel.options, function (x) { return +x.text === want.y || +x.value === want.y; })[0]; if (yo) nativeSet(cur.c.yearSel, yo.value); }
          if (cur.c.yearInp && want.y !== cur.y) nativeSet(cur.c.yearInp, String(want.y));
          await wait(140); pop = pop.isConnected && visible(pop) ? pop : calendarRoot(watch, el); if (!pop) return false;
          var c2 = calControls(pop);
          if (c2.monthSel) { var mo = Array.prototype.filter.call(c2.monthSel.options, function (x) { return monthIndex(x.text) + 1 === want.m; })[0]; if (mo && c2.monthSel.value !== mo.value) nativeSet(c2.monthSel, mo.value); }
          await wait(160);
        } else {
          var byYear = Math.abs(diff) >= 12 ? navButton(pop, diff, true) : null, b = byYear || navButton(pop, diff, false);
          if (!b) return false;
          human(b); await wait(150);
        }
        if (!pop.isConnected || !visible(pop)) { pop = calendarRoot(watch, el); if (!pop) return false; }
      }
      var day = dayCell(pop, want); if (!day) return false;
      human(day); await wait(260);
      return true;
    } finally { watch.stop(); }
  }
  // put a date in a box. → true if it took
  async function fillDate(el, value) {
    var want = parseDate(value);
    if (el.tagName === 'INPUT' && el.type === 'date') { if (!want) return false; nativeSet(el, want.y + '-' + (want.m < 10 ? '0' : '') + want.m + '-' + (want.d < 10 ? '0' : '') + want.d); blur(el); return true; }
    if (!el.readOnly && !el.disabled && el.tagName === 'INPUT') {                // 1. just write it
      try { el.focus({ preventScroll: true }); } catch (e) { }
      nativeSet(el, value); await wait(60);
      el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true, composed: true }));
      blur(el); await wait(240);
      if (!want || sameDate(el.value, want)) return true;
    }
    if (!want) return false;
    var ok = await driveCalendar(el, want);                                      // 2. the box wants clicks: use its calendar
    await wait(120);
    if (el.tagName === 'INPUT' && el.value && parseDate(el.value)) return sameDate(el.value, want);
    return ok;
  }

  // ---------- buttons: next vs. final ----------
  var FINAL = /\b(submit|sign|certify|attest|pay|purchase|place\s*order|buy|confirm\s*(and|&)\s*submit|send\s*application|apply\s*now|finish|complete\s*(application|submission)|e-?sign|authorize|i\s*agree)\b/i;
  var NEXT = /^(next|continue|save\s*(and|&)\s*continue|next\s*step|next\s*page|proceed|save\s*(and|&)\s*next|continue\s*to\s*next\s*step|go\s*to\s*next)\b/i;
  function clickables() {
    return Array.prototype.filter.call(document.querySelectorAll('button,input[type="submit"],input[type="button"],a[role="button"],[role="button"],a.button,a.btn'), function (b) { return visible(b) && !b.disabled && !b.closest('#formquest-root'); });
  }
  function labelOfButton(b) { return (txt(b) || b.value || b.getAttribute('aria-label') || '').trim(); }
  function findNext() {
    var list = clickables(), next = null, final = null;
    list.forEach(function (b) {
      var t = labelOfButton(b).slice(0, 60);
      if (!t) return;
      if (NEXT.test(t) && !next) next = b;
      else if (FINAL.test(t) && !final) final = b;
    });
    return { next: next, final: final };
  }
  function isFinal(el) { return FINAL.test(labelOfButton(el)); }
  function blocker() {
    if (document.querySelector('iframe[src*="recaptcha"],iframe[src*="hcaptcha"],iframe[src*="challenges.cloudflare"],.g-recaptcha,.h-captcha,.cf-turnstile')) return 'captcha';
    var pw = Array.prototype.filter.call(document.querySelectorAll('input[type="password"]'), visible);
    if (pw.length) return 'login';
    return null;
  }
  // press something the way a hand does: hover, pointer down, focus, pointer up, click
  function human(el) {
    try { el.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (e) { }
    var r = el.getBoundingClientRect(), x = Math.round(r.left + r.width / 2), y = Math.round(r.top + r.height / 2);
    var base = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, detail: 1 };
    function mk(type, extra) {
      var o = Object.assign({}, base, extra || {});
      if (type.indexOf('pointer') === 0) { o.pointerId = 1; o.pointerType = 'mouse'; o.isPrimary = true; try { return new PointerEvent(type, o); } catch (e) { } }
      return new MouseEvent(type, o);
    }
    el.dispatchEvent(mk('pointerover')); el.dispatchEvent(mk('pointerenter', { bubbles: false }));
    el.dispatchEvent(mk('mouseover')); el.dispatchEvent(mk('mouseenter', { bubbles: false }));
    el.dispatchEvent(mk('pointermove')); el.dispatchEvent(mk('mousemove'));
    el.dispatchEvent(mk('pointerdown', { buttons: 1 }));
    var go = el.dispatchEvent(mk('mousedown', { buttons: 1 }));
    if (go && el.isConnected) {          // a real mousedown moves focus, unless the page said not to
      var f = el.closest('a[href],button,input,select,textarea,[tabindex],[contenteditable=""],[contenteditable="true"]');
      if (f && f !== deepActive()) { try { f.focus({ preventScroll: true }); } catch (e) { } }
    }
    if (!el.isConnected) return;         // the page already acted on the press and removed it
    el.dispatchEvent(mk('pointerup')); el.dispatchEvent(mk('mouseup'));
    if (!el.isConnected) return;
    if (typeof el.click === 'function') el.click(); else el.dispatchEvent(mk('click'));
  }

  // a fingerprint of "which page is this": address, headings, and the boxes on it. If it changes, the page moved on.
  function pageMark() {
    var f = '', h = '';
    try { f = qsa(FILL_SELECTOR).filter(usable).map(function (e) { return e.id || e.name || e.getAttribute('aria-label') || e.tagName; }).join(','); } catch (e) { }
    try { h = qsa('h1,h2,h3,legend,[role="heading"],[aria-current="step"]').filter(visible).slice(0, 8).map(txt).join('|'); } catch (e) { }
    return location.href + '\u00a7' + h + '\u00a7' + f;
  }
  // wait until the page stops rearranging itself (or `max` ms pass)
  function settle(quiet, max) {
    return new Promise(function (res) {
      var t0 = Date.now(), timer = null, done = false, mo = null;
      function fin() { if (done) return; done = true; if (mo) mo.disconnect(); clearTimeout(timer); res(); }
      function bump() { clearTimeout(timer); var left = max - (Date.now() - t0); if (left <= 0) return fin(); timer = setTimeout(fin, Math.min(quiet, left)); }
      try {
        mo = new MutationObserver(function (m) { for (var i = 0; i < m.length; i++) { var t = m[i].target; if (!(t.closest && inUI(t))) { bump(); return; } } });
        mo.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden', 'aria-hidden', 'aria-busy', 'disabled'] });
      } catch (e) { }
      bump();
    });
  }

  function optionPool(st) {
    var want = FQ.norm(st.option), out = qsa(OPT_SEL, true).filter(function (o) { return visible(o) && !inUI(o); });
    var tag = st.optionLoc && st.optionLoc.tag;
    if (tag) qsa(tag).forEach(function (e) { if (out.indexOf(e) < 0 && (e.textContent || '').length < 300 && visible(e) && !inUI(e) && FQ.norm(txt(e)) === want) out.push(e); });
    return out;
  }
  // the item to pick. `before` = what was already on screen before the list opened (null: is it showing right now?)
  function findOption(st, before, opener) {
    var want = FQ.norm(st.option); if (!want) return null;
    var pool = optionPool(st).filter(function (e) { return !opener || (e !== opener && !opener.contains(e) && !e.contains(opener)); });
    var exact = pool.filter(function (e) { return FQ.norm(txt(e)) === want; });
    if (!before) { exact = exact.filter(function (e) { return e.matches(OPT_SEL) || floats(e); }); return exact[0] || null; }
    var fresh = exact.filter(function (e) { return !before.has(e); });
    if (fresh.length) return fresh[0];
    var roleExact = exact.filter(function (e) { return e.matches(OPT_SEL); });
    if (roleExact.length) return roleExact[0];
    var best = null, bs = 0;
    pool.forEach(function (e) { if (before.has(e) || !e.matches(OPT_SEL)) return; var s = FQ.optionScore(txt(e), st.option); if (s > bs) { bs = s; best = e; } });
    return bs >= .85 ? best : null;
  }
  function scrollList(before) {
    var o = shownOptions().filter(function (e) { return !before.has(e); })[0], n = o, d = 0;
    while (n && d++ < 6) { if (n.scrollHeight > n.clientHeight + 8 && /auto|scroll/.test(getComputedStyle(n).overflowY)) { n.scrollTop += Math.max(60, n.clientHeight * .8); return; } n = parentOf(n); }
  }
  // open a dropdown of any make and pick the recorded item. → 'ok' | 'skip' | 'missing' | 'final'
  async function choose(st, el) {
    var want = FQ.norm(st.option);
    var opt = findOption(st, null, el);                      // list still open, or a submenu
    var isText = el && el.tagName === 'INPUT' && !/^(button|submit|checkbox|radio)$/i.test(el.type) && !el.readOnly;
    if (!opt) {
      if (!el) return 'missing';
      var shown = FQ.norm(el.tagName === 'INPUT' ? el.value : txt(el));
      if (shown && shown === want) return 'skip';             // it already says that
      var before = new Set(optionPool(st));
      if (isText && st.typed) { try { el.focus({ preventScroll: true }); } catch (e) { } typeInto(el, st.typed); }
      else human(el);
      for (var i = 0; i < 34 && !opt; i++) {
        await wait(110);
        opt = findOption(st, before, el);
        if (opt) break;
        if (i === 13) { if (isText) typeInto(el, st.option); else if (!shownOptions().some(function (o) { return !before.has(o); })) human(el); }
        if (i > 5 && i % 4 === 0) scrollList(before);          // long or virtual lists
      }
    }
    if (!opt) {
      try { (el || document).dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); } catch (e) { }
      return 'missing';
    }
    if (isFinal(opt) && !st.allowFinal) { try { opt.scrollIntoView({ block: 'center' }); } catch (e) { } return 'final'; }
    human(opt);
    await wait(180);
    return 'ok';
  }
  // type without the "I'm finished" signal, so suggestion lists stay open
  function typeInto(el, value) {
    var desc = Object.getOwnPropertyDescriptor(el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype, 'value');
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, composed: true, key: 'Unidentified' }));
    if (desc && desc.set) desc.set.call(el, value); else el.value = value;
    el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'insertText', data: value }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, composed: true, key: 'Unidentified' }));
  }
  var KEYCODE = { Enter: 13, ' ': 32, Tab: 9, Escape: 27, ArrowDown: 40, ArrowUp: 38, ArrowLeft: 37, ArrowRight: 39, Home: 36, End: 35, PageDown: 34, PageUp: 33 };
  function pressKey(el, key) {
    var code = key === ' ' ? 'Space' : key, kc = KEYCODE[key] || 0;
    var o = { key: key, code: code, keyCode: kc, which: kc, bubbles: true, cancelable: true, composed: true, view: window };
    var go = el.dispatchEvent(new KeyboardEvent('keydown', o));
    if (key === 'Enter' || key === ' ') el.dispatchEvent(new KeyboardEvent('keypress', o));
    el.dispatchEvent(new KeyboardEvent('keyup', o));
    // Enter in a form that has no button still sends the form
    if (go && key === 'Enter' && el.isConnected && el.tagName === 'INPUT' && el.form && !el.form.querySelector('button:not([type]),button[type="submit"],input[type="submit"],input[type="image"]')) {
      try { el.form.requestSubmit(); } catch (e) { }
    }
  }
  // set a <select> by its visible text, even one hidden behind a dressed-up copy
  function setSelectText(el, text) {
    var cur = (el.options[el.selectedIndex] || {}).text || '';
    if (FQ.norm(cur) === FQ.norm(text)) return true;
    var pick = pickOption({ el: el }, text); return pick ? setSelectDirect(el, pick) : false;
  }
  function fillRich(el, raw) {
    try { el.focus(); var sel = (el.getRootNode().getSelection ? el.getRootNode() : window).getSelection(), r = document.createRange(); r.selectNodeContents(el); sel.removeAllRanges(); sel.addRange(r); } catch (e) { }
    var ok = false;
    try { ok = document.execCommand('insertText', false, raw); } catch (e) { }
    if (!ok || FQ.norm(el.innerText) !== FQ.norm(raw)) { el.textContent = raw; el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType: 'insertText', data: raw })); }
    return true;
  }

  window.FQE = {
    scan: scan, fillItems: fillItems, labelText: labelText, questionFor: questionFor, optionLabel: optionLabel,
    sig: sig, targetOf: targetOf, findTarget: findTarget, locate: locate, visible: visible, kindOf: kindOf, usable: usable,
    findNext: findNext, isFinal: isFinal, blocker: blocker, human: human, labelOfButton: labelOfButton,
    nativeSet: nativeSet, wait: wait, valueFor: valueFor, FILL_SELECTOR: FILL_SELECTOR, txt: txt,
    qsa: qsa, roots: roots, shadowOf: shadowOf, parentOf: parentOf, rootOf: rootOf, deepActive: deepActive, inUI: inUI,
    settle: settle, parseDate: parseDate, shiftedDate: shiftedDate, daysFromToday: daysFromToday, fillDate: fillDate, pickFromList: pickFromList, looksDropdown: looksDropdown, pageMark: pageMark, hasValue: hasValue, choose: choose, findOption: findOption, pressKey: pressKey, setSelectText: setSelectText, OPT_SEL: OPT_SEL
  };
})();
