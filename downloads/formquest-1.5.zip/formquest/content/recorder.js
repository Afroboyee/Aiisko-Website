/* FormQuest · recorder: runs in every frame and turns what you do into quest steps.

   Why it is built this way (the old recorder waited for the browser's "change" and "click" reports):
   - It listens to the press itself (pointerdown), because many menus pick on mouse-down and are gone before a click exists.
   - It listens on the window, first in line, and reads the true target through component walls (shadow DOM).
   - It runs in every frame, not just the top page.
   - A pick from any pop-up list becomes one "choose" step: which control, which item.
   - Typed text is noted as you type and written down before the next press, so order is always right.
   - Keyboard picks (arrows + Enter) and Enter-to-add are steps too. */
(function () {
  'use strict';
  if (window.FQREC) return;
  var FQ = self.FQ, E = window.FQE;
  var TOP = window === window.top;
  var on = false, pending = true, queue = [], attached = false;
  var DOC = Math.random().toString(36).slice(2, 8), eidN = 0, eids = new WeakMap();
  var dirty = new Map(), prevVal = new WeakMap(), lastFill = new WeakMap(), typedIn = new WeakSet(), touched = new WeakMap();
  var fresh = new WeakMap(), opener = null, lastPress = null, lastKey = null, nav = { el: null, keys: [] };
  var idle = 0, lines = [], t0 = Date.now(), seen = new WeakSet(), closedHosts = new WeakSet(), watched = new WeakSet(), mo = null, rootT = 0;

  function send(msg) { return new Promise(function (res) { try { chrome.runtime.sendMessage(msg, function (r) { void chrome.runtime.lastError; res(r); }); } catch (e) { res(null); } }); }
  function uid() { return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4); }
  function eid(el) { var v = eids.get(el); if (!v) { v = DOC + '.' + (++eidN); eids.set(el, v); } return v; }
  function active() { return on || pending; }

  var frameCache = null;
  function frameInfo() {
    if (TOP) return null;
    if (frameCache) return frameCache;
    var path = [], w = window;
    try { while (w !== w.top && path.length < 6) { var p = w.parent, idx = -1; for (var i = 0; i < p.frames.length; i++) if (p.frames[i] === w) { idx = i; break; } path.unshift(idx); w = p; } } catch (e) { }
    var url = ''; try { url = location.origin + location.pathname; } catch (e) { }
    return (frameCache = { url: url, name: window.name || '', path: path });
  }

  // ---------- a private log of what was heard (no typed values), for when a site still beats us ----------
  function short(el) {
    if (!el || !el.tagName) return '?';
    var s = el.tagName.toLowerCase();
    if (el.id) s += '#' + String(el.id).slice(0, 24);
    var c = typeof el.className === 'string' ? el.className.trim().split(/\s+/).slice(0, 2).join('.') : ''; if (c) s += '.' + c;
    ['role', 'type', 'aria-haspopup'].forEach(function (a) { var v = el.getAttribute(a); if (v) s += '[' + a + '=' + v + ']'; });
    var t = E.kindOf(el) ? '' : E.txt(el).slice(0, 24); if (t) s += ' "' + t + '"';
    return s;
  }
  function trace(what, el) {
    if (!on) return;
    lines.push(((Date.now() - t0) / 1000).toFixed(1) + 's ' + (TOP ? '' : '[frame] ') + what + (el ? ' ' + short(el) : ''));
    if (lines.length >= 25) flushTrace();
  }
  function flushTrace() { if (lines.length) { send({ type: 'rec.trace', lines: lines.splice(0) }); } }

  // ---------- writing a step down ----------
  function flash(el) {
    try {
      if (!el || !el.isConnected) return;
      var r = el.getBoundingClientRect(); if (r.width < 2 && r.height < 2) return;
      var d = document.createElement('div'); d.setAttribute('data-fq-ui', '');
      d.style.cssText = 'position:fixed;z-index:2147483640;pointer-events:none;border:3px solid #3ddc84;border-radius:6px;box-shadow:0 0 0 3px rgba(61,220,132,.3);transition:opacity .45s;left:' + (r.left - 4) + 'px;top:' + (r.top - 4) + 'px;width:' + (r.width + 8) + 'px;height:' + (r.height + 8) + 'px';
      (document.body || document.documentElement).appendChild(d);
      setTimeout(function () { d.style.opacity = '0'; }, 250); setTimeout(function () { d.remove(); }, 750);
    } catch (e) { }
  }
  var log = [], fieldPress = new WeakMap();
  function inFloat(el) { var n = el, d = 0; try { while (n && n.nodeType === 1 && d++ < 12) { var p = getComputedStyle(n).position; if (p === 'absolute' || p === 'fixed') return true; n = E.parentOf(n); } } catch (e) { } return false; }
  function emit(step, el) {
    step.id = step.id || uid();
    log.push({ id: step.id, t: Date.now(), type: step.type, el: el, pop: !!el && inFloat(el) }); if (log.length > 80) log.shift();
    var fr = frameInfo(); if (fr) step.frame = fr;
    if (pending) { queue.push([step, el]); return step.id; }
    if (!on) return null;
    send({ type: 'rec.add', step: step });
    flash(el);
    trace('STEP ' + step.type, el);
    return step.id;
  }

  // ---------- what was pressed, really ----------
  function real(e) {
    var p = e.composedPath && e.composedPath(), el = p && p.length ? p[0] : e.target;
    if (el && el.nodeType === 3) el = el.parentElement;
    return el && el.nodeType === 1 ? el : null;
  }
  var BTN_TYPE = /^(button|submit|reset|image)$/i;
  var STRICT = 'a[href],button,summary,input[type="button"],input[type="submit"],input[type="reset"],input[type="image"],label,[role="button"],[role="link"],[role="tab"],[role="menuitem"],[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"],[role="checkbox"],[role="radio"],[role="switch"],[role="treeitem"],[role="gridcell"],[role="combobox"]';
  var SEM = STRICT + ',[onclick],[tabindex]:not([tabindex="-1"])';
  var OPT_ROLE = /^(option|menuitem|menuitemradio|menuitemcheckbox|treeitem)$/;
  function isText(f) { return !!f && (f.tagName === 'TEXTAREA' || f.isContentEditable || (f.tagName === 'INPUT' && !/^(checkbox|radio|button|submit|reset|image|range|file|color)$/i.test(f.type))); }
  function fieldOf(el) {
    if (!el) return null;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) return el.tagName === 'INPUT' && BTN_TYPE.test(el.type) ? null : el;
    if (el.isContentEditable) { var n = el; while (E.parentOf(n) && E.parentOf(n).isContentEditable) n = E.parentOf(n); return n; }
    return null;
  }
  // a press that just lands in a box (or on its label) is not a step; the box's value is
  function pressField(el) {
    var n = el, d = 0;
    while (n && n.nodeType === 1 && d++ < 5) {
      var tag = n.tagName;
      if (tag === 'OPTION' || tag === 'OPTGROUP') return n.closest('select');
      if (tag === 'SELECT' || tag === 'TEXTAREA') return n;
      if (tag === 'INPUT') return BTN_TYPE.test(n.type) ? null : n;
      if (n.isContentEditable) return fieldOf(n);
      if (tag === 'LABEL') { var c = n.control; return c && /^(INPUT|SELECT|TEXTAREA)$/.test(c.tagName) && !BTN_TYPE.test(c.type || '') ? c : null; }
      if (n.matches(SEM)) return null;
      n = E.parentOf(n);
    }
    return null;
  }
  // the thing a press was meant for: a real control, or whatever owns the pointer cursor
  function actionable(el) {
    var n = el, d = 0;
    for (; n && n.nodeType === 1 && d < 7; n = E.parentOf(n), d++) {
      if (n === document.body || n === document.documentElement) break;
      if (n.matches(STRICT)) return n;
    }
    try {
      if (getComputedStyle(el).cursor === 'pointer') {
        n = el;
        for (d = 0; d < 6; d++) {          // climb through wrappers that say the same thing (an icon inside a fake button)
          var p = E.parentOf(n);
          if (!p || p === document.body || getComputedStyle(p).cursor !== 'pointer' || E.txt(p) !== E.txt(n)) break;
          n = p;
        }
        return n;
      }
    } catch (e) { }
    for (n = el, d = 0; n && n.nodeType === 1 && d < 3; n = E.parentOf(n), d++) if (n.matches('[onclick],[tabindex]:not([tabindex="-1"])')) return n;
    return null;
  }
  // is this an item in a list that popped up?
  function optionItem(el) {
    var n = el, d = 0, floatAnc = false, freshAnc = false, roleEl = null, li = null, since = opener ? opener.t - 150 : Infinity;
    for (; n && n.nodeType === 1 && d < 14; n = E.parentOf(n), d++) {
      if (n === document.body || n === document.documentElement) break;
      var role = n.getAttribute('role') || '';
      if (!roleEl && (OPT_ROLE.test(role) || n.getAttribute('data-automation-id') === 'promptOption')) roleEl = n;
      if (!li && n.tagName === 'LI') li = n;
      if ((fresh.get(n) || 0) >= since) freshAnc = true;
      if (!floatAnc) { try { var pos = getComputedStyle(n).position; if (pos === 'absolute' || pos === 'fixed') floatAnc = true; } catch (e) { } }
    }
    if (roleEl) return { el: roleEl, fresh: freshAnc };
    if (freshAnc && floatAnc) {
      var it = li || el;
      if (!li) for (d = 0; d < 5; d++) { var p = E.parentOf(it); if (!p || p.children.length !== 1 || (fresh.get(p) || 0) >= since && getComputedStyle(p).position !== 'static') break; it = p; }
      return { el: it, fresh: true };
    }
    return null;
  }
  function looksLikeOpener(el) { return !!(el && (el.hasAttribute('aria-haspopup') || el.hasAttribute('aria-expanded') || el.hasAttribute('aria-controls') || el.hasAttribute('aria-owns') || el.getAttribute('role') === 'combobox' || fieldOf(el))); }
  function linked(item) {
    if (!opener || !opener.el) return false;
    var oe = opener.el;
    if (oe === item.el || oe.contains(item.el) || item.el.contains(oe)) return false;
    if (Date.now() - opener.t > 90000) return false;
    return item.fresh || looksLikeOpener(oe);
  }
  function setOpener(el, stepId, keepTime) {
    if (opener && opener.el === el && keepTime) return;
    opener = { el: el, t: Date.now(), stepId: stepId || null, loc: null };
  }
  function openerLoc() { if (!opener.loc) opener.loc = E.targetOf(opener.el); return opener.loc; }

  // ---------- values ----------
  function valOf(el) {
    if (el.tagName === 'SELECT') return (el.options[el.selectedIndex] || {}).text || '';
    if (el.type === 'checkbox') return el.checked ? 'yes' : 'no';
    if (el.type === 'radio') return E.optionLabel(el);
    if (el.isContentEditable) return String(el.innerText || '').replace(/\u00a0/g, ' ').replace(/[ \t]+\n/g, '\n').trim();
    return el.value;
  }
  function skip(f) { return !f || /^(password|file|hidden)$/i.test(f.type || '') || E.inUI(f); }
  function mark(f) {
    var d = dirty.get(f); if (!d) { d = { loc: null }; dirty.set(f, d); }
    d.val = valOf(f);
    if (!d.loc && f.isConnected) { try { d.loc = E.targetOf(f); } catch (e) { } }
    clearTimeout(idle); idle = setTimeout(flushAll, 2500);
  }
  function buildFill(el, val, loc) {
    var kind = E.kindOf(el) || (el.tagName === 'SELECT' ? 'select' : 'text');
    var step = { type: 'fill', target: loc || E.targetOf(el), eid: kind === 'radio' && el.name ? DOC + '.r.' + el.name : eid(el) };
    var ctx = (window.FQUI && window.FQUI.ctx()) || {}, it = null;
    try { it = E.scan({ rules: ctx.rules, answers: ctx.answers, data: ctx.data }).find(function (x) { return x.el === el || (x.options && x.options.indexOf(el) >= 0); }); } catch (e) { }
    if (kind === 'radio') step.choice = val;
    if (it && it.key) {
      var secure = !!(FQ.BY_KEY[it.key] || {}).secure, mine = FQ.resolve(it.key, ctx.data || {}, ctx);
      var same = mine && (FQ.norm(mine) === FQ.norm(val) || (FQ.digits(mine) && FQ.digits(mine) === FQ.digits(val)) || FQ.variants(it.key, mine, { inputType: el.type }).indexOf(val) >= 0 || FQ.optionScore(val, mine) > .8);
      if (same || secure) step.key = it.key;        // secrets are never written into a quest; they come from the vault at run time
    }
    if (!step.key && it && it.answerId) {
      var a = (ctx.answers || []).find(function (x) { return x.id === it.answerId; });
      if (a && a.a && FQ.optionScore(val, a.a) >= .85) step.answerId = it.answerId;   // only when you picked what your answer bank says
    }
    if (!step.key && !step.answerId && kind !== 'radio') step.value = val;
    if (step.value != null && kind !== 'select' && kind !== 'checkbox') {            // a date: remember how far it was from the day you recorded
      var dp = E.parseDate(step.value);
      if (dp) { step.date = true; step.rel = E.daysFromToday(dp); step.relOn = Math.abs(step.rel) <= 14; }
    }
    if (/\bssn\b|social security/i.test(step.target.label || '')) delete step.value;
    return step;
  }
  function flush(f) {
    var d = dirty.get(f); if (!d) return null;
    dirty.delete(f);
    var val = f.isConnected ? valOf(f) : d.val, choice = f.type === 'radio' || f.type === 'checkbox';
    if (f.type === 'radio' && !f.checked) return null;
    if (!choice && prevVal.has(f) && prevVal.get(f) === val) return null;   // typed, then put back
    prevVal.set(f, val);
    var step = buildFill(f, val, f.isConnected ? null : d.loc);
    var id = emit(step, f); lastFill.set(f, id);
    return id;
  }
  function flushAll(except) { Array.from(dirty.keys()).forEach(function (f) { if (f !== except) flush(f); }); }

  // ---------- after a press: note what it changed ----------
  function watchToggle(el, id) {
    setTimeout(function () {
      if (!el.isConnected || !id) return;
      var a = ['aria-checked', 'aria-pressed', 'aria-selected', 'aria-expanded'].filter(function (x) { return el.hasAttribute(x); })[0];
      if (a) send({ type: 'rec.patch', id: id, patch: { want: [a, el.getAttribute(a)] } });   // so a replay won't flip it back
    }, 320);
  }
  var selWatch = null;
  function settleSelects() {
    var w = selWatch; if (!w) return; selWatch = null; clearTimeout(w.timer);
    var fx = [];
    w.before.forEach(function (idx, s) {
      if (s.isConnected && s.selectedIndex !== idx && !dirty.has(s) && Date.now() - (touched.get(s) || 0) > 1200) fx.push({ target: E.targetOf(s), value: (s.options[s.selectedIndex] || {}).text || '' });
    });
    if (fx.length && fx.length <= 3) send({ type: 'rec.patch', id: w.id, patch: { effects: fx } });   // a hidden real dropdown the site changed for you
    w.inputs.forEach(function (old, inp) {
      if (!inp.isConnected || inp.value === old || !inp.value || dirty.has(inp) || Date.now() - (touched.get(inp) || 0) < 900) return;
      if (E.parseDate(inp.value)) datePicked(inp, inp.value);
    });
  }
  // you picked a date from a calendar. However many clicks that took, the step is "put this date in this box".
  function datePicked(D, val) {
    var now = Date.now(), start = fieldPress.get(D) || 0, box = (D.parentElement && D.parentElement.parentElement) || D.parentElement, popOnly = false;
    log.forEach(function (x) { if (x.type === 'click' && x.el && box && box.contains(x.el) && !x.pop && x.t > start) start = x.t; });     // or a calendar icon beside it
    if (!start || now - start > 120000) { start = now - 30000; popOnly = true; }
    var ids = log.filter(function (x) { return x.t >= start - 5 && (x.pop || (!popOnly && box && x.el && box.contains(x.el))); }).map(function (x) { return x.id; });
    var step = buildFill(D, val, null);
    if (ids.length) step.merge = ids;
    dirty.delete(D); prevVal.set(D, val);
    var id = emit(step, D); lastFill.set(D, id);
    trace('  (calendar clicks folded into one date step)');
  }
  function watchSelects(id) {
    settleSelects();
    if (!id) return;
    var before = new Map(), inputs = new Map(); E.qsa('select').forEach(function (s) { before.set(s, s.selectedIndex); });
    E.qsa('input').slice(0, 300).forEach(function (i) { if (isText(i) && !skip(i) && E.visible(i)) inputs.set(i, i.value); });
    if (before.size || inputs.size) selWatch = { id: id, before: before, inputs: inputs, timer: setTimeout(settleSelects, 650) };
  }

  // did that press move the page on (Next, Save and continue, a pop-up form)? The replay then waits for the same thing.
  var navWatch = null;
  function endNav(final) {
    var w = navWatch; if (!w) return;
    var moved = false; try { moved = E.pageMark() !== w.before; } catch (e) { }
    if (moved) send({ type: 'rec.patch', id: w.id, patch: { nav: true } });
    if (moved || final) { clearInterval(w.timer); navWatch = null; }
  }
  function watchNav(id, before) {
    endNav(true);
    if (!id) return;
    navWatch = { id: id, before: before, n: 0, timer: setInterval(function () { if (navWatch && ++navWatch.n > 200) endNav(true); else endNav(false); }, 300) };
  }

  // ---------- steps ----------
  function emitClick(el, extra) {
    endNav(true);
    var mark = E.pageMark();
    var step = Object.assign({ type: 'click', target: E.targetOf(el), final: E.isFinal(el) }, extra || {});
    var id = emit(step, el);
    watchNav(id, mark);
    lastPress = { el: el, t: Date.now(), id: id };
    opener = { el: el, t: Date.now(), stepId: id, loc: step.target };
    watchToggle(el, id); watchSelects(id);
    return id;
  }
  function emitChoose(item, viaKey) {
    var oe = opener.el, text = (E.txt(item.el) || item.el.getAttribute('aria-label') || '').slice(0, 140);
    if (!text) return false;
    var step = { type: 'choose', target: openerLoc(), option: text, optionLoc: E.targetOf(item.el), final: E.isFinal(item.el) };
    var merge = [];
    if (opener.stepId && !opener.used) merge.push(opener.stepId);       // the "open it" click is part of this step now
    if (isText(oe) && !oe.isContentEditable) {
      if (typedIn.has(oe) && oe.value && !oe.readOnly) step.typed = oe.value;
      var lf = lastFill.get(oe); if (lf) merge.push(lf);
      dirty.delete(oe); typedIn.delete(oe);
      setTimeout(function () { if (oe.isConnected) { prevVal.set(oe, valOf(oe)); dirty.delete(oe); } }, 450);   // what the list put in the box is not something you typed
    }
    if (merge.length) step.merge = merge;
    opener.used = true;
    endNav(true);
    var mark = E.pageMark();
    var id = emit(step, item.el);
    watchNav(id, mark);
    lastPress = { el: item.el, t: Date.now(), id: id };
    if (viaKey) trace('  (picked with the keyboard)');
    watchSelects(id);
    return true;
  }

  // ---------- listeners ----------
  function mine(e, viaRoot) {
    if (!active() || !e.isTrusted) return null;
    var el = real(e); if (!el || E.inUI(el)) return null;
    if (!viaRoot && closedHosts.has(el)) return null;      // a sealed component: its own listener (below) sees the true target
    if (seen.has(e)) return null; seen.add(e);
    return el;
  }
  function onPress(e, viaRoot) {
    if (e.button !== 0) return;
    var el = mine(e, viaRoot); if (!el) return;
    var f = pressField(el);
    settleSelects();                                       // whatever the last press changed belongs to that press, not this one
    endNav(true);
    flushAll(f);
    nav = { el: null, keys: [] };
    if (f) { fieldPress.set(f, Date.now()); if (isText(f) || f.readOnly) setOpener(f, null, true); return; }
    var item = optionItem(el);
    if (item && linked(item) && emitChoose(item)) return;
    var act = actionable(el);
    if (!act) { trace('press ignored (nothing clickable there)', el); return; }
    emitClick(act);
  }
  function onClick(e, viaRoot) {
    var el = mine(e, viaRoot); if (!el) return;
    if (pressField(el)) return;
    var act = actionable(el); if (!act) return;
    var lp = lastPress, recent = lp && Date.now() - lp.t < 1500;
    if (recent && (!lp.el.isConnected || lp.el === act || lp.el.contains(act) || act.contains(lp.el) || (lp.el.tagName === 'LABEL' && lp.el.control === act))) return;   // already written down at press time
    if (e.detail !== 0 && recent) return;                  // pressed one thing, released on another
    // a click with no press: Enter or Space on a button, or Enter in a box sending its form
    flushAll();
    var extra = lastKey && Date.now() - lastKey.t < 400 && lastKey.id ? { merge: [lastKey.id] } : null;
    emitClick(act, extra);
  }
  function onInput(e, viaRoot) {
    var el = mine(e, viaRoot); if (!el) return;
    var f = fieldOf(el); if (skip(f)) return;
    touched.set(f, Date.now());
    if (dirty.size && !(dirty.size === 1 && dirty.has(f))) flushAll(f);   // moved on to another box: write the last one down first
    if (!prevVal.has(f) && f.tagName !== 'SELECT' && f.type !== 'checkbox' && f.type !== 'radio') prevVal.set(f, '');
    mark(f);
    if (f.tagName === 'SELECT' || f.type === 'checkbox' || f.type === 'radio') { flush(f); return; }
    typedIn.add(f);
    if (f.tagName === 'INPUT') setOpener(f, null, true);    // typing may be what opens a suggestion list
  }
  function onChange(e, viaRoot) {
    var el = mine(e, viaRoot); if (!el) return;
    var f = fieldOf(el); if (skip(f)) return;
    touched.set(f, Date.now());
    if (dirty.size && !(dirty.size === 1 && dirty.has(f))) flushAll(f);
    if (f.tagName === 'SELECT' || f.type === 'checkbox' || f.type === 'radio') mark(f);
    flush(f);
  }
  function onFocusIn(e, viaRoot) {
    if (!active()) return;
    var el = real(e), f = fieldOf(el);
    if (f && !skip(f) && !prevVal.has(f)) prevVal.set(f, valOf(f));
  }
  function onFocusOut(e, viaRoot) {
    if (!active()) return;
    var f = fieldOf(real(e)); if (f && dirty.has(f)) flush(f);
  }
  function activeOption(el) {
    if (OPT_ROLE.test(el.getAttribute('role') || '')) return el;                 // focus sits on the item itself
    var id = el.getAttribute('aria-activedescendant');
    if (id) { var o = E.rootOf(el).getElementById(id) || document.getElementById(id); if (o && E.visible(o)) return o; }
    if (!(el.getAttribute('aria-expanded') === 'true' || el.hasAttribute('aria-autocomplete') || (opener && opener.el === el))) return null;
    var hot = E.qsa('[role="option"].focused,[role="option"].highlighted,[role="option"].active,[role="option"].is-focused,[role="option"][data-focus="true"],[role="option"][data-focused="true"],[role="option"][data-highlighted],[role="option"][data-active],[role="option"][data-active-item],[role="option"].Mui-focused,[role="option"].Mui-focusVisible,[role="option"].ant-select-item-option-active,.select2-results__option--highlighted,.active-result.highlighted,.pac-item-selected,.ui-menu-item .ui-state-active').filter(E.visible);
    return hot.length === 1 ? hot[0] : null;
  }
  function onKey(e, viaRoot) {
    if (e.isComposing) return;
    var k = e.key;
    if (!/^(Enter| |Tab|ArrowDown|ArrowUp|Home|End|PageDown|PageUp)$/.test(k)) return;
    var el = mine(e, viaRoot); if (!el) return;
    var f = fieldOf(el), text = isText(f);
    if (f && (f.tagName === 'SELECT' || f.tagName === 'TEXTAREA' || f.isContentEditable)) return;   // their own keys, their own change
    if (/^(Arrow|Home|End|Page)/.test(k)) {
      if (nav.el !== el) nav = { el: el, keys: [] };
      if (nav.keys.length < 40) nav.keys.push(k);
      if (!opener || opener.el !== el) setOpener(el, null);
      return;
    }
    if (k === ' ' && text) return;
    var opt = activeOption(el);
    if (opt && E.visible(opt)) {                             // arrows + Enter in an open list = a pick
      flushAll(el);
      if (OPT_ROLE.test(el.getAttribute('role') || '')) { if (!opener || opener.el === el) { nav = { el: null, keys: [] }; return emitClick(el); } }
      else if (!opener || opener.el !== el) setOpener(el, null);
      nav = { el: null, keys: [] };
      if (emitChoose({ el: opt, fresh: true }, true)) return;
    }
    if (k === 'Tab') { nav = { el: null, keys: [] }; return; }
    if (el.matches('button,a[href],summary,input[type="button"],input[type="submit"],input[type="reset"],input[type="checkbox"],input[type="radio"]')) return;   // the browser answers these with a click
    var keys = nav.el === el ? nav.keys.slice() : []; nav = { el: null, keys: [] };
    if (!text) {
      if (!el.matches(SEM)) return;
      flushAll();
      if (keys.length) { emit({ type: 'key', keys: keys.concat([k]), target: E.targetOf(el) }, el); return; }   // a keyboard-driven widget we can't read: replay the keys
      emitClick(el);                                         // Enter/Space on a fake button
      return;
    }
    if (k === 'Enter') {                                     // Enter in a box: add a tag, run a search, send a form
      flushAll();
      endNav(true);
      var mark = E.pageMark();
      var id = emit({ type: 'key', keys: keys.concat(['Enter']), target: E.targetOf(el) }, el);
      lastKey = { id: id, t: Date.now() };
      watchNav(id, mark);
      prevVal.set(f, '');                                    // the box may be emptied and reused
    }
  }

  var H = [['pointerdown', onPress], ['click', onClick], ['input', onInput], ['change', onChange], ['focusin', onFocusIn], ['focusout', onFocusOut], ['keydown', onKey]];
  function onLeave() { if (navWatch) { send({ type: 'rec.patch', id: navWatch.id, patch: { nav: true } }); clearInterval(navWatch.timer); navWatch = null; } flushAll(); flushTrace(); }   // leaving the page is the clearest "it moved on" there is
  function note(muts) {
    var now = Date.now();
    for (var i = 0; i < muts.length; i++) {
      var m = muts[i];
      if (m.type === 'attributes') { if (m.target.nodeType === 1 && !m.target.hasAttribute('data-fq-ui')) fresh.set(m.target, now); }
      else for (var j = 0; j < m.addedNodes.length; j++) { var n = m.addedNodes[j]; if (n.nodeType === 1 && !n.hasAttribute('data-fq-ui')) fresh.set(n, now); }
    }
    clearTimeout(rootT); rootT = setTimeout(watchRoots, 400);
  }
  var MO_OPT = { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'hidden', 'aria-hidden', 'aria-expanded', 'open', 'data-state'] };
  function watchRoots() {
    if (!on) return;
    E.roots(true).forEach(function (r) {
      if (watched.has(r)) return; watched.add(r);
      try { mo.observe(r, MO_OPT); } catch (e) { }
      if (r.mode === 'closed') {                             // sealed: listen from the inside
        closedHosts.add(r.host);
        H.forEach(function (h) { r.addEventListener(h[0], function (e) { h[1](e, true); }, true); });
      }
    });
  }
  function attach() {
    if (attached) return; attached = true;
    H.forEach(function (h) { window.addEventListener(h[0], h[1], true); });
    window.addEventListener('pagehide', onLeave, true);
  }
  function detach() {
    if (!attached) return; attached = false;
    H.forEach(function (h) { window.removeEventListener(h[0], h[1], true); });
    window.removeEventListener('pagehide', onLeave, true);
  }
  function start() {
    on = true; t0 = Date.now(); attach();
    if (!mo) mo = new MutationObserver(note);
    try { mo.observe(document.documentElement, MO_OPT); } catch (e) { }
    watchRoots();
    trace('recording in ' + (TOP ? 'page ' : 'frame ') + location.hostname);
  }
  function stop() {
    if (on) { settleSelects(); endNav(true); flushAll(); flushTrace(); }
    on = false; detach();
    if (mo) mo.disconnect();
    watched = new WeakSet(); dirty.clear(); opener = lastPress = lastKey = null;
  }

  chrome.runtime.onMessage.addListener(function (msg) {
    if (!msg || msg.type !== 'fq.rec') return;
    pending = false;
    if (msg.on) start(); else stop();
  });
  // be listening from the first moment of the page; drop out again if nothing is being recorded
  attach();
  send({ type: 'rec.state' }).then(function (r) {
    if (!pending) return;
    pending = false;
    if (r && r.on) { start(); queue.forEach(function (q) { emit(q[0], q[1]); }); }
    else detach();
    queue = [];
  });

  window.FQREC = { frameInfo: frameInfo, isOn: function () { return on; } };
})();
