# FormQuest 1.5: install guide

FormQuest works in both Chrome and Microsoft Edge. It's the same folder for both.

## Install (one time, about 1 minute)

1. Unzip `formquest-1.5.zip` somewhere you'll keep it, for example `Documents\FormQuest`. Don't delete the folder afterward; the browser runs it from there.
2. Open the extensions page:
   - **Chrome:** type `chrome://extensions` in the address bar
   - **Edge:** type `edge://extensions` in the address bar
3. Turn on **Developer mode** (top right in Chrome, left side in Edge).
4. Click **Load unpacked** and pick the `formquest` folder, the one that has `manifest.json` inside.
5. Click the puzzle-piece icon in the toolbar and **pin** FormQuest so Nib's pencil icon is always there.

The Guild Hall opens by itself the first time. Start there.

## First-time setup

1. **Hero sheet:** press **Choose resume file** (PDF, Word .docx or text) and FormQuest fills in most of your sheet. Check what it found, fix anything, and save. Then fill in whatever is left. Add a Business profile if you want one.
2. **Settings, then Master password:** this encrypts your SSN, date of birth, VA file number and EIN. It never leaves your computer and can't be recovered, so write it down somewhere safe.
3. **Answer bank:** answer the common job screening questions (work authorization, sponsorship, veteran status and so on).

## Everyday use

- On a page with a form, the **FormQuest** badge appears at the bottom right.
- **▶ Fill this page** fills everything FormQuest recognizes.
- **⏩ Fill & continue** fills, presses Next, and keeps going page after page. It pauses when a required box needs you. On the last page it stops before Submit unless you turn on "Press Submit" in Settings.
- **👁 Preview** outlines every box: green = sure, yellow = guess, red = unknown, purple = a screening question.
- **✎ Teach** lets you click any box and tell FormQuest what it is. It remembers per site.
- **⏺ Record quest** records you doing a form once (great for timesheets). After that it's one click. While you record, every step flashes green on the page and is listed in the panel. If something you did doesn't flash, it wasn't recorded. **↶ Undo last step** removes a mistake.
- **Hotkeys:** Alt+Shift+F fills the page. Alt+Shift+Q opens the panel.

## Good to know

- To unlock the vault, use the toolbar button, never a web page. FormQuest will never ask for your master password on a website.
- It won't solve CAPTCHAs or log in for you. Outside a quest it never ticks "I agree" or "I certify" boxes on its own. In a quest it does what you recorded.
- **Submit in quests:** a quest presses what you pressed while recording, Submit included. First it checks for empty required boxes, then counts down 3 seconds (press **Hold it!** or Esc to stop). Settings lets you make it instant, or make it stop before Submit like before.
- To update it later, replace the folder's files and click the reload arrow on the extensions page. Your saved info stays. The version number shows at the top of the FormQuest panel and in the toolbar pop-up, so you can check which build is running.
- Coming from 1.0: do the same, then refresh any tabs that were already open. Old quests still run, but re-record the ones that missed steps.
- Back up anytime: Guild Hall, then Settings, then Save backup file.

## What's new in 1.5: move the button anywhere

Drag the FormQuest button (or the top of the open panel) to any spot on the page so it never covers what you need. Each site remembers its own spot, and new sites start where you last put it. The panel always opens toward the middle of the screen. To put it back, open the panel and click **Move me back to the corner**.

## What's new in 1.4: dates, and staying in step with the site

- **Dates are one step.** Pick a date from a calendar while recording, however many clicks it takes, and the quest saves it as "put this date in this box". On replay it writes the date; if the box only takes clicks, it works the calendar's month and year controls itself and clicks the day.
- **Dates near the day you recorded move with today.** Record "today" or "this Friday" and the quest uses the same distance from the day you run it. Dates more than two weeks away stay exact. Each date step has a **Move with today** switch in the Guild Hall.
- **Skipped pages.** If the site skips a page it showed when you recorded (a notice, an intro), the quest notices and doesn't press Next an extra time.
- **A better pause.** When it can't find something, press Continue after fixing the page (even by going back a page) and it tries that step again, then moves on if it still isn't there.
- Fill puts profile dates (start date, date of birth) into calendar boxes too.
- Re-record quests that pick dates from a calendar, so the calendar clicks become date steps.

## What came in 1.3: dropdowns

- **Fill picks from dropdowns instead of typing into them.** It presses the box, watches what list appears, and chooses the match, whatever the site built the dropdown out of.
- If a box looks like plain text but wipes what was typed or answers "please select", FormQuest goes back and picks from its list.
- Click-to-choose boxes you can't type in, and real dropdowns hidden behind a prettier copy, are filled too.
- If nothing matches exactly it takes the site's closest match, outlines the box in yellow, and tells you to look. If nothing matches at all, it leaves that one for you and says so.

## What came in 1.2

- **Quests press Submit.** If you pressed a final button while recording, the quest presses it too, after a quick check and a 3-second countdown.
- **Next is understood.** The recorder notes when a press moved the page on, and the replay waits for the page to actually change before the next step. If the page doesn't move, it stops and tells you instead of filling the wrong page.
- **Resume import.** Give the Hero sheet a PDF, Word or text resume. It reads it on your computer (no upload, no AI), shows what it found, and saves what you approve.
- Re-record quests made in 1.0 or 1.1 that go through Next pages, so they pick up the new page-change notes.

## What came in 1.1: the recorder was rebuilt

- Records pop-up dropdowns of every kind (Workday, React, Material, Ant Design, Select2, Chosen and the like), menus that pick on mouse-down, type-ahead boxes, date pickers, keyboard picks with arrows and Enter, Enter-to-add boxes, rich text boxes, fake checkboxes and switches, and clickable things that aren't real buttons.
- Records inside embedded frames and inside sealed components (shadow DOM).
- Tells timesheet cells apart by row and column, and twin buttons apart by the heading they sit under.
- A dropdown pick is one step: "Choose Georgia in State". Replays open the list and pick by name, so list order can change.
- Quests wait for the page to settle instead of a fixed pause, and carry on across page loads.
- In the Guild Hall, each quest lists its steps in plain words. Remove a step with the ✕ beside it.

## If a site still isn't recorded right

1. Record the quest anyway and save it.
2. Guild Hall, then Quests, then **Copy recorder notes** on that quest.
3. Paste the notes to Claude and say which step was missed. The notes list what the recorder heard (element names, never what you typed).

## What no browser extension can record

CAPTCHAs, the file-upload window, PDF forms opened in the browser's PDF viewer, pages drawn on a canvas, and the rare site that rejects simulated clicks.
